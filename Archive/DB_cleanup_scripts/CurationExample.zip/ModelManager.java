/**
 * Copyright (c) 2001, SAIC, its vendors, and suppliers. ALL RIGHTS RESERVED.
 *
 * @author: Johnita Beasley
 * @date: July 20, 2005
 *
 * Revision History
 * ----------------
 *
 * 2005 July 21    Johnita Beasley    Created and successfully compiled.
 *
 */

/**
 *
 */
public class ModelManager
{
	public ModelManager()
	{
	}

	public void executeCurationExample()
	{
		CurationManager curationManager = new CurationManagerImpl();

		//Use Case: A request comes from the client to the ModelManager requesting to create
		//			a new AnimalModel
		Curateable animalModel = new AnimalModel();
		animalModel = curationManager.changeState(animalModel, null);
		System.out.println(">>>>>The new AnimalModel state is: " + animalModel.getState());

		//Use Case: A request comes from the client to the ModelManager requesting to update
		//			the state/status of the created AnimalModel (the user has indicated the
		//			model is complete).
		curationManager.changeState(animalModel, "CompleteNotScreened");

		//Use Case: A request comes from the client (Admin) to the ModelManager requesting
		//			that a screener be assigned to screen the newly submiited model.
		curationManager.changeState(animalModel, "ScreenerAssigned");

		//Use Case: A request comes from the client (Admin) to the ModelManager requesting
		//			that the model has beed sucessfully screened.
		curationManager.changeState(animalModel, "ScreenerApproved");

		//Use Case: A request comes from the client (Admin) to the ModelManager requesting
		//			that a reviewer be assigned to review the newly submiited model.
		curationManager.changeState(animalModel, "ReviewerAssigned");

		//Use Case: A request comes from the client (Admin) to the ModelManager requesting
		//			that the model has beed sucessfully reviewed.
		curationManager.changeState(animalModel, "ReviewerApproved");

		//Use Case: A request comes from the client (Admin) to the ModelManager requesting
		//			that the model state/status be set to "sucessfully curated".
		curationManager.changeState(animalModel, "Complete");


	}

	public static void main(String[] args)
	{
		ModelManager modelManager = new ModelManager();
		modelManager.executeCurationExample();
	}
}