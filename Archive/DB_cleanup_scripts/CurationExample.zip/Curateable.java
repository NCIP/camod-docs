  import java.io.*;

public interface Curateable extends Serializable
{
  //----------------------------------------------------------------------
  //                            METHODS
  //----------------------------------------------------------------------
  public void setState(String state);

  public String getState();

}
