/**
 * Copyright (c) 2001, SAIC, its vendors, and suppliers. ALL RIGHTS RESERVED.
 *
 * @author: Johnita Beasley
 * @date: November 14, 2001
 *
 * Revision History
 * ----------------
 *
 * 2005 July 22    Johnita Beasley    Created and successfully compiled.
 *
 */

public class AnimalModel extends AbstractCancerModel
{
    public AnimalModel(){}
}
