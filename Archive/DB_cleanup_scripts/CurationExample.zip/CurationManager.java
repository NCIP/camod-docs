/**
 * Copyright (c) 2001, SAIC, its vendors, and suppliers. ALL RIGHTS RESERVED.
 *
 * @author: Johnita Beasley
 * @date: July 20, 2005
 *
 * Revision History
 * ----------------
 *
 * 2005 July 21    Johnita Beasley    Created and successfully compiled.
 *
 */


/**
 *
 */
public interface CurationManager
{
    public String getDefaultState();
    public Curateable changeState(Curateable obj, String newState);
    public String processEvent(org.w3c.dom.Element curationState);
}
