/**
 * Copyright (c) 2001, SAIC, its vendors, and suppliers. ALL RIGHTS RESERVED.
 *
 * @author: Johnita Beasley
 * @date: November 14, 2001
 *
 * Revision History
 * ----------------
 *
 * 2005 July 22    Johnita Beasley    Created and successfully compiled.
 *
 */

public abstract class AbstractCancerModel
	implements Curateable
{
    public String state = null;

    public void setState(String p_state)
    {
        this.state = p_state;
    }

    public String getState()
    {
        return this.state;
    }
}
