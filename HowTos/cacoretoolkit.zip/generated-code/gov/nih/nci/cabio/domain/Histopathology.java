

package gov.nih.nci.cabio.domain;


public interface Histopathology 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getComments();
	   public void setComments( java.lang.String comments);
	
	   
	   public  java.lang.String getGrossDescription();
	   public void setGrossDescription( java.lang.String grossDescription);
	
	   
	   public  java.lang.String getRelationalOperation();
	   public void setRelationalOperation( java.lang.String relationalOperation);
	
	   
	   public  java.lang.Float getTumorIncidenceRate();
	   public void setTumorIncidenceRate( java.lang.Float tumorIncidenceRate);
	
	   
	   public  java.lang.String getSurvivalInfo();
	   public void setSurvivalInfo( java.lang.String survivalInfo);
	
	   
	   public  java.lang.String getAgeOfOnset();
	   public void setAgeOfOnset( java.lang.String ageOfOnset);
	
	   
	   public  java.lang.String getMicroscopicDescription();
	   public void setMicroscopicDescription( java.lang.String microscopicDescription);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.DiseaseOntology getDiseaseOntology();
		  
		
	public void setDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology diseaseOntology);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getAnomalyCollection();
	      
		
	public void setAnomalyCollection(java.util.Collection anomalyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getClinicalTrialProtocolCollection();
	      
		
	public void setClinicalTrialProtocolCollection(java.util.Collection clinicalTrialProtocolCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getLibraryCollection();
	      
		
	public void setLibraryCollection(java.util.Collection libraryCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.OrganOntology getOrganOntology();
		  
		
	public void setOrganOntology(gov.nih.nci.cabio.domain.OrganOntology organOntology);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getMetastasisCollection();
	      
		
	public void setMetastasisCollection(java.util.Collection metastasisCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	
}
