

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ProteinImpl 
	implements java.io.Serializable, Protein 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String primaryAccession;
	   public  java.lang.String getPrimaryAccession(){
	      return primaryAccession;
	   }
	   public void setPrimaryAccession( java.lang.String primaryAccession){
	      this.primaryAccession = primaryAccession;
	   }
	
	   
	   public java.lang.String uniProtCode;
	   public  java.lang.String getUniProtCode(){
	      return uniProtCode;
	   }
	   public void setUniProtCode( java.lang.String uniProtCode){
	      this.uniProtCode = uniProtCode;
	   }
	
	   
	   public java.lang.String copyrightStatement;
	   public  java.lang.String getCopyrightStatement(){
	      return copyrightStatement;
	   }
	   public void setCopyrightStatement( java.lang.String copyrightStatement){
	      this.copyrightStatement = copyrightStatement;
	   }
	
	   
	   public java.util.Collection secondaryAccession;
	   public  java.util.Collection getSecondaryAccession(){
	      return secondaryAccession;
	   }
	   public void setSecondaryAccession( java.util.Collection secondaryAccession){
	      this.secondaryAccession = secondaryAccession;
	   }
	
	   
	   public java.util.Collection keywords;
	   public  java.util.Collection getKeywords(){
	      return keywords;
	   }
	   public void setKeywords( java.util.Collection keywords){
	      this.keywords = keywords;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection proteinAliasCollection = new java.util.HashSet();
			public java.util.Collection getProteinAliasCollection(){
			try{
			   if(proteinAliasCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Protein thisIdSet = new gov.nih.nci.cabio.domain.impl.ProteinImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.ProteinAlias", thisIdSet);				 
				 	proteinAliasCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Protein:getProteinAliasCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return proteinAliasCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setProteinAliasCollection(java.util.Collection proteinAliasCollection){
	   		this.proteinAliasCollection = proteinAliasCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection geneCollection = new java.util.HashSet();
			public java.util.Collection getGeneCollection(){
			try{
			   if(geneCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Protein thisIdSet = new gov.nih.nci.cabio.domain.impl.ProteinImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Gene", thisIdSet);				 
				 	geneCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Protein:getGeneCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return geneCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setGeneCollection(java.util.Collection geneCollection){
	   		this.geneCollection = geneCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection taxonCollection = new java.util.HashSet();
			public java.util.Collection getTaxonCollection(){
			try{
			   if(taxonCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Protein thisIdSet = new gov.nih.nci.cabio.domain.impl.ProteinImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Taxon", thisIdSet);				 
				 	taxonCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Protein:getTaxonCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return taxonCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setTaxonCollection(java.util.Collection taxonCollection){
	   		this.taxonCollection = taxonCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			private gov.nih.nci.cabio.domain.ProteinSequence proteinSequence;
			public gov.nih.nci.cabio.domain.ProteinSequence getProteinSequence(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Protein thisIdSet = new gov.nih.nci.cabio.domain.impl.ProteinImpl();
			  thisIdSet.setId(this.getId());
			  try {
			  java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.ProteinSequence", thisIdSet);				 
			 
			  if (resultList!=null && resultList.size()>0) {
			     proteinSequence = (gov.nih.nci.cabio.domain.ProteinSequence)resultList.get(0);
			     }
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Protein:getProteinSequence throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return proteinSequence;			
                        }
                        
	      
	               
	   
	   
	   
	   public void setProteinSequence(gov.nih.nci.cabio.domain.ProteinSequence proteinSequence){
		this.proteinSequence = proteinSequence;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Protein) {
				Protein c =(Protein)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}