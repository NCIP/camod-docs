

package gov.nih.nci.cabio.domain;


public interface ClinicalTrialProtocol 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getCurrentStatus();
	   public void setCurrentStatus( java.lang.String currentStatus);
	
	   
	   public  java.lang.String getTreatmentFlag();
	   public void setTreatmentFlag( java.lang.String treatmentFlag);
	
	   
	   public  java.lang.String getParticipationType();
	   public void setParticipationType( java.lang.String participationType);
	
	   
	   public  java.lang.String getLeadOrganizationId();
	   public void setLeadOrganizationId( java.lang.String leadOrganizationId);
	
	   
	   public  java.lang.String getTitle();
	   public void setTitle( java.lang.String title);
	
	   
	   public  java.lang.String getPIName();
	   public void setPIName( java.lang.String PIName);
	
	   
	   public  java.lang.String getDocumentNumber();
	   public void setDocumentNumber( java.lang.String documentNumber);
	
	   
	   public  java.lang.String getNIHAdminCode();
	   public void setNIHAdminCode( java.lang.String NIHAdminCode);
	
	   
	   public  java.lang.String getLeadOrganizationName();
	   public void setLeadOrganizationName( java.lang.String leadOrganizationName);
	
	   
	   public  java.lang.String getPhase();
	   public void setPhase( java.lang.String phase);
	
	   
	   public  java.lang.String getPDQIdentifier();
	   public void setPDQIdentifier( java.lang.String PDQIdentifier);
	
	   
	   public  java.util.Date getCurrentStatusDate();
	   public void setCurrentStatusDate( java.util.Date currentStatusDate);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getProtocolAssociationCollection();
	      
		
	public void setProtocolAssociationCollection(java.util.Collection protocolAssociationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getHistopathologyCollection();
	      
		
	public void setHistopathologyCollection(java.util.Collection histopathologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getAgentCollection();
	      
		
	public void setAgentCollection(java.util.Collection agentCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDiseaseOntologyCollection();
	      
		
	public void setDiseaseOntologyCollection(java.util.Collection diseaseOntologyCollection);
		
	   
	
	
}
