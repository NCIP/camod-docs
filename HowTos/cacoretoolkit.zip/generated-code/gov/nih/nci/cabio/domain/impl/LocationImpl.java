

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class LocationImpl 
	implements java.io.Serializable, Location 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.Gene gene;
			public gov.nih.nci.cabio.domain.Gene getGene(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Location thisIdSet = new gov.nih.nci.cabio.domain.impl.LocationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Gene", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                gene = (gov.nih.nci.cabio.domain.Gene)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Location:getGene throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return gene;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setGene(gov.nih.nci.cabio.domain.Gene gene){
		this.gene = gene;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.Chromosome chromosome;
			public gov.nih.nci.cabio.domain.Chromosome getChromosome(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Location thisIdSet = new gov.nih.nci.cabio.domain.impl.LocationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Chromosome", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                chromosome = (gov.nih.nci.cabio.domain.Chromosome)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Location:getChromosome throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return chromosome;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setChromosome(gov.nih.nci.cabio.domain.Chromosome chromosome){
		this.chromosome = chromosome;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.SNP SNP;
			public gov.nih.nci.cabio.domain.SNP getSNP(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Location thisIdSet = new gov.nih.nci.cabio.domain.impl.LocationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.SNP", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                SNP = (gov.nih.nci.cabio.domain.SNP)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Location:getSNP throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return SNP;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setSNP(gov.nih.nci.cabio.domain.SNP SNP){
		this.SNP = SNP;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			private gov.nih.nci.cabio.domain.NucleicAcidSequence nucleicAcidSequence;
			public gov.nih.nci.cabio.domain.NucleicAcidSequence getNucleicAcidSequence(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Location thisIdSet = new gov.nih.nci.cabio.domain.impl.LocationImpl();
			  thisIdSet.setId(this.getId());
			  try {
			  java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.NucleicAcidSequence", thisIdSet);				 
			 
			  if (resultList!=null && resultList.size()>0) {
			     nucleicAcidSequence = (gov.nih.nci.cabio.domain.NucleicAcidSequence)resultList.get(0);
			     }
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Location:getNucleicAcidSequence throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return nucleicAcidSequence;			
                        }
                        
	      
	               
	   
	   
	   
	   public void setNucleicAcidSequence(gov.nih.nci.cabio.domain.NucleicAcidSequence nucleicAcidSequence){
		this.nucleicAcidSequence = nucleicAcidSequence;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Location) {
				Location c =(Location)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}