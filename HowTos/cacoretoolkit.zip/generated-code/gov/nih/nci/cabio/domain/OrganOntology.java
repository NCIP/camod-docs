

package gov.nih.nci.cabio.domain;


public interface OrganOntology 




    extends Ontology



{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getAnomalyCollection();
	      
		
	public void setAnomalyCollection(java.util.Collection anomalyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildOrganOntologyRelationshipCollection();
	      
		
	public void setChildOrganOntologyRelationshipCollection(java.util.Collection childOrganOntologyRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getParentOrganOntologyRelationshipCollection();
	      
		
	public void setParentOrganOntologyRelationshipCollection(java.util.Collection parentOrganOntologyRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getHistopathologyCollection();
	      
		
	public void setHistopathologyCollection(java.util.Collection histopathologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getExpressionFeatureCollection();
	      
		
	public void setExpressionFeatureCollection(java.util.Collection expressionFeatureCollection);
		
	   
	
	
}
