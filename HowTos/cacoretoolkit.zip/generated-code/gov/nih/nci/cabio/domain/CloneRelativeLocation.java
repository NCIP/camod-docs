

package gov.nih.nci.cabio.domain;


public interface CloneRelativeLocation 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Clone getClone();
		  
		
	public void setClone(gov.nih.nci.cabio.domain.Clone clone);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.NucleicAcidSequence getNucleicAcidSequence();
		  
		
	public void setNucleicAcidSequence(gov.nih.nci.cabio.domain.NucleicAcidSequence nucleicAcidSequence);
		
	
	   
	
	
}
