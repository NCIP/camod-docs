

package gov.nih.nci.cabio.domain;


public interface ProtocolAssociation 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getDiseaseSubCategory();
	   public void setDiseaseSubCategory( java.lang.String diseaseSubCategory);
	
	   
	   public  java.lang.String getCTEPNAME();
	   public void setCTEPNAME( java.lang.String CTEPNAME);
	
	   
	   public  java.lang.Long getIMTCODE();
	   public void setIMTCODE( java.lang.Long IMTCODE);
	
	   
	   public  java.lang.String getDiseaseCategory();
	   public void setDiseaseCategory( java.lang.String diseaseCategory);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.DiseaseOntology getDiseaseOntology();
		  
		
	public void setDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology diseaseOntology);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.ClinicalTrialProtocol getClinicalTrialProtocol();
		  
		
	public void setClinicalTrialProtocol(gov.nih.nci.cabio.domain.ClinicalTrialProtocol clinicalTrialProtocol);
		
	
	   
	
	
}
