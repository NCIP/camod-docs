

package gov.nih.nci.cabio.domain;


public interface ProteinSequence 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.Double getMolecularWeightInDaltons();
	   public void setMolecularWeightInDaltons( java.lang.Double molecularWeightInDaltons);
	
	   
	   public  java.lang.String getCheckSum();
	   public void setCheckSum( java.lang.String checkSum);
	
	   
	   public  java.lang.String getValue();
	   public void setValue( java.lang.String value);
	
	   
	   public  java.lang.Long getLength();
	   public void setLength( java.lang.Long length);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Protein getProtein();
		  
		
	public void setProtein(gov.nih.nci.cabio.domain.Protein protein);
		
	
	   
	
	
}
