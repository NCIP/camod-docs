

package gov.nih.nci.cabio.domain;


public interface Taxon 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getScientificName();
	   public void setScientificName( java.lang.String scientificName);
	
	   
	   public  java.lang.String getEthnicityStrain();
	   public void setEthnicityStrain( java.lang.String ethnicityStrain);
	
	   
	   public  java.lang.String getAbbreviation();
	   public void setAbbreviation( java.lang.String abbreviation);
	
	   
	   public  java.lang.String getCommonName();
	   public void setCommonName( java.lang.String commonName);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getCloneCollection();
	      
		
	public void setCloneCollection(java.util.Collection cloneCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTissueCollection();
	      
		
	public void setTissueCollection(java.util.Collection tissueCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getPathwayCollection();
	      
		
	public void setPathwayCollection(java.util.Collection pathwayCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChromosomeCollection();
	      
		
	public void setChromosomeCollection(java.util.Collection chromosomeCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getProteinCollection();
	      
		
	public void setProteinCollection(java.util.Collection proteinCollection);
		
	   
	
	
}
