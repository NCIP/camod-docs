

package gov.nih.nci.cabio.domain;


public interface CytogeneticLocation 



    extends Location




{
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Cytoband getEndCytoband();
		  
		
	public void setEndCytoband(gov.nih.nci.cabio.domain.Cytoband endCytoband);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Cytoband getStartCytoband();
		  
		
	public void setStartCytoband(gov.nih.nci.cabio.domain.Cytoband startCytoband);
		
	
	   
	
	
}
