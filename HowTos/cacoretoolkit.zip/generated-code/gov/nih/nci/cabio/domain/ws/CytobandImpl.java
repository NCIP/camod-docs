

package gov.nih.nci.cabio.domain.ws;
import gov.nih.nci.cabio.domain.ws.*;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class CytobandImpl 
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.PhysicalLocationImpl physicalLocation;
			public gov.nih.nci.cabio.domain.ws.PhysicalLocationImpl getPhysicalLocation(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setPhysicalLocation(gov.nih.nci.cabio.domain.ws.PhysicalLocationImpl physicalLocation){
		this.physicalLocation = physicalLocation;
	   }	
	   
	   
	
	   
	   
	   
	      
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Cytoband) {
				Cytoband c =(Cytoband)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
