

package gov.nih.nci.cabio.domain.ws;
import gov.nih.nci.cabio.domain.ws.*;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class DiseaseOntologyRelationshipImpl 
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl childDiseaseOntology;
			public gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl getChildDiseaseOntology(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setChildDiseaseOntology(gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl childDiseaseOntology){
		this.childDiseaseOntology = childDiseaseOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl parentDiseaseOntology;
			public gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl getParentDiseaseOntology(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setParentDiseaseOntology(gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl parentDiseaseOntology){
		this.parentDiseaseOntology = parentDiseaseOntology;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof DiseaseOntologyRelationship) {
				DiseaseOntologyRelationship c =(DiseaseOntologyRelationship)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
