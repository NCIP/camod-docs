

package gov.nih.nci.cabio.domain;


public interface Location 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Gene getGene();
		  
		
	public void setGene(gov.nih.nci.cabio.domain.Gene gene);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Chromosome getChromosome();
		  
		
	public void setChromosome(gov.nih.nci.cabio.domain.Chromosome chromosome);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.SNP getSNP();
		  
		
	public void setSNP(gov.nih.nci.cabio.domain.SNP SNP);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.NucleicAcidSequence getNucleicAcidSequence();
		  
		
	public void setNucleicAcidSequence(gov.nih.nci.cabio.domain.NucleicAcidSequence nucleicAcidSequence);
		
	
	   
	
	
}
