

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ProtocolAssociationImpl 
	implements java.io.Serializable, ProtocolAssociation 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String diseaseSubCategory;
	   public  java.lang.String getDiseaseSubCategory(){
	      return diseaseSubCategory;
	   }
	   public void setDiseaseSubCategory( java.lang.String diseaseSubCategory){
	      this.diseaseSubCategory = diseaseSubCategory;
	   }
	
	   
	   public java.lang.String CTEPNAME;
	   public  java.lang.String getCTEPNAME(){
	      return CTEPNAME;
	   }
	   public void setCTEPNAME( java.lang.String CTEPNAME){
	      this.CTEPNAME = CTEPNAME;
	   }
	
	   
	   public java.lang.Long IMTCODE;
	   public  java.lang.Long getIMTCODE(){
	      return IMTCODE;
	   }
	   public void setIMTCODE( java.lang.Long IMTCODE){
	      this.IMTCODE = IMTCODE;
	   }
	
	   
	   public java.lang.String diseaseCategory;
	   public  java.lang.String getDiseaseCategory(){
	      return diseaseCategory;
	   }
	   public void setDiseaseCategory( java.lang.String diseaseCategory){
	      this.diseaseCategory = diseaseCategory;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.DiseaseOntology diseaseOntology;
			public gov.nih.nci.cabio.domain.DiseaseOntology getDiseaseOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.ProtocolAssociation thisIdSet = new gov.nih.nci.cabio.domain.impl.ProtocolAssociationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.DiseaseOntology", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                diseaseOntology = (gov.nih.nci.cabio.domain.DiseaseOntology)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("ProtocolAssociation:getDiseaseOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return diseaseOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology diseaseOntology){
		this.diseaseOntology = diseaseOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ClinicalTrialProtocol clinicalTrialProtocol;
			public gov.nih.nci.cabio.domain.ClinicalTrialProtocol getClinicalTrialProtocol(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.ProtocolAssociation thisIdSet = new gov.nih.nci.cabio.domain.impl.ProtocolAssociationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.ClinicalTrialProtocol", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                clinicalTrialProtocol = (gov.nih.nci.cabio.domain.ClinicalTrialProtocol)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("ProtocolAssociation:getClinicalTrialProtocol throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return clinicalTrialProtocol;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setClinicalTrialProtocol(gov.nih.nci.cabio.domain.ClinicalTrialProtocol clinicalTrialProtocol){
		this.clinicalTrialProtocol = clinicalTrialProtocol;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ProtocolAssociation) {
				ProtocolAssociation c =(ProtocolAssociation)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}