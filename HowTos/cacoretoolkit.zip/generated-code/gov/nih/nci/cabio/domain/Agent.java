

package gov.nih.nci.cabio.domain;


public interface Agent 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.Long getNSCNumber();
	   public void setNSCNumber( java.lang.Long NSCNumber);
	
	   
	   public  java.lang.Boolean getIsCMAPAgent();
	   public void setIsCMAPAgent( java.lang.Boolean isCMAPAgent);
	
	   
	   public  java.lang.String getEVSId();
	   public void setEVSId( java.lang.String EVSId);
	
	   
	   public  java.lang.String getComment();
	   public void setComment( java.lang.String comment);
	
	   
	   public  java.lang.String getSource();
	   public void setSource( java.lang.String source);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getClinicalTrialProtocolCollection();
	      
		
	public void setClinicalTrialProtocolCollection(java.util.Collection clinicalTrialProtocolCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTargetCollection();
	      
		
	public void setTargetCollection(java.util.Collection targetCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	
}
