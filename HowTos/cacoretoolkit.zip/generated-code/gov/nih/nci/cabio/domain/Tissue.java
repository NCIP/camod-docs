

package gov.nih.nci.cabio.domain;


public interface Tissue 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getSex();
	   public void setSex( java.lang.String sex);
	
	   
	   public  java.lang.String getCellLine();
	   public void setCellLine( java.lang.String cellLine);
	
	   
	   public  java.lang.String getSupplier();
	   public void setSupplier( java.lang.String supplier);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getHistology();
	   public void setHistology( java.lang.String histology);
	
	   
	   public  java.lang.String getCellType();
	   public void setCellType( java.lang.String cellType);
	
	   
	   public  java.lang.String getDevelopmentalStage();
	   public void setDevelopmentalStage( java.lang.String developmentalStage);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	   
	   public  java.lang.String getOrgan();
	   public void setOrgan( java.lang.String organ);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Protocol getProtocol();
		  
		
	public void setProtocol(gov.nih.nci.cabio.domain.Protocol protocol);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getLibraryCollection();
	      
		
	public void setLibraryCollection(java.util.Collection libraryCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Taxon getTaxon();
		  
		
	public void setTaxon(gov.nih.nci.cabio.domain.Taxon taxon);
		
	
	   
	
	
}
