

package gov.nih.nci.cabio.domain.ws;
import gov.nih.nci.cabio.domain.ws.*;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class CytogeneticLocationImpl 
    extends LocationImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.CytobandImpl endCytoband;
			public gov.nih.nci.cabio.domain.ws.CytobandImpl getEndCytoband(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setEndCytoband(gov.nih.nci.cabio.domain.ws.CytobandImpl endCytoband){
		this.endCytoband = endCytoband;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.CytobandImpl startCytoband;
			public gov.nih.nci.cabio.domain.ws.CytobandImpl getStartCytoband(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setStartCytoband(gov.nih.nci.cabio.domain.ws.CytobandImpl startCytoband){
		this.startCytoband = startCytoband;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof CytogeneticLocation) {
				CytogeneticLocation c =(CytogeneticLocation)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
