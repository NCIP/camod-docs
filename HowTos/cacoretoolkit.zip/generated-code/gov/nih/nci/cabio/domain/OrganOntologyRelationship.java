

package gov.nih.nci.cabio.domain;


public interface OrganOntologyRelationship 





    extends OntologyRelationship


{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.OrganOntology getChildOrganOntology();
		  
		
	public void setChildOrganOntology(gov.nih.nci.cabio.domain.OrganOntology childOrganOntology);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.OrganOntology getParentOrganOntology();
		  
		
	public void setParentOrganOntology(gov.nih.nci.cabio.domain.OrganOntology parentOrganOntology);
		
	
	   
	
	
}
