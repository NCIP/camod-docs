

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class CytogeneticLocationImpl 
    extends LocationImpl
	implements java.io.Serializable, CytogeneticLocation 
{
	private static final long serialVersionUID = 1234567890L;

	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.Cytoband endCytoband;
			public gov.nih.nci.cabio.domain.Cytoband getEndCytoband(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.CytogeneticLocation thisIdSet = new gov.nih.nci.cabio.domain.impl.CytogeneticLocationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Cytoband", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                endCytoband = (gov.nih.nci.cabio.domain.Cytoband)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("CytogeneticLocation:getEndCytoband throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return endCytoband;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setEndCytoband(gov.nih.nci.cabio.domain.Cytoband endCytoband){
		this.endCytoband = endCytoband;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.Cytoband startCytoband;
			public gov.nih.nci.cabio.domain.Cytoband getStartCytoband(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.CytogeneticLocation thisIdSet = new gov.nih.nci.cabio.domain.impl.CytogeneticLocationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Cytoband", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                startCytoband = (gov.nih.nci.cabio.domain.Cytoband)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("CytogeneticLocation:getStartCytoband throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return startCytoband;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setStartCytoband(gov.nih.nci.cabio.domain.Cytoband startCytoband){
		this.startCytoband = startCytoband;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof CytogeneticLocation) {
				CytogeneticLocation c =(CytogeneticLocation)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}