

package gov.nih.nci.cabio.domain;


public interface Chromosome 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getNumber();
	   public void setNumber( java.lang.String number);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Taxon getTaxon();
		  
		
	public void setTaxon(gov.nih.nci.cabio.domain.Taxon taxon);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getLocationCollection();
	      
		
	public void setLocationCollection(java.util.Collection locationCollection);
		
	   
	
	
}
