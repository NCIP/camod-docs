

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class DiseaseOntologyRelationshipImpl 
	implements java.io.Serializable, DiseaseOntologyRelationship 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.DiseaseOntology childDiseaseOntology;
			public gov.nih.nci.cabio.domain.DiseaseOntology getChildDiseaseOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.DiseaseOntologyRelationship thisIdSet = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyRelationshipImpl();
			  thisIdSet.setId(this.getId());
			  
			   List relations = new ArrayList();
			   relations.add(thisIdSet);
			   gov.nih.nci.cabio.domain.DiseaseOntology obj = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyImpl();
			   	obj.setParentDiseaseOntologyRelationshipCollection(relations);
			   
			  try {
			  	java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.DiseaseOntology", obj);				 
			  	if (resultList!=null && resultList.size()>0) {
			  	childDiseaseOntology = (gov.nih.nci.cabio.domain.DiseaseOntology)resultList.get(0);
		          }
			  
			  } catch(Exception ex) 
			  { 
			      	System.out.println("DiseaseOntologyRelationship:getChildDiseaseOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return childDiseaseOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setChildDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology childDiseaseOntology){
		this.childDiseaseOntology = childDiseaseOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.DiseaseOntology parentDiseaseOntology;
			public gov.nih.nci.cabio.domain.DiseaseOntology getParentDiseaseOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.DiseaseOntologyRelationship thisIdSet = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyRelationshipImpl();
			  thisIdSet.setId(this.getId());
			  
			   List relations = new ArrayList();
			   relations.add(thisIdSet);
			   gov.nih.nci.cabio.domain.DiseaseOntology obj = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyImpl();
			   	obj.setChildDiseaseOntologyRelationshipCollection(relations);
			   
			  try {
			  	java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.DiseaseOntology", obj);				 
			  	if (resultList!=null && resultList.size()>0) {
			  	parentDiseaseOntology = (gov.nih.nci.cabio.domain.DiseaseOntology)resultList.get(0);
		          }
			  
			  } catch(Exception ex) 
			  { 
			      	System.out.println("DiseaseOntologyRelationship:getParentDiseaseOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return parentDiseaseOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setParentDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology parentDiseaseOntology){
		this.parentDiseaseOntology = parentDiseaseOntology;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof DiseaseOntologyRelationship) {
				DiseaseOntologyRelationship c =(DiseaseOntologyRelationship)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}