

package gov.nih.nci.cabio.domain;


public interface Protocol 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getLibraryCollection();
	      
		
	public void setLibraryCollection(java.util.Collection libraryCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTissueCollection();
	      
		
	public void setTissueCollection(java.util.Collection tissueCollection);
		
	   
	
	
}
