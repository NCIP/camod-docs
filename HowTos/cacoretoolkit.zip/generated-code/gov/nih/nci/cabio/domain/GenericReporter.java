

package gov.nih.nci.cabio.domain;


public interface GenericReporter 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGenericArrayCollection();
	      
		
	public void setGenericArrayCollection(java.util.Collection genericArrayCollection);
		
	   
	
	
}
