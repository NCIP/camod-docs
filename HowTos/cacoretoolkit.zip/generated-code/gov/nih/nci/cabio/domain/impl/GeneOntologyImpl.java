

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class GeneOntologyImpl 
	implements java.io.Serializable, GeneOntology 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection parentGeneOntologyRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getParentGeneOntologyRelationshipCollection(){
			try{
			   if(parentGeneOntologyRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
			         	gov.nih.nci.cabio.domain.GeneOntology thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneOntologyImpl();
			         	thisIdSet.setId(this.getId()); 
			         	gov.nih.nci.cabio.domain.GeneOntologyRelationship obj = new gov.nih.nci.cabio.domain.impl.GeneOntologyRelationshipImpl();
				 	
				 		obj.setChildGeneOntology(thisIdSet);
				 	
				 	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneOntologyRelationship", obj);				 
				 	
				 	parentGeneOntologyRelationshipCollection = resultList;  
				 	return resultList;
			         
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("GeneOntology:getParentGeneOntologyRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return parentGeneOntologyRelationshipCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setParentGeneOntologyRelationshipCollection(java.util.Collection parentGeneOntologyRelationshipCollection){
	   		this.parentGeneOntologyRelationshipCollection = parentGeneOntologyRelationshipCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection geneCollection = new java.util.HashSet();
			public java.util.Collection getGeneCollection(){
			try{
			   if(geneCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.GeneOntology thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneOntologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Gene", thisIdSet);				 
				 	geneCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("GeneOntology:getGeneCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return geneCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setGeneCollection(java.util.Collection geneCollection){
	   		this.geneCollection = geneCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection childGeneOntologyRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getChildGeneOntologyRelationshipCollection(){
			try{
			   if(childGeneOntologyRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
			         	gov.nih.nci.cabio.domain.GeneOntology thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneOntologyImpl();
			         	thisIdSet.setId(this.getId()); 
			         	gov.nih.nci.cabio.domain.GeneOntologyRelationship obj = new gov.nih.nci.cabio.domain.impl.GeneOntologyRelationshipImpl();
				 	
				 	        obj.setParentGeneOntology(thisIdSet);
				 	
				 	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneOntologyRelationship", obj);				 
				 	
				 	childGeneOntologyRelationshipCollection = resultList;  
				 	return resultList;
			         
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("GeneOntology:getChildGeneOntologyRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return childGeneOntologyRelationshipCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setChildGeneOntologyRelationshipCollection(java.util.Collection childGeneOntologyRelationshipCollection){
	   		this.childGeneOntologyRelationshipCollection = childGeneOntologyRelationshipCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof GeneOntology) {
				GeneOntology c =(GeneOntology)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}