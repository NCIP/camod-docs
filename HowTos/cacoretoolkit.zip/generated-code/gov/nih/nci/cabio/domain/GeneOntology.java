

package gov.nih.nci.cabio.domain;


public interface GeneOntology 




    extends Ontology



{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getParentGeneOntologyRelationshipCollection();
	      
		
	public void setParentGeneOntologyRelationshipCollection(java.util.Collection parentGeneOntologyRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildGeneOntologyRelationshipCollection();
	      
		
	public void setChildGeneOntologyRelationshipCollection(java.util.Collection childGeneOntologyRelationshipCollection);
		
	   
	
	
}
