

package gov.nih.nci.cabio.domain;


public interface GenericArray 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getArrayName();
	   public void setArrayName( java.lang.String arrayName);
	
	   
	   public  java.lang.String getPlatform();
	   public void setPlatform( java.lang.String platform);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getGenericReporterCollection();
	      
		
	public void setGenericReporterCollection(java.util.Collection genericReporterCollection);
		
	   
	
	
}
