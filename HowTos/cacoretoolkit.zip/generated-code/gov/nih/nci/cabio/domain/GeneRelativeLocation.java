

package gov.nih.nci.cabio.domain;


public interface GeneRelativeLocation 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	   
	
	
}
