

package gov.nih.nci.cabio.domain;


public interface SNP 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getDBSNPID();
	   public void setDBSNPID( java.lang.String DBSNPID);
	
	   
	   public  java.lang.String getValidationStatus();
	   public void setValidationStatus( java.lang.String validationStatus);
	
	   
	   public  java.lang.String getAlleleA();
	   public void setAlleleA( java.lang.String alleleA);
	
	   
	   public  java.lang.String getAlleleB();
	   public void setAlleleB( java.lang.String alleleB);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getDatabaseCrossReferenceCollection();
	      
		
	public void setDatabaseCrossReferenceCollection(java.util.Collection databaseCrossReferenceCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getPopulationFrequencyCollection();
	      
		
	public void setPopulationFrequencyCollection(java.util.Collection populationFrequencyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getLocationCollection();
	      
		
	public void setLocationCollection(java.util.Collection locationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneRelativeLocationCollection();
	      
		
	public void setGeneRelativeLocationCollection(java.util.Collection geneRelativeLocationCollection);
		
	   
	
	
}
