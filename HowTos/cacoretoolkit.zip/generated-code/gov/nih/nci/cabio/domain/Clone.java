

package gov.nih.nci.cabio.domain;


public interface Clone 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.Long getInsertSize();
	   public void setInsertSize( java.lang.Long insertSize);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getCloneRelativeLocationCollection();
	      
		
	public void setCloneRelativeLocationCollection(java.util.Collection cloneRelativeLocationCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Library getLibrary();
		  
		
	public void setLibrary(gov.nih.nci.cabio.domain.Library library);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getNucleicAcidSequenceCollection();
	      
		
	public void setNucleicAcidSequenceCollection(java.util.Collection nucleicAcidSequenceCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTaxonCollection();
	      
		
	public void setTaxonCollection(java.util.Collection taxonCollection);
		
	   
	
	
}
