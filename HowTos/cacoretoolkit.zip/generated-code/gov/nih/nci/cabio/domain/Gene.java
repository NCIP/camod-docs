

package gov.nih.nci.cabio.domain;


public interface Gene 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getFullName();
	   public void setFullName( java.lang.String fullName);
	
	   
	   public  java.lang.Long getClusterId();
	   public void setClusterId( java.lang.Long clusterId);
	
	   
	   public  java.lang.String getSymbol();
	   public void setSymbol( java.lang.String symbol);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Taxon getTaxon();
		  
		
	public void setTaxon(gov.nih.nci.cabio.domain.Taxon taxon);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getPathwayCollection();
	      
		
	public void setPathwayCollection(java.util.Collection pathwayCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getExpressionFeatureCollection();
	      
		
	public void setExpressionFeatureCollection(java.util.Collection expressionFeatureCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getNucleicAcidSequenceCollection();
	      
		
	public void setNucleicAcidSequenceCollection(java.util.Collection nucleicAcidSequenceCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getLocationCollection();
	      
		
	public void setLocationCollection(java.util.Collection locationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getHomologousAssociationCollection();
	      
		
	public void setHomologousAssociationCollection(java.util.Collection homologousAssociationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneRelativeLocationCollection();
	      
		
	public void setGeneRelativeLocationCollection(java.util.Collection geneRelativeLocationCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGenericReporterCollection();
	      
		
	public void setGenericReporterCollection(java.util.Collection genericReporterCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDatabaseCrossReferenceCollection();
	      
		
	public void setDatabaseCrossReferenceCollection(java.util.Collection databaseCrossReferenceCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getLibraryCollection();
	      
		
	public void setLibraryCollection(java.util.Collection libraryCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Chromosome getChromosome();
		  
		
	public void setChromosome(gov.nih.nci.cabio.domain.Chromosome chromosome);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getHistopathologyCollection();
	      
		
	public void setHistopathologyCollection(java.util.Collection histopathologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneAliasCollection();
	      
		
	public void setGeneAliasCollection(java.util.Collection geneAliasCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getOrganOntologyCollection();
	      
		
	public void setOrganOntologyCollection(java.util.Collection organOntologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getProteinCollection();
	      
		
	public void setProteinCollection(java.util.Collection proteinCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneOntologyCollection();
	      
		
	public void setGeneOntologyCollection(java.util.Collection geneOntologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTargetCollection();
	      
		
	public void setTargetCollection(java.util.Collection targetCollection);
		
	   
	
	
}
