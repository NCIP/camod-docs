

package gov.nih.nci.cabio.domain;


public interface Cytoband 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.PhysicalLocation getPhysicalLocation();
		  
		
	public void setPhysicalLocation(gov.nih.nci.cabio.domain.PhysicalLocation physicalLocation);
		
	
	   
	
	   
	   
	   
	      
	   
	
	
}
