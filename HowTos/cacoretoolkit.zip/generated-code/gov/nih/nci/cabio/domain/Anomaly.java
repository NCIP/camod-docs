

package gov.nih.nci.cabio.domain;


public interface Anomaly 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Histopathology getHistopathology();
		  
		
	public void setHistopathology(gov.nih.nci.cabio.domain.Histopathology histopathology);
		
	
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getOrganOntologyCollection();
	      
		
	public void setOrganOntologyCollection(java.util.Collection organOntologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getVocabularyCollection();
	      
		
	public void setVocabularyCollection(java.util.Collection vocabularyCollection);
		
	   
	
	
}
