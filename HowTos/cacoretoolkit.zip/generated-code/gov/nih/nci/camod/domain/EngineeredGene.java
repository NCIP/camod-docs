

package gov.nih.nci.camod.domain;


public interface EngineeredGene 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.Long getCabioId();
	   public void setCabioId( java.lang.Long cabioId);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDatabaseCrossReferenceCollection();
	      
		
	public void setDatabaseCrossReferenceCollection(java.util.Collection databaseCrossReferenceCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.Conditionality getConditionality();
		  
		
	public void setConditionality(gov.nih.nci.camod.domain.Conditionality conditionality);
		
	
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.Image getImage();
		  
		
	public void setImage(gov.nih.nci.camod.domain.Image image);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getExpressionFeatureCollection();
	      
		
	public void setExpressionFeatureCollection(java.util.Collection expressionFeatureCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.GenotypeSummary getGenotypeSummary();
		  
		
	public void setGenotypeSummary(gov.nih.nci.camod.domain.GenotypeSummary genotypeSummary);
		
	
	   
	
	
}
