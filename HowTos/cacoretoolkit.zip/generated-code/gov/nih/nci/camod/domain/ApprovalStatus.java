

package gov.nih.nci.camod.domain;


public interface ApprovalStatus 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	   
	
	
}
