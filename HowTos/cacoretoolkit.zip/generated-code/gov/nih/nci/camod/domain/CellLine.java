

package gov.nih.nci.camod.domain;


public interface CellLine 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getComments();
	   public void setComments( java.lang.String comments);
	
	   
	   public  java.lang.String getExperiment();
	   public void setExperiment( java.lang.String experiment);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.String getResults();
	   public void setResults( java.lang.String results);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getPublicationCollection();
	      
		
	public void setPublicationCollection(java.util.Collection publicationCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	
}
