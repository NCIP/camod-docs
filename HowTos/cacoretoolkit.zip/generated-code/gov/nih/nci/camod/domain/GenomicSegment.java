

package gov.nih.nci.camod.domain;


public interface GenomicSegment 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getLocationOfIntegration();
	   public void setLocationOfIntegration( java.lang.String locationOfIntegration);
	
	   
	   public  java.lang.String getSegmentSize();
	   public void setSegmentSize( java.lang.String segmentSize);
	
	   
	   public  java.lang.String getCloneDesignator();
	   public void setCloneDesignator( java.lang.String cloneDesignator);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.SegmentType getSegmentType();
		  
		
	public void setSegmentType(gov.nih.nci.camod.domain.SegmentType segmentType);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getEngineeredGeneCollection();
	      
		
	public void setEngineeredGeneCollection(java.util.Collection engineeredGeneCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	
}
