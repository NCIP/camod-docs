

package gov.nih.nci.camod.domain;


public interface AbstractCancerModel 







{
	
	   
	   public  java.lang.String getExperimentDesign();
	   public void setExperimentDesign( java.lang.String experimentDesign);
	
	   
	   public  java.lang.String getModelDescriptor();
	   public void setModelDescriptor( java.lang.String modelDescriptor);
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.ApprovalStatus getApprovalStatus();
		  
		
	public void setApprovalStatus(gov.nih.nci.camod.domain.ApprovalStatus approvalStatus);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getPublicationCollection();
	      
		
	public void setPublicationCollection(java.util.Collection publicationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getPartyRoleCollection();
	      
		
	public void setPartyRoleCollection(java.util.Collection partyRoleCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.Availability getAvailability();
		  
		
	public void setAvailability(gov.nih.nci.camod.domain.Availability availability);
		
	
	   
	
	
}
