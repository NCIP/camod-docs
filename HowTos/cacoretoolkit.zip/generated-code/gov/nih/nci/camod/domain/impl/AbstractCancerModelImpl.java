

package gov.nih.nci.camod.domain.impl;
import gov.nih.nci.camod.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class AbstractCancerModelImpl 
	implements java.io.Serializable, AbstractCancerModel 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.String experimentDesign;
	   public  java.lang.String getExperimentDesign(){
	      return experimentDesign;
	   }
	   public void setExperimentDesign( java.lang.String experimentDesign){
	      this.experimentDesign = experimentDesign;
	   }
	
	   
	   public java.lang.String modelDescriptor;
	   public  java.lang.String getModelDescriptor(){
	      return modelDescriptor;
	   }
	   public void setModelDescriptor( java.lang.String modelDescriptor){
	      this.modelDescriptor = modelDescriptor;
	   }
	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.camod.domain.ApprovalStatus approvalStatus;
			public gov.nih.nci.camod.domain.ApprovalStatus getApprovalStatus(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.camod.domain.AbstractCancerModel thisIdSet = new gov.nih.nci.camod.domain.impl.AbstractCancerModelImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.camod.domain.ApprovalStatus", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                approvalStatus = (gov.nih.nci.camod.domain.ApprovalStatus)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("AbstractCancerModel:getApprovalStatus throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return approvalStatus;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setApprovalStatus(gov.nih.nci.camod.domain.ApprovalStatus approvalStatus){
		this.approvalStatus = approvalStatus;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection publicationCollection = new java.util.HashSet();
			public java.util.Collection getPublicationCollection(){
			try{
			   if(publicationCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.camod.domain.AbstractCancerModel thisIdSet = new gov.nih.nci.camod.domain.impl.AbstractCancerModelImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.camod.domain.Publication", thisIdSet);				 
				 	publicationCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("AbstractCancerModel:getPublicationCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return publicationCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setPublicationCollection(java.util.Collection publicationCollection){
	   		this.publicationCollection = publicationCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection partyRoleCollection = new java.util.HashSet();
			public java.util.Collection getPartyRoleCollection(){
			try{
			   if(partyRoleCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.camod.domain.AbstractCancerModel thisIdSet = new gov.nih.nci.camod.domain.impl.AbstractCancerModelImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.camod.domain.PartyRole", thisIdSet);				 
				 	partyRoleCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("AbstractCancerModel:getPartyRoleCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return partyRoleCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setPartyRoleCollection(java.util.Collection partyRoleCollection){
	   		this.partyRoleCollection = partyRoleCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			private gov.nih.nci.camod.domain.Availability availability;
			public gov.nih.nci.camod.domain.Availability getAvailability(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.camod.domain.AbstractCancerModel thisIdSet = new gov.nih.nci.camod.domain.impl.AbstractCancerModelImpl();
			  thisIdSet.setId(this.getId());
			  try {
			  java.util.List resultList = applicationService.search("gov.nih.nci.camod.domain.Availability", thisIdSet);				 
			 
			  if (resultList!=null && resultList.size()>0) {
			     availability = (gov.nih.nci.camod.domain.Availability)resultList.get(0);
			     }
			  } catch(Exception ex) 
			  { 
			      	System.out.println("AbstractCancerModel:getAvailability throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return availability;			
                        }
                        
	      
	               
	   
	   
	   
	   public void setAvailability(gov.nih.nci.camod.domain.Availability availability){
		this.availability = availability;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof AbstractCancerModel) {
				AbstractCancerModel c =(AbstractCancerModel)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}