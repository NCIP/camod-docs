

package gov.nih.nci.camod.domain;


public interface CarcinogenicIntervention 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.EnvironmentalFactor getEnvironmentalFactor();
		  
		
	public void setEnvironmentalFactor(gov.nih.nci.camod.domain.EnvironmentalFactor environmentalFactor);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.TreatmentSchedule getTreatmentSchedule();
		  
		
	public void setTreatmentSchedule(gov.nih.nci.camod.domain.TreatmentSchedule treatmentSchedule);
		
	
	   
	
	   
	   
	   
	      
	   
	
	
}
