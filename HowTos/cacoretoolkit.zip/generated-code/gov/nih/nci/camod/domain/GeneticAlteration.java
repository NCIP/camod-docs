

package gov.nih.nci.camod.domain;


public interface GeneticAlteration 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getObservation();
	   public void setObservation( java.lang.String observation);
	
	   
	   public  java.lang.String getMethodOfObservation();
	   public void setMethodOfObservation( java.lang.String methodOfObservation);
	
	
	
}
