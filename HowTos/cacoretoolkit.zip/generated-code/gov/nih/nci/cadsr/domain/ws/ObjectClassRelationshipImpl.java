

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ObjectClassRelationshipImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	
	   
	   public java.lang.String sourceRole;
	   public  java.lang.String getSourceRole(){
	      return sourceRole;
	   }
	   
	   public void setSourceRole( java.lang.String sourceRole){
	      this.sourceRole = sourceRole;
	   }
	
	   
	   public java.lang.String targetRole;
	   public  java.lang.String getTargetRole(){
	      return targetRole;
	   }
	   
	   public void setTargetRole( java.lang.String targetRole){
	      this.targetRole = targetRole;
	   }
	
	   
	   public java.lang.String direction;
	   public  java.lang.String getDirection(){
	      return direction;
	   }
	   
	   public void setDirection( java.lang.String direction){
	      this.direction = direction;
	   }
	
	   
	   public java.lang.Integer sourceLowMultiplicity;
	   public  java.lang.Integer getSourceLowMultiplicity(){
	      return sourceLowMultiplicity;
	   }
	   
	   public void setSourceLowMultiplicity( java.lang.Integer sourceLowMultiplicity){
	      this.sourceLowMultiplicity = sourceLowMultiplicity;
	   }
	
	   
	   public java.lang.Integer sourceHighMultiplicity;
	   public  java.lang.Integer getSourceHighMultiplicity(){
	      return sourceHighMultiplicity;
	   }
	   
	   public void setSourceHighMultiplicity( java.lang.Integer sourceHighMultiplicity){
	      this.sourceHighMultiplicity = sourceHighMultiplicity;
	   }
	
	   
	   public java.lang.Integer targetLowMultiplicity;
	   public  java.lang.Integer getTargetLowMultiplicity(){
	      return targetLowMultiplicity;
	   }
	   
	   public void setTargetLowMultiplicity( java.lang.Integer targetLowMultiplicity){
	      this.targetLowMultiplicity = targetLowMultiplicity;
	   }
	
	   
	   public java.lang.Integer targetHighMultiplicity;
	   public  java.lang.Integer getTargetHighMultiplicity(){
	      return targetHighMultiplicity;
	   }
	   
	   public void setTargetHighMultiplicity( java.lang.Integer targetHighMultiplicity){
	      this.targetHighMultiplicity = targetHighMultiplicity;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ObjectClassImpl targetObjectClass;
			public gov.nih.nci.cadsr.domain.ws.ObjectClassImpl getTargetObjectClass(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setTargetObjectClass(gov.nih.nci.cadsr.domain.ws.ObjectClassImpl targetObjectClass){
		this.targetObjectClass = targetObjectClass;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ObjectClassImpl sourceObjectClass;
			public gov.nih.nci.cadsr.domain.ws.ObjectClassImpl getSourceObjectClass(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setSourceObjectClass(gov.nih.nci.cadsr.domain.ws.ObjectClassImpl sourceObjectClass){
		this.sourceObjectClass = sourceObjectClass;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ObjectClassRelationship) {
				ObjectClassRelationship c =(ObjectClassRelationship)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
