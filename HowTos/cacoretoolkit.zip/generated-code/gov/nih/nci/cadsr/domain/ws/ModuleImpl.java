

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ModuleImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Integer displayOrder;
	   public  java.lang.Integer getDisplayOrder(){
	      return displayOrder;
	   }
	   
	   public void setDisplayOrder( java.lang.Integer displayOrder){
	      this.displayOrder = displayOrder;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.CaseReportFormImpl caseReportForm;
			public gov.nih.nci.cadsr.domain.ws.CaseReportFormImpl getCaseReportForm(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setCaseReportForm(gov.nih.nci.cadsr.domain.ws.CaseReportFormImpl caseReportForm){
		this.caseReportForm = caseReportForm;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection questionCollection = new java.util.HashSet();
			public java.util.Collection getQuestionCollection(){
	              return questionCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setQuestionCollection(java.util.Collection questionCollection){
	   		this.questionCollection = questionCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
	              return instructionCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ProtocolFormsTemplateImpl protocolFormsTemplate;
			public gov.nih.nci.cadsr.domain.ws.ProtocolFormsTemplateImpl getProtocolFormsTemplate(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setProtocolFormsTemplate(gov.nih.nci.cadsr.domain.ws.ProtocolFormsTemplateImpl protocolFormsTemplate){
		this.protocolFormsTemplate = protocolFormsTemplate;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Module) {
				Module c =(Module)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
