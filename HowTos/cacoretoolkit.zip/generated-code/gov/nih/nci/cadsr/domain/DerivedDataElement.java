

package gov.nih.nci.cadsr.domain;


public interface DerivedDataElement 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.String getConcatenationCharacter();
	   public void setConcatenationCharacter( java.lang.String concatenationCharacter);
	
	   
	   public  java.lang.String getMethods();
	   public void setMethods( java.lang.String methods);
	
	   
	   public  java.lang.String getRule();
	   public void setRule( java.lang.String rule);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.DataElement getDataElement();
		  
		
	public void setDataElement(gov.nih.nci.cadsr.domain.DataElement dataElement);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDataElementDerivationCollection();
	      
		
	public void setDataElementDerivationCollection(java.util.Collection dataElementDerivationCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.DerivationType getDerivationType();
		  
		
	public void setDerivationType(gov.nih.nci.cadsr.domain.DerivationType derivationType);
		
	
	   
	
	
}
