

package gov.nih.nci.cadsr.domain;


public interface ProtocolFormsSet 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getProtocolId();
	   public void setProtocolId( java.lang.String protocolId);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getPhase();
	   public void setPhase( java.lang.String phase);
	
	   
	   public  java.lang.String getLeadOrganizationName();
	   public void setLeadOrganizationName( java.lang.String leadOrganizationName);
	
	   
	   public  java.lang.String getChangeType();
	   public void setChangeType( java.lang.String changeType);
	
	   
	   public  java.lang.String getChangeNumber();
	   public void setChangeNumber( java.lang.String changeNumber);
	
	   
	   public  java.util.Date getReviewedDate();
	   public void setReviewedDate( java.util.Date reviewedDate);
	
	   
	   public  java.lang.String getReviewedBy();
	   public void setReviewedBy( java.lang.String reviewedBy);
	
	   
	   public  java.util.Date getApprovedDate();
	   public void setApprovedDate( java.util.Date approvedDate);
	
	   
	   public  java.lang.String getApprovedBy();
	   public void setApprovedBy( java.lang.String approvedBy);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getCaseReportFormCollection();
	      
		
	public void setCaseReportFormCollection(java.util.Collection caseReportFormCollection);
		
	   
	
	
}
