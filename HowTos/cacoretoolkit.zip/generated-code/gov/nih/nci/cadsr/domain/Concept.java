

package gov.nih.nci.cadsr.domain;


public interface Concept 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getEvsSource();
	   public void setEvsSource( java.lang.String evsSource);
	
	   
	   public  java.lang.String getDefinitionSource();
	   public void setDefinitionSource( java.lang.String definitionSource);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getValueDomainPermissibleValueCollection();
	      
		
	public void setValueDomainPermissibleValueCollection(java.util.Collection valueDomainPermissibleValueCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getComponentConceptCollection();
	      
		
	public void setComponentConceptCollection(java.util.Collection componentConceptCollection);
		
	   
	
	
}
