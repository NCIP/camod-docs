

package gov.nih.nci.cadsr.domain;


public interface Property 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getDefinitionSource();
	   public void setDefinitionSource( java.lang.String definitionSource);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getDataElementConceptCollection();
	      
		
	public void setDataElementConceptCollection(java.util.Collection dataElementConceptCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule();
		  
		
	public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule);
		
	
	   
	
	
}
