

package gov.nih.nci.cadsr.domain;


public interface AdministeredComponent 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.String getPreferredName();
	   public void setPreferredName( java.lang.String preferredName);
	
	   
	   public  java.lang.String getPreferredDefinition();
	   public void setPreferredDefinition( java.lang.String preferredDefinition);
	
	   
	   public  java.lang.String getLongName();
	   public void setLongName( java.lang.String longName);
	
	   
	   public  java.lang.Float getVersion();
	   public void setVersion( java.lang.Float version);
	
	   
	   public  java.lang.String getWorkflowStatusName();
	   public void setWorkflowStatusName( java.lang.String workflowStatusName);
	
	   
	   public  java.lang.String getWorkflowStatusDescription();
	   public void setWorkflowStatusDescription( java.lang.String workflowStatusDescription);
	
	   
	   public  java.lang.String getLatestVersionIndicator();
	   public void setLatestVersionIndicator( java.lang.String latestVersionIndicator);
	
	   
	   public  java.util.Date getBeginDate();
	   public void setBeginDate( java.util.Date beginDate);
	
	   
	   public  java.util.Date getEndDate();
	   public void setEndDate( java.util.Date endDate);
	
	   
	   public  java.lang.String getDeletedIndicator();
	   public void setDeletedIndicator( java.lang.String deletedIndicator);
	
	   
	   public  java.lang.String getChangeNote();
	   public void setChangeNote( java.lang.String changeNote);
	
	   
	   public  java.lang.String getUnresolvedIssue();
	   public void setUnresolvedIssue( java.lang.String unresolvedIssue);
	
	   
	   public  java.lang.String getOrigin();
	   public void setOrigin( java.lang.String origin);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.Long getPublicID();
	   public void setPublicID( java.lang.Long publicID);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	   
	   public  java.lang.String getRegistrationStatus();
	   public void setRegistrationStatus( java.lang.String registrationStatus);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Context getContext();
		  
		
	public void setContext(gov.nih.nci.cadsr.domain.Context context);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getAdministeredComponentClassSchemeItemCollection();
	      
		
	public void setAdministeredComponentClassSchemeItemCollection(java.util.Collection administeredComponentClassSchemeItemCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDesignationCollection();
	      
		
	public void setDesignationCollection(java.util.Collection designationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getReferenceDocumentCollection();
	      
		
	public void setReferenceDocumentCollection(java.util.Collection referenceDocumentCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDefinitionCollection();
	      
		
	public void setDefinitionCollection(java.util.Collection definitionCollection);
		
	   
	
	
}
