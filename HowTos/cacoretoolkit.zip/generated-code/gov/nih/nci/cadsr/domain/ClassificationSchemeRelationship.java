

package gov.nih.nci.cadsr.domain;


public interface ClassificationSchemeRelationship 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.Integer getDisplayOrder();
	   public void setDisplayOrder( java.lang.Integer displayOrder);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ClassificationScheme getChildClassificationScheme();
		  
		
	public void setChildClassificationScheme(gov.nih.nci.cadsr.domain.ClassificationScheme childClassificationScheme);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ClassificationScheme getParentClassificationScheme();
		  
		
	public void setParentClassificationScheme(gov.nih.nci.cadsr.domain.ClassificationScheme parentClassificationScheme);
		
	
	   
	
	
}
