

package gov.nih.nci.cadsr.domain;


public interface PermissibleValue 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.String getValue();
	   public void setValue( java.lang.String value);
	
	   
	   public  java.lang.Long getHighValueNumber();
	   public void setHighValueNumber( java.lang.Long highValueNumber);
	
	   
	   public  java.lang.Long getLowValueNumber();
	   public void setLowValueNumber( java.lang.Long lowValueNumber);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ValueMeaning getValueMeaning();
		  
		
	public void setValueMeaning(gov.nih.nci.cadsr.domain.ValueMeaning valueMeaning);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getValueDomainPermissibleValueCollection();
	      
		
	public void setValueDomainPermissibleValueCollection(java.util.Collection valueDomainPermissibleValueCollection);
		
	   
	
	
}
