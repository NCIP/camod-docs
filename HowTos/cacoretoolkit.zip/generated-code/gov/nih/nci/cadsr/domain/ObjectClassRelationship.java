

package gov.nih.nci.cadsr.domain;


public interface ObjectClassRelationship 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.String getSourceRole();
	   public void setSourceRole( java.lang.String sourceRole);
	
	   
	   public  java.lang.String getTargetRole();
	   public void setTargetRole( java.lang.String targetRole);
	
	   
	   public  java.lang.String getDirection();
	   public void setDirection( java.lang.String direction);
	
	   
	   public  java.lang.Integer getSourceLowMultiplicity();
	   public void setSourceLowMultiplicity( java.lang.Integer sourceLowMultiplicity);
	
	   
	   public  java.lang.Integer getSourceHighMultiplicity();
	   public void setSourceHighMultiplicity( java.lang.Integer sourceHighMultiplicity);
	
	   
	   public  java.lang.Integer getTargetLowMultiplicity();
	   public void setTargetLowMultiplicity( java.lang.Integer targetLowMultiplicity);
	
	   
	   public  java.lang.Integer getTargetHighMultiplicity();
	   public void setTargetHighMultiplicity( java.lang.Integer targetHighMultiplicity);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ObjectClass getTargetObjectClass();
		  
		
	public void setTargetObjectClass(gov.nih.nci.cadsr.domain.ObjectClass targetObjectClass);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ObjectClass getSourceObjectClass();
		  
		
	public void setSourceObjectClass(gov.nih.nci.cadsr.domain.ObjectClass sourceObjectClass);
		
	
	   
	
	
}
