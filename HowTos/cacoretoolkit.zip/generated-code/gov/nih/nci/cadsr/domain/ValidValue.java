

package gov.nih.nci.cadsr.domain;


public interface ValidValue 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.Integer getDisplayOrder();
	   public void setDisplayOrder( java.lang.Integer displayOrder);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Question getQuestion();
		  
		
	public void setQuestion(gov.nih.nci.cadsr.domain.Question question);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ValueDomainPermissibleValue getValueDomainPermissibleValue();
		  
		
	public void setValueDomainPermissibleValue(gov.nih.nci.cadsr.domain.ValueDomainPermissibleValue valueDomainPermissibleValue);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getInstructionCollection();
	      
		
	public void setInstructionCollection(java.util.Collection instructionCollection);
		
	   
	
	
}
