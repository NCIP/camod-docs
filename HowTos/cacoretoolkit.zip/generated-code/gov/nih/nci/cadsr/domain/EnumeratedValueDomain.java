

package gov.nih.nci.cadsr.domain;


public interface EnumeratedValueDomain 



    extends ValueDomain




{
	
	
	   
	   
	   
	      
	
	public java.util.Collection getValueDomainPermissibleValueCollection();
	      
		
	public void setValueDomainPermissibleValueCollection(java.util.Collection valueDomainPermissibleValueCollection);
		
	   
	
	
}
