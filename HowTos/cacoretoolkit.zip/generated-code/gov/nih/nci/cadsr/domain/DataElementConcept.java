

package gov.nih.nci.cadsr.domain;


public interface DataElementConcept 



    extends AdministeredComponent




{
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Qualifier getPropertyQualifier();
		  
		
	public void setPropertyQualifier(gov.nih.nci.cadsr.domain.Qualifier propertyQualifier);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Qualifier getObjectClassQualifier();
		  
		
	public void setObjectClassQualifier(gov.nih.nci.cadsr.domain.Qualifier objectClassQualifier);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Property getProperty();
		  
		
	public void setProperty(gov.nih.nci.cadsr.domain.Property property);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptualDomain getConceptualDomain();
		  
		
	public void setConceptualDomain(gov.nih.nci.cadsr.domain.ConceptualDomain conceptualDomain);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDataElementCollection();
	      
		
	public void setDataElementCollection(java.util.Collection dataElementCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildDataElementConceptRelationshipCollection();
	      
		
	public void setChildDataElementConceptRelationshipCollection(java.util.Collection childDataElementConceptRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ObjectClass getObjectClass();
		  
		
	public void setObjectClass(gov.nih.nci.cadsr.domain.ObjectClass objectClass);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getParentDataElementConceptRelationshipCollection();
	      
		
	public void setParentDataElementConceptRelationshipCollection(java.util.Collection parentDataElementConceptRelationshipCollection);
		
	   
	
	
}
