

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class DataElementImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	

	
	   
	   
	   
	      
			private java.util.Collection questionCollection = new java.util.HashSet();
			public java.util.Collection getQuestionCollection(){
	              return questionCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setQuestionCollection(java.util.Collection questionCollection){
	   		this.questionCollection = questionCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ValueDomainImpl valueDomain;
			public gov.nih.nci.cadsr.domain.ws.ValueDomainImpl getValueDomain(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setValueDomain(gov.nih.nci.cadsr.domain.ws.ValueDomainImpl valueDomain){
		this.valueDomain = valueDomain;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection parentDataElementRelationshipsCollection = new java.util.HashSet();
			public java.util.Collection getParentDataElementRelationshipsCollection(){
	              return parentDataElementRelationshipsCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setParentDataElementRelationshipsCollection(java.util.Collection parentDataElementRelationshipsCollection){
	   		this.parentDataElementRelationshipsCollection = parentDataElementRelationshipsCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection dataElementDerivationCollection = new java.util.HashSet();
			public java.util.Collection getDataElementDerivationCollection(){
	              return dataElementDerivationCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setDataElementDerivationCollection(java.util.Collection dataElementDerivationCollection){
	   		this.dataElementDerivationCollection = dataElementDerivationCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.DataElementConceptImpl dataElementConcept;
			public gov.nih.nci.cadsr.domain.ws.DataElementConceptImpl getDataElementConcept(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setDataElementConcept(gov.nih.nci.cadsr.domain.ws.DataElementConceptImpl dataElementConcept){
		this.dataElementConcept = dataElementConcept;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			private gov.nih.nci.cadsr.domain.ws.DerivedDataElementImpl derivedDataElement;
			public gov.nih.nci.cadsr.domain.ws.DerivedDataElementImpl getDerivedDataElement(){
			  return derivedDataElement;			
                        }
                        
	      
	               
	   
	   
	   
	   public void setDerivedDataElement(gov.nih.nci.cadsr.domain.ws.DerivedDataElementImpl derivedDataElement){
		this.derivedDataElement = derivedDataElement;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection childDataElementRelationshipsCollection = new java.util.HashSet();
			public java.util.Collection getChildDataElementRelationshipsCollection(){
	              return childDataElementRelationshipsCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setChildDataElementRelationshipsCollection(java.util.Collection childDataElementRelationshipsCollection){
	   		this.childDataElementRelationshipsCollection = childDataElementRelationshipsCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof DataElement) {
				DataElement c =(DataElement)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
