

package gov.nih.nci.cadsr.domain;


public interface NonenumeratedValueDomain 



    extends ValueDomain




{
	
	
	
}
