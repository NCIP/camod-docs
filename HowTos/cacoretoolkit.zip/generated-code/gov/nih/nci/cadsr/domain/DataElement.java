

package gov.nih.nci.cadsr.domain;


public interface DataElement 



    extends AdministeredComponent




{
	
	
	   
	   
	   
	      
	
	public java.util.Collection getQuestionCollection();
	      
		
	public void setQuestionCollection(java.util.Collection questionCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ValueDomain getValueDomain();
		  
		
	public void setValueDomain(gov.nih.nci.cadsr.domain.ValueDomain valueDomain);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getParentDataElementRelationshipsCollection();
	      
		
	public void setParentDataElementRelationshipsCollection(java.util.Collection parentDataElementRelationshipsCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDataElementDerivationCollection();
	      
		
	public void setDataElementDerivationCollection(java.util.Collection dataElementDerivationCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.DataElementConcept getDataElementConcept();
		  
		
	public void setDataElementConcept(gov.nih.nci.cadsr.domain.DataElementConcept dataElementConcept);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.DerivedDataElement getDerivedDataElement();
		  
		
	public void setDerivedDataElement(gov.nih.nci.cadsr.domain.DerivedDataElement derivedDataElement);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildDataElementRelationshipsCollection();
	      
		
	public void setChildDataElementRelationshipsCollection(java.util.Collection childDataElementRelationshipsCollection);
		
	   
	
	
}
