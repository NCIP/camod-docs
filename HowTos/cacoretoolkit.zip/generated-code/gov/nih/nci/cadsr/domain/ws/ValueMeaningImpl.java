

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ValueMeaningImpl 
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.String id;
	   public  java.lang.String getId(){
	      return id;
	   }
	   
	   public void setId( java.lang.String id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String shortMeaning;
	   public  java.lang.String getShortMeaning(){
	      return shortMeaning;
	   }
	   
	   public void setShortMeaning( java.lang.String shortMeaning){
	      this.shortMeaning = shortMeaning;
	   }
	
	   
	   public java.lang.String description;
	   public  java.lang.String getDescription(){
	      return description;
	   }
	   
	   public void setDescription( java.lang.String description){
	      this.description = description;
	   }
	
	   
	   public java.lang.String comments;
	   public  java.lang.String getComments(){
	      return comments;
	   }
	   
	   public void setComments( java.lang.String comments){
	      this.comments = comments;
	   }
	
	   
	   public java.util.Date beginDate;
	   public  java.util.Date getBeginDate(){
	      return beginDate;
	   }
	   
	   public void setBeginDate( java.util.Date beginDate){
	      this.beginDate = beginDate;
	   }
	
	   
	   public java.util.Date endDate;
	   public  java.util.Date getEndDate(){
	      return endDate;
	   }
	   
	   public void setEndDate( java.util.Date endDate){
	      this.endDate = endDate;
	   }
	
	   
	   public java.util.Date dateCreated;
	   public  java.util.Date getDateCreated(){
	      return dateCreated;
	   }
	   
	   public void setDateCreated( java.util.Date dateCreated){
	      this.dateCreated = dateCreated;
	   }
	
	   
	   public java.util.Date dateModified;
	   public  java.util.Date getDateModified(){
	      return dateModified;
	   }
	   
	   public void setDateModified( java.util.Date dateModified){
	      this.dateModified = dateModified;
	   }
	
	   
	   public java.lang.String createdBy;
	   public  java.lang.String getCreatedBy(){
	      return createdBy;
	   }
	   
	   public void setCreatedBy( java.lang.String createdBy){
	      this.createdBy = createdBy;
	   }
	
	   
	   public java.lang.String modifiedBy;
	   public  java.lang.String getModifiedBy(){
	      return modifiedBy;
	   }
	   
	   public void setModifiedBy( java.lang.String modifiedBy){
	      this.modifiedBy = modifiedBy;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection permissableValueCollection = new java.util.HashSet();
			public java.util.Collection getPermissableValueCollection(){
	              return permissableValueCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setPermissableValueCollection(java.util.Collection permissableValueCollection){
	   		this.permissableValueCollection = permissableValueCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ConceptDerivationRuleImpl conceptDerivationRule;
			public gov.nih.nci.cadsr.domain.ws.ConceptDerivationRuleImpl getConceptDerivationRule(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ws.ConceptDerivationRuleImpl conceptDerivationRule){
		this.conceptDerivationRule = conceptDerivationRule;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection conceptualDomainCollection = new java.util.HashSet();
			public java.util.Collection getConceptualDomainCollection(){
	              return conceptualDomainCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setConceptualDomainCollection(java.util.Collection conceptualDomainCollection){
	   		this.conceptualDomainCollection = conceptualDomainCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ValueMeaning) {
				ValueMeaning c =(ValueMeaning)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
