

package gov.nih.nci.cadsr.domain;


public interface ClassificationScheme 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getLabelTypeFlag();
	   public void setLabelTypeFlag( java.lang.String labelTypeFlag);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getClassSchemeClassSchemeItemCollection();
	      
		
	public void setClassSchemeClassSchemeItemCollection(java.util.Collection classSchemeClassSchemeItemCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getParentClassificationSchemeRelationshipCollection();
	      
		
	public void setParentClassificationSchemeRelationshipCollection(java.util.Collection parentClassificationSchemeRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildClassificationSchemeRelationshipCollection();
	      
		
	public void setChildClassificationSchemeRelationshipCollection(java.util.Collection childClassificationSchemeRelationshipCollection);
		
	   
	
	
}
