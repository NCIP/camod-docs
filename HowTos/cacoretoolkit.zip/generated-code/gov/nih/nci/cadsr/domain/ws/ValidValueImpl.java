

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ValidValueImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Integer displayOrder;
	   public  java.lang.Integer getDisplayOrder(){
	      return displayOrder;
	   }
	   
	   public void setDisplayOrder( java.lang.Integer displayOrder){
	      this.displayOrder = displayOrder;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.QuestionImpl question;
			public gov.nih.nci.cadsr.domain.ws.QuestionImpl getQuestion(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setQuestion(gov.nih.nci.cadsr.domain.ws.QuestionImpl question){
		this.question = question;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ValueDomainPermissibleValueImpl valueDomainPermissibleValue;
			public gov.nih.nci.cadsr.domain.ws.ValueDomainPermissibleValueImpl getValueDomainPermissibleValue(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setValueDomainPermissibleValue(gov.nih.nci.cadsr.domain.ws.ValueDomainPermissibleValueImpl valueDomainPermissibleValue){
		this.valueDomainPermissibleValue = valueDomainPermissibleValue;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
	              return instructionCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ValidValue) {
				ValidValue c =(ValidValue)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
