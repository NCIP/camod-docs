

package gov.nih.nci.cadsr.domain;


public interface Module 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.Integer getDisplayOrder();
	   public void setDisplayOrder( java.lang.Integer displayOrder);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.CaseReportForm getCaseReportForm();
		  
		
	public void setCaseReportForm(gov.nih.nci.cadsr.domain.CaseReportForm caseReportForm);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getQuestionCollection();
	      
		
	public void setQuestionCollection(java.util.Collection questionCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getInstructionCollection();
	      
		
	public void setInstructionCollection(java.util.Collection instructionCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ProtocolFormsTemplate getProtocolFormsTemplate();
		  
		
	public void setProtocolFormsTemplate(gov.nih.nci.cadsr.domain.ProtocolFormsTemplate protocolFormsTemplate);
		
	
	   
	
	
}
