

package gov.nih.nci.cadsr.domain;


public interface ConceptualDomain 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getDimensionality();
	   public void setDimensionality( java.lang.String dimensionality);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getValueMeaningCollection();
	      
		
	public void setValueMeaningCollection(java.util.Collection valueMeaningCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getValueDomainCollection();
	      
		
	public void setValueDomainCollection(java.util.Collection valueDomainCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDataElementConceptCollection();
	      
		
	public void setDataElementConceptCollection(java.util.Collection dataElementConceptCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule();
		  
		
	public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule);
		
	
	   
	
	
}
