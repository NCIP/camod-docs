

package gov.nih.nci.cadsr.domain;


public interface Question 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.Integer getDisplayOrder();
	   public void setDisplayOrder( java.lang.Integer displayOrder);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.DataElement getDataElement();
		  
		
	public void setDataElement(gov.nih.nci.cadsr.domain.DataElement dataElement);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ValueDomain getValueDomain();
		  
		
	public void setValueDomain(gov.nih.nci.cadsr.domain.ValueDomain valueDomain);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getValidValueCollection();
	      
		
	public void setValidValueCollection(java.util.Collection validValueCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getInstructionCollection();
	      
		
	public void setInstructionCollection(java.util.Collection instructionCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Module getModule();
		  
		
	public void setModule(gov.nih.nci.cadsr.domain.Module module);
		
	
	   
	
	
}
