

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class DefinitionImpl
	implements java.io.Serializable, Definition
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String id;
	   public  java.lang.String getId(){
	      return id;
	   }
	   public void setId( java.lang.String id){
	      this.id = id;
	   }


	   public java.lang.String text;
	   public  java.lang.String getText(){
	      return text;
	   }
	   public void setText( java.lang.String text){
	      this.text = text;
	   }


	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }


	   public java.lang.String languageName;
	   public  java.lang.String getLanguageName(){
	      return languageName;
	   }
	   public void setLanguageName( java.lang.String languageName){
	      this.languageName = languageName;
	   }


	   public java.util.Date dateCreated;
	   public  java.util.Date getDateCreated(){
	      return dateCreated;
	   }
	   public void setDateCreated( java.util.Date dateCreated){
	      this.dateCreated = dateCreated;
	   }


	   public java.util.Date dateModified;
	   public  java.util.Date getDateModified(){
	      return dateModified;
	   }
	   public void setDateModified( java.util.Date dateModified){
	      this.dateModified = dateModified;
	   }


	   public java.lang.String createdBy;
	   public  java.lang.String getCreatedBy(){
	      return createdBy;
	   }
	   public void setCreatedBy( java.lang.String createdBy){
	      this.createdBy = createdBy;
	   }


	   public java.lang.String modifiedBy;
	   public  java.lang.String getModifiedBy(){
	      return modifiedBy;
	   }
	   public void setModifiedBy( java.lang.String modifiedBy){
	      this.modifiedBy = modifiedBy;
	   }











			private gov.nih.nci.cadsr.domain.Context context;
			public gov.nih.nci.cadsr.domain.Context getContext(){
			  return context;
                        }






	   public void setContext(gov.nih.nci.cadsr.domain.Context context){
		this.context = context;
	   }







			private java.util.Collection definitionClassSchemeItemCollection = new java.util.HashSet();
			public java.util.Collection getDefinitionClassSchemeItemCollection(){
			try{
			   if(definitionClassSchemeItemCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Definition thisIdSet = new gov.nih.nci.cadsr.domain.impl.DefinitionImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DefinitionClassSchemeItem", thisIdSet);
				 	definitionClassSchemeItemCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Definition:getDefinitionClassSchemeItemCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return definitionClassSchemeItemCollection;
	          }








	   	public void setDefinitionClassSchemeItemCollection(java.util.Collection definitionClassSchemeItemCollection){
	   		this.definitionClassSchemeItemCollection = definitionClassSchemeItemCollection;
	        }











			private gov.nih.nci.cadsr.domain.AdministeredComponent administeredComponent;
			public gov.nih.nci.cadsr.domain.AdministeredComponent getAdministeredComponent(){
			  return administeredComponent;
                        }






	   public void setAdministeredComponent(gov.nih.nci.cadsr.domain.AdministeredComponent administeredComponent){
		this.administeredComponent = administeredComponent;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Definition) {
				Definition c =(Definition)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}