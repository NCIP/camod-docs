

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ValidValueImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, ValidValue
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.Integer displayOrder;
	   public  java.lang.Integer getDisplayOrder(){
	      return displayOrder;
	   }
	   public void setDisplayOrder( java.lang.Integer displayOrder){
	      this.displayOrder = displayOrder;
	   }











			private gov.nih.nci.cadsr.domain.Question question;
			public gov.nih.nci.cadsr.domain.Question getQuestion(){
			  return question;
                        }






	   public void setQuestion(gov.nih.nci.cadsr.domain.Question question){
		this.question = question;
	   }











			private gov.nih.nci.cadsr.domain.ValueDomainPermissibleValue valueDomainPermissibleValue;
			public gov.nih.nci.cadsr.domain.ValueDomainPermissibleValue getValueDomainPermissibleValue(){
			  return valueDomainPermissibleValue;
                        }






	   public void setValueDomainPermissibleValue(gov.nih.nci.cadsr.domain.ValueDomainPermissibleValue valueDomainPermissibleValue){
		this.valueDomainPermissibleValue = valueDomainPermissibleValue;
	   }







			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
			try{
			   if(instructionCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ValidValue thisIdSet = new gov.nih.nci.cadsr.domain.impl.ValidValueImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Instruction", thisIdSet);
				 	instructionCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ValidValue:getInstructionCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return instructionCollection;
	          }








	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ValidValue) {
				ValidValue c =(ValidValue)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}