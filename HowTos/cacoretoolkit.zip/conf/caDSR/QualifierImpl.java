

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class QualifierImpl
	implements java.io.Serializable, Qualifier
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String id;
	   public  java.lang.String getId(){
	      return id;
	   }
	   public void setId( java.lang.String id){
	      this.id = id;
	   }


	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }


	   public java.lang.String description;
	   public  java.lang.String getDescription(){
	      return description;
	   }
	   public void setDescription( java.lang.String description){
	      this.description = description;
	   }


	   public java.lang.String comments;
	   public  java.lang.String getComments(){
	      return comments;
	   }
	   public void setComments( java.lang.String comments){
	      this.comments = comments;
	   }


	   public java.util.Date dateCreated;
	   public  java.util.Date getDateCreated(){
	      return dateCreated;
	   }
	   public void setDateCreated( java.util.Date dateCreated){
	      this.dateCreated = dateCreated;
	   }


	   public java.util.Date dateModified;
	   public  java.util.Date getDateModified(){
	      return dateModified;
	   }
	   public void setDateModified( java.util.Date dateModified){
	      this.dateModified = dateModified;
	   }


	   public java.lang.String createdBy;
	   public  java.lang.String getCreatedBy(){
	      return createdBy;
	   }
	   public void setCreatedBy( java.lang.String createdBy){
	      this.createdBy = createdBy;
	   }


	   public java.lang.String modifiedBy;
	   public  java.lang.String getModifiedBy(){
	      return modifiedBy;
	   }
	   public void setModifiedBy( java.lang.String modifiedBy){
	      this.modifiedBy = modifiedBy;
	   }







			private java.util.Collection DECPropertyCollection = new java.util.HashSet();
			public java.util.Collection getDECPropertyCollection(){
			try{
			   if(DECPropertyCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Qualifier thisIdSet = new gov.nih.nci.cadsr.domain.impl.QualifierImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementConcept", thisIdSet);
				 	DECPropertyCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Qualifier:getDECPropertyCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return DECPropertyCollection;
	          }








	   	public void setDECPropertyCollection(java.util.Collection DECPropertyCollection){
	   		this.DECPropertyCollection = DECPropertyCollection;
	        }







			private java.util.Collection DECObjectClassCollection = new java.util.HashSet();
			public java.util.Collection getDECObjectClassCollection(){
			try{
			   if(DECObjectClassCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Qualifier thisIdSet = new gov.nih.nci.cadsr.domain.impl.QualifierImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementConcept", thisIdSet);
				 	DECObjectClassCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Qualifier:getDECObjectClassCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return DECObjectClassCollection;
	          }








	   	public void setDECObjectClassCollection(java.util.Collection DECObjectClassCollection){
	   		this.DECObjectClassCollection = DECObjectClassCollection;
	        }







			private java.util.Collection VDRepresentationCollection = new java.util.HashSet();
			public java.util.Collection getVDRepresentationCollection(){
			try{
			   if(VDRepresentationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Qualifier thisIdSet = new gov.nih.nci.cadsr.domain.impl.QualifierImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ValueDomain", thisIdSet);
				 	VDRepresentationCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Qualifier:getVDRepresentationCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return VDRepresentationCollection;
	          }








	   	public void setVDRepresentationCollection(java.util.Collection VDRepresentationCollection){
	   		this.VDRepresentationCollection = VDRepresentationCollection;
	        }











			private gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule;
			public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule(){
			  return conceptDerivationRule;
                        }






	   public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule){
		this.conceptDerivationRule = conceptDerivationRule;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Qualifier) {
				Qualifier c =(Qualifier)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}