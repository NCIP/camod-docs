

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ProtocolFormsTemplateImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable, ProtocolFormsTemplate 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.String displayName;
	   public  java.lang.String getDisplayName(){
	      return displayName;
	   }
	   public void setDisplayName( java.lang.String displayName){
	      this.displayName = displayName;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
			try{
			   if(instructionCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cadsr.domain.ProtocolFormsTemplate thisIdSet = new gov.nih.nci.cadsr.domain.impl.ProtocolFormsTemplateImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Instruction", thisIdSet);				 
				 	instructionCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("ProtocolFormsTemplate:getInstructionCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return instructionCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection moduleCollection = new java.util.HashSet();
			public java.util.Collection getModuleCollection(){
			try{
			   if(moduleCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cadsr.domain.ProtocolFormsTemplate thisIdSet = new gov.nih.nci.cadsr.domain.impl.ProtocolFormsTemplateImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Module", thisIdSet);				 
				 	moduleCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("ProtocolFormsTemplate:getModuleCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return moduleCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setModuleCollection(java.util.Collection moduleCollection){
	   		this.moduleCollection = moduleCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ProtocolFormsTemplate) {
				ProtocolFormsTemplate c =(ProtocolFormsTemplate)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}