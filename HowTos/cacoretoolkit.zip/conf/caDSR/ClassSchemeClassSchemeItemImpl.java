

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ClassSchemeClassSchemeItemImpl
	implements java.io.Serializable, ClassSchemeClassSchemeItem
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String id;
	   public  java.lang.String getId(){
	      return id;
	   }
	   public void setId( java.lang.String id){
	      this.id = id;
	   }


	   public java.lang.Integer displayOrder;
	   public  java.lang.Integer getDisplayOrder(){
	      return displayOrder;
	   }
	   public void setDisplayOrder( java.lang.Integer displayOrder){
	      this.displayOrder = displayOrder;
	   }


	   public java.util.Date dateCreated;
	   public  java.util.Date getDateCreated(){
	      return dateCreated;
	   }
	   public void setDateCreated( java.util.Date dateCreated){
	      this.dateCreated = dateCreated;
	   }


	   public java.util.Date dateModified;
	   public  java.util.Date getDateModified(){
	      return dateModified;
	   }
	   public void setDateModified( java.util.Date dateModified){
	      this.dateModified = dateModified;
	   }


	   public java.lang.String createdBy;
	   public  java.lang.String getCreatedBy(){
	      return createdBy;
	   }
	   public void setCreatedBy( java.lang.String createdBy){
	      this.createdBy = createdBy;
	   }


	   public java.lang.String modifiedBy;
	   public  java.lang.String getModifiedBy(){
	      return modifiedBy;
	   }
	   public void setModifiedBy( java.lang.String modifiedBy){
	      this.modifiedBy = modifiedBy;
	   }











			private gov.nih.nci.cadsr.domain.ClassificationScheme classificationScheme;
			public gov.nih.nci.cadsr.domain.ClassificationScheme getClassificationScheme(){
			  return classificationScheme;
                        }






	   public void setClassificationScheme(gov.nih.nci.cadsr.domain.ClassificationScheme classificationScheme){
		this.classificationScheme = classificationScheme;
	   }







			private java.util.Collection administeredComponentClassSchemeItemCollection = new java.util.HashSet();
			public java.util.Collection getAdministeredComponentClassSchemeItemCollection(){
			try{
			   if(administeredComponentClassSchemeItemCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem thisIdSet = new gov.nih.nci.cadsr.domain.impl.ClassSchemeClassSchemeItemImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.AdministeredComponentClassSchemeItem", thisIdSet);
				 	administeredComponentClassSchemeItemCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ClassSchemeClassSchemeItem:getAdministeredComponentClassSchemeItemCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return administeredComponentClassSchemeItemCollection;
	          }








	   	public void setAdministeredComponentClassSchemeItemCollection(java.util.Collection administeredComponentClassSchemeItemCollection){
	   		this.administeredComponentClassSchemeItemCollection = administeredComponentClassSchemeItemCollection;
	        }











			private gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem parentClassSchemeClassSchemeItem;
			public gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem getParentClassSchemeClassSchemeItem(){
			  return parentClassSchemeClassSchemeItem;
                        }






	   public void setParentClassSchemeClassSchemeItem(gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem parentClassSchemeClassSchemeItem){
		this.parentClassSchemeClassSchemeItem = parentClassSchemeClassSchemeItem;
	   }







			private java.util.Collection definitionClassSchemeItemCollection = new java.util.HashSet();
			public java.util.Collection getDefinitionClassSchemeItemCollection(){
			try{
			   if(definitionClassSchemeItemCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem thisIdSet = new gov.nih.nci.cadsr.domain.impl.ClassSchemeClassSchemeItemImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DefinitionClassSchemeItem", thisIdSet);
				 	definitionClassSchemeItemCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ClassSchemeClassSchemeItem:getDefinitionClassSchemeItemCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return definitionClassSchemeItemCollection;
	          }








	   	public void setDefinitionClassSchemeItemCollection(java.util.Collection definitionClassSchemeItemCollection){
	   		this.definitionClassSchemeItemCollection = definitionClassSchemeItemCollection;
	        }











			private gov.nih.nci.cadsr.domain.ClassificationSchemeItem classificationSchemeItem;
			public gov.nih.nci.cadsr.domain.ClassificationSchemeItem getClassificationSchemeItem(){
			  return classificationSchemeItem;
                        }






	   public void setClassificationSchemeItem(gov.nih.nci.cadsr.domain.ClassificationSchemeItem classificationSchemeItem){
		this.classificationSchemeItem = classificationSchemeItem;
	   }







			private java.util.Collection designationClassSchemeItemCollection = new java.util.HashSet();
			public java.util.Collection getDesignationClassSchemeItemCollection(){
			try{
			   if(designationClassSchemeItemCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem thisIdSet = new gov.nih.nci.cadsr.domain.impl.ClassSchemeClassSchemeItemImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DesignationClassSchemeItem", thisIdSet);
				 	designationClassSchemeItemCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ClassSchemeClassSchemeItem:getDesignationClassSchemeItemCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return designationClassSchemeItemCollection;
	          }








	   	public void setDesignationClassSchemeItemCollection(java.util.Collection designationClassSchemeItemCollection){
	   		this.designationClassSchemeItemCollection = designationClassSchemeItemCollection;
	        }







			private java.util.Collection childClassSchemeClassSchemeItemCollection = new java.util.HashSet();
			public java.util.Collection getChildClassSchemeClassSchemeItemCollection(){
			try{
			   if(childClassSchemeClassSchemeItemCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem thisIdSet = new gov.nih.nci.cadsr.domain.impl.ClassSchemeClassSchemeItemImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem", thisIdSet);
				 	childClassSchemeClassSchemeItemCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ClassSchemeClassSchemeItem:getChildClassSchemeClassSchemeItemCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return childClassSchemeClassSchemeItemCollection;
	          }








	   	public void setChildClassSchemeClassSchemeItemCollection(java.util.Collection childClassSchemeClassSchemeItemCollection){
	   		this.childClassSchemeClassSchemeItemCollection = childClassSchemeClassSchemeItemCollection;
	        }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ClassSchemeClassSchemeItem) {
				ClassSchemeClassSchemeItem c =(ClassSchemeClassSchemeItem)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}