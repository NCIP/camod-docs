

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ClassificationSchemeImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable, ClassificationScheme 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	
	   
	   public java.lang.String labelTypeFlag;
	   public  java.lang.String getLabelTypeFlag(){
	      return labelTypeFlag;
	   }
	   public void setLabelTypeFlag( java.lang.String labelTypeFlag){
	      this.labelTypeFlag = labelTypeFlag;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection classSchemeClassSchemeItemCollection = new java.util.HashSet();
			public java.util.Collection getClassSchemeClassSchemeItemCollection(){
			try{
			   if(classSchemeClassSchemeItemCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cadsr.domain.ClassificationScheme thisIdSet = new gov.nih.nci.cadsr.domain.impl.ClassificationSchemeImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem", thisIdSet);				 
				 	classSchemeClassSchemeItemCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("ClassificationScheme:getClassSchemeClassSchemeItemCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return classSchemeClassSchemeItemCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setClassSchemeClassSchemeItemCollection(java.util.Collection classSchemeClassSchemeItemCollection){
	   		this.classSchemeClassSchemeItemCollection = classSchemeClassSchemeItemCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection parentClassificationSchemeRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getParentClassificationSchemeRelationshipCollection(){
			try{
			   if(parentClassificationSchemeRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cadsr.domain.ClassificationScheme thisIdSet = new gov.nih.nci.cadsr.domain.impl.ClassificationSchemeImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ClassificationSchemeRelationship", thisIdSet);				 
				 	parentClassificationSchemeRelationshipCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("ClassificationScheme:getParentClassificationSchemeRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return parentClassificationSchemeRelationshipCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setParentClassificationSchemeRelationshipCollection(java.util.Collection parentClassificationSchemeRelationshipCollection){
	   		this.parentClassificationSchemeRelationshipCollection = parentClassificationSchemeRelationshipCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection childClassificationSchemeRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getChildClassificationSchemeRelationshipCollection(){
			try{
			   if(childClassificationSchemeRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cadsr.domain.ClassificationScheme thisIdSet = new gov.nih.nci.cadsr.domain.impl.ClassificationSchemeImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ClassificationSchemeRelationship", thisIdSet);				 
				 	childClassificationSchemeRelationshipCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("ClassificationScheme:getChildClassificationSchemeRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return childClassificationSchemeRelationshipCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setChildClassificationSchemeRelationshipCollection(java.util.Collection childClassificationSchemeRelationshipCollection){
	   		this.childClassificationSchemeRelationshipCollection = childClassificationSchemeRelationshipCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ClassificationScheme) {
				ClassificationScheme c =(ClassificationScheme)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}