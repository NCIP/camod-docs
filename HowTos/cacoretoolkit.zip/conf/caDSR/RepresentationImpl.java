

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class RepresentationImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, Representation
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String definitionSource;
	   public  java.lang.String getDefinitionSource(){
	      return definitionSource;
	   }
	   public void setDefinitionSource( java.lang.String definitionSource){
	      this.definitionSource = definitionSource;
	   }







			private java.util.Collection valueDomainCollection = new java.util.HashSet();
			public java.util.Collection getValueDomainCollection(){
			try{
			   if(valueDomainCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Representation thisIdSet = new gov.nih.nci.cadsr.domain.impl.RepresentationImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ValueDomain", thisIdSet);
				 	valueDomainCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Representation:getValueDomainCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return valueDomainCollection;
	          }








	   	public void setValueDomainCollection(java.util.Collection valueDomainCollection){
	   		this.valueDomainCollection = valueDomainCollection;
	        }











			private gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule;
			public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule(){
			  return conceptDerivationRule;
                        }






	   public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule){
		this.conceptDerivationRule = conceptDerivationRule;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Representation) {
				Representation c =(Representation)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}