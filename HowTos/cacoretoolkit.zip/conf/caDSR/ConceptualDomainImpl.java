

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ConceptualDomainImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, ConceptualDomain
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String dimensionality;
	   public  java.lang.String getDimensionality(){
	      return dimensionality;
	   }
	   public void setDimensionality( java.lang.String dimensionality){
	      this.dimensionality = dimensionality;
	   }







			private java.util.Collection valueMeaningCollection = new java.util.HashSet();
			public java.util.Collection getValueMeaningCollection(){
			try{
			   if(valueMeaningCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ConceptualDomain thisIdSet = new gov.nih.nci.cadsr.domain.impl.ConceptualDomainImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ValueMeaning", thisIdSet);
				 	valueMeaningCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ConceptualDomain:getValueMeaningCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return valueMeaningCollection;
	          }








	   	public void setValueMeaningCollection(java.util.Collection valueMeaningCollection){
	   		this.valueMeaningCollection = valueMeaningCollection;
	        }







			private java.util.Collection valueDomainCollection = new java.util.HashSet();
			public java.util.Collection getValueDomainCollection(){
			try{
			   if(valueDomainCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ConceptualDomain thisIdSet = new gov.nih.nci.cadsr.domain.impl.ConceptualDomainImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ValueDomain", thisIdSet);
				 	valueDomainCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ConceptualDomain:getValueDomainCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return valueDomainCollection;
	          }








	   	public void setValueDomainCollection(java.util.Collection valueDomainCollection){
	   		this.valueDomainCollection = valueDomainCollection;
	        }







			private java.util.Collection dataElementConceptCollection = new java.util.HashSet();
			public java.util.Collection getDataElementConceptCollection(){
			try{
			   if(dataElementConceptCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ConceptualDomain thisIdSet = new gov.nih.nci.cadsr.domain.impl.ConceptualDomainImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementConcept", thisIdSet);
				 	dataElementConceptCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ConceptualDomain:getDataElementConceptCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return dataElementConceptCollection;
	          }








	   	public void setDataElementConceptCollection(java.util.Collection dataElementConceptCollection){
	   		this.dataElementConceptCollection = dataElementConceptCollection;
	        }











			private gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule;
			public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule(){
			  return conceptDerivationRule;
                        }






	   public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule){
		this.conceptDerivationRule = conceptDerivationRule;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ConceptualDomain) {
				ConceptualDomain c =(ConceptualDomain)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}