

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class DataElementImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, DataElement
{
	private static final long serialVersionUID = 1234567890L;








			private java.util.Collection questionCollection = new java.util.HashSet();
			public java.util.Collection getQuestionCollection(){
			try{
			   if(questionCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.DataElement thisIdSet = new gov.nih.nci.cadsr.domain.impl.DataElementImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Question", thisIdSet);
				 	questionCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("DataElement:getQuestionCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return questionCollection;
	          }








	   	public void setQuestionCollection(java.util.Collection questionCollection){
	   		this.questionCollection = questionCollection;
	        }











			private gov.nih.nci.cadsr.domain.ValueDomain valueDomain;
			public gov.nih.nci.cadsr.domain.ValueDomain getValueDomain(){
			  return valueDomain;
                        }






	   public void setValueDomain(gov.nih.nci.cadsr.domain.ValueDomain valueDomain){
		this.valueDomain = valueDomain;
	   }







			private java.util.Collection parentDataElementRelationshipsCollection = new java.util.HashSet();
			public java.util.Collection getParentDataElementRelationshipsCollection(){
			try{
			   if(parentDataElementRelationshipsCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.DataElement thisIdSet = new gov.nih.nci.cadsr.domain.impl.DataElementImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementRelationship", thisIdSet);
				 	parentDataElementRelationshipsCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("DataElement:getParentDataElementRelationshipsCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return parentDataElementRelationshipsCollection;
	          }








	   	public void setParentDataElementRelationshipsCollection(java.util.Collection parentDataElementRelationshipsCollection){
	   		this.parentDataElementRelationshipsCollection = parentDataElementRelationshipsCollection;
	        }







			private java.util.Collection dataElementDerivationCollection = new java.util.HashSet();
			public java.util.Collection getDataElementDerivationCollection(){
			try{
			   if(dataElementDerivationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.DataElement thisIdSet = new gov.nih.nci.cadsr.domain.impl.DataElementImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementDerivation", thisIdSet);
				 	dataElementDerivationCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("DataElement:getDataElementDerivationCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return dataElementDerivationCollection;
	          }








	   	public void setDataElementDerivationCollection(java.util.Collection dataElementDerivationCollection){
	   		this.dataElementDerivationCollection = dataElementDerivationCollection;
	        }











			private gov.nih.nci.cadsr.domain.DataElementConcept dataElementConcept;
			public gov.nih.nci.cadsr.domain.DataElementConcept getDataElementConcept(){
			  return dataElementConcept;
                        }






	   public void setDataElementConcept(gov.nih.nci.cadsr.domain.DataElementConcept dataElementConcept){
		this.dataElementConcept = dataElementConcept;
	   }









			private gov.nih.nci.cadsr.domain.DerivedDataElement derivedDataElement;
			public gov.nih.nci.cadsr.domain.DerivedDataElement getDerivedDataElement(){
			  return derivedDataElement;
                        }






	   public void setDerivedDataElement(gov.nih.nci.cadsr.domain.DerivedDataElement derivedDataElement){
		this.derivedDataElement = derivedDataElement;
	   }







			private java.util.Collection childDataElementRelationshipsCollection = new java.util.HashSet();
			public java.util.Collection getChildDataElementRelationshipsCollection(){
			try{
			   if(childDataElementRelationshipsCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.DataElement thisIdSet = new gov.nih.nci.cadsr.domain.impl.DataElementImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementRelationship", thisIdSet);
				 	childDataElementRelationshipsCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("DataElement:getChildDataElementRelationshipsCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return childDataElementRelationshipsCollection;
	          }








	   	public void setChildDataElementRelationshipsCollection(java.util.Collection childDataElementRelationshipsCollection){
	   		this.childDataElementRelationshipsCollection = childDataElementRelationshipsCollection;
	        }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof DataElement) {
				DataElement c =(DataElement)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}