

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class GeneImpl
	implements java.io.Serializable, Gene
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }


	   public java.lang.String fullName;
	   public  java.lang.String getFullName(){
	      return fullName;
	   }
	   public void setFullName( java.lang.String fullName){
	      this.fullName = fullName;
	   }


	   public java.lang.Long clusterId;
	   public  java.lang.Long getClusterId(){
	      return clusterId;
	   }
	   public void setClusterId( java.lang.Long clusterId){
	      this.clusterId = clusterId;
	   }


	   public java.lang.String symbol;
	   public  java.lang.String getSymbol(){
	      return symbol;
	   }
	   public void setSymbol( java.lang.String symbol){
	      this.symbol = symbol;
	   }









private gov.nih.nci.cabio.domain.Taxon taxon ;
public gov.nih.nci.cabio.domain.Taxon getTaxon(){

              ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			  thisIdSet.setId(this.getId());

			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Taxon", thisIdSet);
		             if (resultList!=null && resultList.size()>0) {
		                taxon = (gov.nih.nci.cabio.domain.Taxon)resultList.get(0);
		             }

			  } catch(Exception ex) { }

	          return taxon;
	       }


	   public void setTaxon(gov.nih.nci.cabio.domain.Taxon taxon){
		this.taxon = taxon;
	   }







			private java.util.Collection pathwayCollection = new java.util.HashSet();
			public java.util.Collection getPathwayCollection(){
			try{
			   if(pathwayCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Pathway", thisIdSet);
				 pathwayCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return pathwayCollection;
	                }

	   	public void setPathwayCollection(java.util.Collection pathwayCollection){
	   		this.pathwayCollection = pathwayCollection;
	        }







			private java.util.Collection expressionFeatureCollection = new java.util.HashSet();
			public java.util.Collection getExpressionFeatureCollection(){
			try{
			   if(expressionFeatureCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.camod.domain.ExpressionFeature", thisIdSet);
				 expressionFeatureCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return expressionFeatureCollection;
	                }

	   	public void setExpressionFeatureCollection(java.util.Collection expressionFeatureCollection){
	   		this.expressionFeatureCollection = expressionFeatureCollection;
	        }







			private java.util.Collection nucleicAcidSequenceCollection = new java.util.HashSet();
			public java.util.Collection getNucleicAcidSequenceCollection(){
			try{
			   if(nucleicAcidSequenceCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.NucleicAcidSequence", thisIdSet);
				 nucleicAcidSequenceCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return nucleicAcidSequenceCollection;
	                }

	   	public void setNucleicAcidSequenceCollection(java.util.Collection nucleicAcidSequenceCollection){
	   		this.nucleicAcidSequenceCollection = nucleicAcidSequenceCollection;
	        }







			private java.util.Collection locationCollection = new java.util.HashSet();
			public java.util.Collection getLocationCollection(){
			try{
			   if(locationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Location", thisIdSet);
				 locationCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return locationCollection;
	                }

	   	public void setLocationCollection(java.util.Collection locationCollection){
	   		this.locationCollection = locationCollection;
	        }







			private java.util.Collection homologousAssociationCollection = new java.util.HashSet();
			public java.util.Collection getHomologousAssociationCollection(){
			try{
			   if(homologousAssociationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.HomologousAssociation", thisIdSet);
				 homologousAssociationCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return homologousAssociationCollection;
	                }

	   	public void setHomologousAssociationCollection(java.util.Collection homologousAssociationCollection){
	   		this.homologousAssociationCollection = homologousAssociationCollection;
	        }







			private java.util.Collection geneRelativeLocationCollection = new java.util.HashSet();
			public java.util.Collection getGeneRelativeLocationCollection(){
			try{
			   if(geneRelativeLocationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneRelativeLocation", thisIdSet);
				 geneRelativeLocationCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return geneRelativeLocationCollection;
	                }

	   	public void setGeneRelativeLocationCollection(java.util.Collection geneRelativeLocationCollection){
	   		this.geneRelativeLocationCollection = geneRelativeLocationCollection;
	        }













			private java.util.Collection genericReporterCollection = new java.util.HashSet();
			public java.util.Collection getGenericReporterCollection(){
			try{
			   if(genericReporterCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.GenericReporter", thisIdSet);
				 genericReporterCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return genericReporterCollection;
	                }

	   	public void setGenericReporterCollection(java.util.Collection genericReporterCollection){
	   		this.genericReporterCollection = genericReporterCollection;
	        }







			private java.util.Collection databaseCrossReferenceCollection = new java.util.HashSet();
			public java.util.Collection getDatabaseCrossReferenceCollection(){
			try{
			   if(databaseCrossReferenceCollection.size() == 0) {}
		     } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 		gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.List resultList = applicationService.search("gov.nih.nci.common.domain.DatabaseCrossReference", thisIdSet);
				 		databaseCrossReferenceCollection = resultList;
				  		java.util.List resultList1 = new ArrayList();
						 for(int i = 0; i < resultList.size(); i++)
						 {
							 gov.nih.nci.common.domain.DatabaseCrossReference db = (gov.nih.nci.common.domain.DatabaseCrossReference)resultList.get(i);
							 String type = db.getType().trim();
							 if(type.equalsIgnoreCase("gov.nih.nci.cabio.domain.GENE"))
								 resultList1.add(resultList.get(i));
						 }

						 //System.out.println("size = " + resultList1.size());
						 return resultList1;



			      }catch(Exception ex) { }
			   }

	                return databaseCrossReferenceCollection;
	                }

	   	public void setDatabaseCrossReferenceCollection(java.util.Collection databaseCrossReferenceCollection){
	   		this.databaseCrossReferenceCollection = databaseCrossReferenceCollection;
	        }













			private java.util.Collection libraryCollection = new java.util.HashSet();
			public java.util.Collection getLibraryCollection(){
			try{
			   if(libraryCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Library", thisIdSet);
				 libraryCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return libraryCollection;
	                }

	   	public void setLibraryCollection(java.util.Collection libraryCollection){
	   		this.libraryCollection = libraryCollection;
	        }









private gov.nih.nci.cabio.domain.Chromosome chromosome ;
public gov.nih.nci.cabio.domain.Chromosome getChromosome(){

              ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			  thisIdSet.setId(this.getId());

			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Chromosome", thisIdSet);
		             if (resultList!=null && resultList.size()>0) {
		                chromosome = (gov.nih.nci.cabio.domain.Chromosome)resultList.get(0);
		             }

			  } catch(Exception ex) { }
	       return chromosome;
	  }



	   public void setChromosome(gov.nih.nci.cabio.domain.Chromosome chromosome){
		this.chromosome = chromosome;
	   }







			private java.util.Collection histopathologyCollection = new java.util.HashSet();
			public java.util.Collection getHistopathologyCollection(){
			try{
			   if(histopathologyCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Histopathology", thisIdSet);
				 histopathologyCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return histopathologyCollection;
	                }

	   	public void setHistopathologyCollection(java.util.Collection histopathologyCollection){
	   		this.histopathologyCollection = histopathologyCollection;
	        }







			private java.util.Collection geneAliasCollection = new java.util.HashSet();
			public java.util.Collection getGeneAliasCollection(){
			try{
			   if(geneAliasCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneAlias", thisIdSet);
				 geneAliasCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return geneAliasCollection;
	                }

	   	public void setGeneAliasCollection(java.util.Collection geneAliasCollection){
	   		this.geneAliasCollection = geneAliasCollection;
	        }







			private java.util.Collection organOntologyCollection = new java.util.HashSet();
			public java.util.Collection getOrganOntologyCollection(){
			try{
			   if(organOntologyCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.OrganOntology", thisIdSet);
				 organOntologyCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return organOntologyCollection;
	                }

	   	public void setOrganOntologyCollection(java.util.Collection organOntologyCollection){
	   		this.organOntologyCollection = organOntologyCollection;
	        }







			private java.util.Collection proteinCollection = new java.util.HashSet();
			public java.util.Collection getProteinCollection(){
			try{
			   if(proteinCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Protein", thisIdSet);
				 proteinCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return proteinCollection;
	                }

	   	public void setProteinCollection(java.util.Collection proteinCollection){
	   		this.proteinCollection = proteinCollection;
	        }







			private java.util.Collection geneOntologyCollection = new java.util.HashSet();
			public java.util.Collection getGeneOntologyCollection(){
			try{
			   if(geneOntologyCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneOntology", thisIdSet);
				 geneOntologyCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return geneOntologyCollection;
	                }

	   	public void setGeneOntologyCollection(java.util.Collection geneOntologyCollection){
	   		this.geneOntologyCollection = geneOntologyCollection;
	        }







			private java.util.Collection targetCollection = new java.util.HashSet();
			public java.util.Collection getTargetCollection(){
			try{
			   if(targetCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.Gene thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Target", thisIdSet);
				 targetCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return targetCollection;
	                }

	   	public void setTargetCollection(java.util.Collection targetCollection){
	   		this.targetCollection = targetCollection;
	        }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Gene) {
				Gene c =(Gene)obj;
				Long thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}