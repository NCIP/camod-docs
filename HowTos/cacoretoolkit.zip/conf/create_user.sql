grant all privileges on cacore.* to 'cabiouser'@'localhost' identified by 'cabio' with grant option;
grant all privileges on cacore.* to 'cabiouser'@'localhost' identified by 'cabio' with grant option;
grant all privileges on cacore.* to 'cabiouser'@'*' identified by 'cabio' with grant option;
