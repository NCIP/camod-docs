package gov.nih.nci.cabio.domain;

public interface Ontology {

}
