				README
				
This folder contains Test classes which demonstrates 
- Query scenarios to the default cabio example model provided with this download.
- Code generation which is self contained under codeg-demo folder.   

				