import gov.nih.nci.system.applicationservice.*;
import java.util.*;
import java.text.*;
import gov.nih.nci.common.util.*;
import gov.nih.nci.evs.domain.*;
import gov.nih.nci.evs.query.*;

public class TestEVS {



    public static void main(String[] args) {

        System.out.println("*** TestCase...");

        String prod = "http://cabio.nci.nih.gov/cacore30/server/HTTPServer";
        String stage = "http://cabio-stage.nci.nih.gov/cacore30/server/HTTPServer";
        String dev = "http://cbiodev104.nci.nih.gov:29080/cacore30/server/HTTPServer";
        String qa = "http://cbioqa101.nci.nih.gov:29080/cacore30/server/HTTPServer";
        String local = "http://localhost:8080/cacore30/server/HTTPServer";
	  
       ApplicationService appService = ApplicationService.getRemoteInstance(local);


		try
		{
		    String vocabularyName = "NCI_Thesaurus";
			EVSQuery evsQuery = new EVSQueryImpl();
			List evsResults = new ArrayList();
			System.out.println("\n\nEVS RESULTS......");

/**********************************************************************/
			/** METATHESAURUS **/

    		EVSQuery metaSearch = new EVSQueryImpl();
			List metaResults 	= new ArrayList();
			System.out.println("\n\nEVS METAPHRASE RESULTS......");


/************* NCI Metathesaurus Search ******************************************/

/**
 * Testing method searchMetaThesaurus
 */
			
/**
 * Please uncomment each search method and perfome the test. 
 */
			/**
			 * 1. Valid source - concept found
			 */
			metaSearch.searchMetaThesaurus("CL287739", 2, "SNOMEDCT_2004_01_31", true, false, false);
			/**
			 * 2. Found a source that begins with NCI- no concepts found
			 */
			//metaSearch.searchMetaThesaurus("CL287739", 2, "NCI*", true, false, false);	
			/**
			 * 3. Query all sources
			 */
			//metaSearch.searchMetaThesaurus("CL287739", 5, "*", true, false, false);
			/**
			 * 4. Query all sources
			 */
			//metaSearch.searchMetaThesaurus("CL287739", 4, "", true, false, false);
			/**
			 * 5. Invalid source - throws Exception
			 */
			//metaSearch.searchMetaThesaurus("CL287739", 2, "NCI", true, false, false);
			/**
			 * 6. Returns a meta concept
			 */
			//metaSearch.searchMetaThesaurus("CL287739");
			/**
			 * 7. Search on a term with a specified source 
			 */
			//metaSearch.searchMetaThesaurus("lung", 2, "MSH2005_2004_10_12", false, false, false);
			
			/**
			 * 7. Search all sources for a given term
			 */
			//metaSearch.searchMetaThesaurus("lung", 2, "*", false, false, false);
			
			/**
			 * 8. Search all sources for a given term
			 */
			//metaSearch.searchMetaThesaurus("lung", 2, "", false, false, false);
			
			/**
			 * 9. Invalid source - throws an Exception
			 */
			//metaSearch.searchMetaThesaurus("lung", 3, "NCI", false, false, false);
			
			/**
			 * 10. Queries sources that start with NCI
			 */
			//metaSearch.searchMetaThesaurus("lung", 3, "NCI*", false, false, false);
			
			
			
			long startTime = System.currentTimeMillis();
			metaResults = (List)appService.evsSearch(metaSearch);
			long endTime = System.currentTimeMillis();
    		appService.printEVSResults(metaResults);

			System.out.println(metaResults.size()+"\trecords found");
			System.out.println("Latency in miliseconds = "+ (endTime - startTime));

/*******************************************************************/

		}		catch(Exception ex){
			ex.printStackTrace();
			System.out.println("Test client throws Exception = "+ ex);
		}


	 }//end method


}//end class
