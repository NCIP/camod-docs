

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class AdministeredComponentImpl
	implements java.io.Serializable, AdministeredComponent
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String id;
	   public  java.lang.String getId(){
	      return id;
	   }
	   public void setId( java.lang.String id){
	      this.id = id;
	   }


	   public java.lang.String preferredName;
	   public  java.lang.String getPreferredName(){
	      return preferredName;
	   }
	   public void setPreferredName( java.lang.String preferredName){
	      this.preferredName = preferredName;
	   }


	   public java.lang.String preferredDefinition;
	   public  java.lang.String getPreferredDefinition(){
	      return preferredDefinition;
	   }
	   public void setPreferredDefinition( java.lang.String preferredDefinition){
	      this.preferredDefinition = preferredDefinition;
	   }


	   public java.lang.String longName;
	   public  java.lang.String getLongName(){
	      return longName;
	   }
	   public void setLongName( java.lang.String longName){
	      this.longName = longName;
	   }


	   public java.lang.Float version;
	   public  java.lang.Float getVersion(){
	      return version;
	   }
	   public void setVersion( java.lang.Float version){
	      this.version = version;
	   }


	   public java.lang.String workflowStatusName;
	   public  java.lang.String getWorkflowStatusName(){
	      return workflowStatusName;
	   }
	   public void setWorkflowStatusName( java.lang.String workflowStatusName){
	      this.workflowStatusName = workflowStatusName;
	   }


	   public java.lang.String workflowStatusDescription;
	   public  java.lang.String getWorkflowStatusDescription(){
	      return workflowStatusDescription;
	   }
	   public void setWorkflowStatusDescription( java.lang.String workflowStatusDescription){
	      this.workflowStatusDescription = workflowStatusDescription;
	   }


	   public java.lang.String latestVersionIndicator;
	   public  java.lang.String getLatestVersionIndicator(){
	      return latestVersionIndicator;
	   }
	   public void setLatestVersionIndicator( java.lang.String latestVersionIndicator){
	      this.latestVersionIndicator = latestVersionIndicator;
	   }


	   public java.util.Date beginDate;
	   public  java.util.Date getBeginDate(){
	      return beginDate;
	   }
	   public void setBeginDate( java.util.Date beginDate){
	      this.beginDate = beginDate;
	   }


	   public java.util.Date endDate;
	   public  java.util.Date getEndDate(){
	      return endDate;
	   }
	   public void setEndDate( java.util.Date endDate){
	      this.endDate = endDate;
	   }


	   public java.lang.String deletedIndicator;
	   public  java.lang.String getDeletedIndicator(){
	      return deletedIndicator;
	   }
	   public void setDeletedIndicator( java.lang.String deletedIndicator){
	      this.deletedIndicator = deletedIndicator;
	   }


	   public java.lang.String changeNote;
	   public  java.lang.String getChangeNote(){
	      return changeNote;
	   }
	   public void setChangeNote( java.lang.String changeNote){
	      this.changeNote = changeNote;
	   }


	   public java.lang.String unresolvedIssue;
	   public  java.lang.String getUnresolvedIssue(){
	      return unresolvedIssue;
	   }
	   public void setUnresolvedIssue( java.lang.String unresolvedIssue){
	      this.unresolvedIssue = unresolvedIssue;
	   }


	   public java.lang.String origin;
	   public  java.lang.String getOrigin(){
	      return origin;
	   }
	   public void setOrigin( java.lang.String origin){
	      this.origin = origin;
	   }


	   public java.util.Date dateCreated;
	   public  java.util.Date getDateCreated(){
	      return dateCreated;
	   }
	   public void setDateCreated( java.util.Date dateCreated){
	      this.dateCreated = dateCreated;
	   }


	   public java.util.Date dateModified;
	   public  java.util.Date getDateModified(){
	      return dateModified;
	   }
	   public void setDateModified( java.util.Date dateModified){
	      this.dateModified = dateModified;
	   }


	   public java.lang.Long publicID;
	   public  java.lang.Long getPublicID(){
	      return publicID;
	   }
	   public void setPublicID( java.lang.Long publicID){
	      this.publicID = publicID;
	   }


	   public java.lang.String createdBy;
	   public  java.lang.String getCreatedBy(){
	      return createdBy;
	   }
	   public void setCreatedBy( java.lang.String createdBy){
	      this.createdBy = createdBy;
	   }


	   public java.lang.String modifiedBy;
	   public  java.lang.String getModifiedBy(){
	      return modifiedBy;
	   }
	   public void setModifiedBy( java.lang.String modifiedBy){
	      this.modifiedBy = modifiedBy;
	   }


	   public java.lang.String registrationStatus;
	   public  java.lang.String getRegistrationStatus(){
	      return registrationStatus;
	   }
	   public void setRegistrationStatus( java.lang.String registrationStatus){
	      this.registrationStatus = registrationStatus;
	   }











			private gov.nih.nci.cadsr.domain.Context context;
			public gov.nih.nci.cadsr.domain.Context getContext(){
			  return context;
                        }






	   public void setContext(gov.nih.nci.cadsr.domain.Context context){
		this.context = context;
	   }







			private java.util.Collection administeredComponentClassSchemeItemCollection = new java.util.HashSet();
			public java.util.Collection getAdministeredComponentClassSchemeItemCollection(){
			try{
			   if(administeredComponentClassSchemeItemCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.AdministeredComponent thisIdSet = new gov.nih.nci.cadsr.domain.impl.AdministeredComponentImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.AdministeredComponentClassSchemeItem", thisIdSet);
				 	administeredComponentClassSchemeItemCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("AdministeredComponent:getAdministeredComponentClassSchemeItemCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return administeredComponentClassSchemeItemCollection;
	          }








	   	public void setAdministeredComponentClassSchemeItemCollection(java.util.Collection administeredComponentClassSchemeItemCollection){
	   		this.administeredComponentClassSchemeItemCollection = administeredComponentClassSchemeItemCollection;
	        }







			private java.util.Collection designationCollection = new java.util.HashSet();
			public java.util.Collection getDesignationCollection(){
			try{
			   if(designationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.AdministeredComponent thisIdSet = new gov.nih.nci.cadsr.domain.impl.AdministeredComponentImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Designation", thisIdSet);
				 	designationCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("AdministeredComponent:getDesignationCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return designationCollection;
	          }








	   	public void setDesignationCollection(java.util.Collection designationCollection){
	   		this.designationCollection = designationCollection;
	        }







			private java.util.Collection referenceDocumentCollection = new java.util.HashSet();
			public java.util.Collection getReferenceDocumentCollection(){
			try{
			   if(referenceDocumentCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.AdministeredComponent thisIdSet = new gov.nih.nci.cadsr.domain.impl.AdministeredComponentImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ReferenceDocument", thisIdSet);
				 	referenceDocumentCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("AdministeredComponent:getReferenceDocumentCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return referenceDocumentCollection;
	          }








	   	public void setReferenceDocumentCollection(java.util.Collection referenceDocumentCollection){
	   		this.referenceDocumentCollection = referenceDocumentCollection;
	        }







			private java.util.Collection definitionCollection = new java.util.HashSet();
			public java.util.Collection getDefinitionCollection(){
			try{
			   if(definitionCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.AdministeredComponent thisIdSet = new gov.nih.nci.cadsr.domain.impl.AdministeredComponentImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Definition", thisIdSet);
				 	definitionCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("AdministeredComponent:getDefinitionCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return definitionCollection;
	          }








	   	public void setDefinitionCollection(java.util.Collection definitionCollection){
	   		this.definitionCollection = definitionCollection;
	        }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof AdministeredComponent) {
				AdministeredComponent c =(AdministeredComponent)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}