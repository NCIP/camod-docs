

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class EnumeratedValueDomainImpl 
    extends ValueDomainImpl
	implements java.io.Serializable, EnumeratedValueDomain 
{
	private static final long serialVersionUID = 1234567890L;

	

	
	   
	   
	   
	      
			private java.util.Collection valueDomainPermissibleValueCollection = new java.util.HashSet();
			public java.util.Collection getValueDomainPermissibleValueCollection(){
			try{
			   if(valueDomainPermissibleValueCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cadsr.domain.EnumeratedValueDomain thisIdSet = new gov.nih.nci.cadsr.domain.impl.EnumeratedValueDomainImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ValueDomainPermissibleValue", thisIdSet);				 
				 	valueDomainPermissibleValueCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("EnumeratedValueDomain:getValueDomainPermissibleValueCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return valueDomainPermissibleValueCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setValueDomainPermissibleValueCollection(java.util.Collection valueDomainPermissibleValueCollection){
	   		this.valueDomainPermissibleValueCollection = valueDomainPermissibleValueCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof EnumeratedValueDomain) {
				EnumeratedValueDomain c =(EnumeratedValueDomain)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}