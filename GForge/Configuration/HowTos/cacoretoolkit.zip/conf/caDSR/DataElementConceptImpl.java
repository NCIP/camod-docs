

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class DataElementConceptImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, DataElementConcept
{
	private static final long serialVersionUID = 1234567890L;












			private gov.nih.nci.cadsr.domain.Qualifier propertyQualifier;
			public gov.nih.nci.cadsr.domain.Qualifier getPropertyQualifier(){
			  return propertyQualifier;
                        }






	   public void setPropertyQualifier(gov.nih.nci.cadsr.domain.Qualifier propertyQualifier){
		this.propertyQualifier = propertyQualifier;
	   }











			private gov.nih.nci.cadsr.domain.Qualifier objectClassQualifier;
			public gov.nih.nci.cadsr.domain.Qualifier getObjectClassQualifier(){
			  return objectClassQualifier;
                        }






	   public void setObjectClassQualifier(gov.nih.nci.cadsr.domain.Qualifier objectClassQualifier){
		this.objectClassQualifier = objectClassQualifier;
	   }











			private gov.nih.nci.cadsr.domain.Property property;
			public gov.nih.nci.cadsr.domain.Property getProperty(){
			  return property;
                        }






	   public void setProperty(gov.nih.nci.cadsr.domain.Property property){
		this.property = property;
	   }











			private gov.nih.nci.cadsr.domain.ConceptualDomain conceptualDomain;
			public gov.nih.nci.cadsr.domain.ConceptualDomain getConceptualDomain(){
			  return conceptualDomain;
                        }






	   public void setConceptualDomain(gov.nih.nci.cadsr.domain.ConceptualDomain conceptualDomain){
		this.conceptualDomain = conceptualDomain;
	   }







			private java.util.Collection dataElementCollection = new java.util.HashSet();
			public java.util.Collection getDataElementCollection(){
			try{
			   if(dataElementCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.DataElementConcept thisIdSet = new gov.nih.nci.cadsr.domain.impl.DataElementConceptImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElement", thisIdSet);
				 	dataElementCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("DataElementConcept:getDataElementCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return dataElementCollection;
	          }








	   	public void setDataElementCollection(java.util.Collection dataElementCollection){
	   		this.dataElementCollection = dataElementCollection;
	        }







			private java.util.Collection childDataElementConceptRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getChildDataElementConceptRelationshipCollection(){
			try{
			   if(childDataElementConceptRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.DataElementConcept thisIdSet = new gov.nih.nci.cadsr.domain.impl.DataElementConceptImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementConceptRelationship", thisIdSet);
				 	childDataElementConceptRelationshipCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("DataElementConcept:getChildDataElementConceptRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return childDataElementConceptRelationshipCollection;
	          }








	   	public void setChildDataElementConceptRelationshipCollection(java.util.Collection childDataElementConceptRelationshipCollection){
	   		this.childDataElementConceptRelationshipCollection = childDataElementConceptRelationshipCollection;
	        }











			private gov.nih.nci.cadsr.domain.ObjectClass objectClass;
			public gov.nih.nci.cadsr.domain.ObjectClass getObjectClass(){
			  return objectClass;
                        }






	   public void setObjectClass(gov.nih.nci.cadsr.domain.ObjectClass objectClass){
		this.objectClass = objectClass;
	   }







			private java.util.Collection parentDataElementConceptRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getParentDataElementConceptRelationshipCollection(){
			try{
			   if(parentDataElementConceptRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.DataElementConcept thisIdSet = new gov.nih.nci.cadsr.domain.impl.DataElementConceptImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementConceptRelationship", thisIdSet);
				 	parentDataElementConceptRelationshipCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("DataElementConcept:getParentDataElementConceptRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return parentDataElementConceptRelationshipCollection;
	          }








	   	public void setParentDataElementConceptRelationshipCollection(java.util.Collection parentDataElementConceptRelationshipCollection){
	   		this.parentDataElementConceptRelationshipCollection = parentDataElementConceptRelationshipCollection;
	        }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof DataElementConcept) {
				DataElementConcept c =(DataElementConcept)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}