

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class QuestionImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, Question
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.Integer displayOrder;
	   public  java.lang.Integer getDisplayOrder(){
	      return displayOrder;
	   }
	   public void setDisplayOrder( java.lang.Integer displayOrder){
	      this.displayOrder = displayOrder;
	   }











			private gov.nih.nci.cadsr.domain.DataElement dataElement;
			public gov.nih.nci.cadsr.domain.DataElement getDataElement(){
			  return dataElement;
                        }






	   public void setDataElement(gov.nih.nci.cadsr.domain.DataElement dataElement){
		this.dataElement = dataElement;
	   }











			private gov.nih.nci.cadsr.domain.ValueDomain valueDomain;
			public gov.nih.nci.cadsr.domain.ValueDomain getValueDomain(){
			  return valueDomain;
                        }






	   public void setValueDomain(gov.nih.nci.cadsr.domain.ValueDomain valueDomain){
		this.valueDomain = valueDomain;
	   }







			private java.util.Collection validValueCollection = new java.util.HashSet();
			public java.util.Collection getValidValueCollection(){
			try{
			   if(validValueCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Question thisIdSet = new gov.nih.nci.cadsr.domain.impl.QuestionImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ValidValue", thisIdSet);
				 	validValueCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Question:getValidValueCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return validValueCollection;
	          }








	   	public void setValidValueCollection(java.util.Collection validValueCollection){
	   		this.validValueCollection = validValueCollection;
	        }







			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
			try{
			   if(instructionCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Question thisIdSet = new gov.nih.nci.cadsr.domain.impl.QuestionImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Instruction", thisIdSet);
				 	instructionCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Question:getInstructionCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return instructionCollection;
	          }








	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }











			private gov.nih.nci.cadsr.domain.Module module;
			public gov.nih.nci.cadsr.domain.Module getModule(){
			  return module;
                        }






	   public void setModule(gov.nih.nci.cadsr.domain.Module module){
		this.module = module;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Question) {
				Question c =(Question)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}