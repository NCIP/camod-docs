

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ObjectClassImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, ObjectClass
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String definitionSource;
	   public  java.lang.String getDefinitionSource(){
	      return definitionSource;
	   }
	   public void setDefinitionSource( java.lang.String definitionSource){
	      this.definitionSource = definitionSource;
	   }







			private java.util.Collection targetObjectClassRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getTargetObjectClassRelationshipCollection(){
			try{
			   if(targetObjectClassRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ObjectClass thisIdSet = new gov.nih.nci.cadsr.domain.impl.ObjectClassImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ObjectClassRelationship", thisIdSet);
				 	targetObjectClassRelationshipCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ObjectClass:getTargetObjectClassRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return targetObjectClassRelationshipCollection;
	          }








	   	public void setTargetObjectClassRelationshipCollection(java.util.Collection targetObjectClassRelationshipCollection){
	   		this.targetObjectClassRelationshipCollection = targetObjectClassRelationshipCollection;
	        }







			private java.util.Collection sourcObjectClassRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getSourcObjectClassRelationshipCollection(){
			try{
			   if(sourcObjectClassRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ObjectClass thisIdSet = new gov.nih.nci.cadsr.domain.impl.ObjectClassImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ObjectClassRelationship", thisIdSet);
				 	sourcObjectClassRelationshipCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ObjectClass:getSourcObjectClassRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return sourcObjectClassRelationshipCollection;
	          }








	   	public void setSourcObjectClassRelationshipCollection(java.util.Collection sourcObjectClassRelationshipCollection){
	   		this.sourcObjectClassRelationshipCollection = sourcObjectClassRelationshipCollection;
	        }







			private java.util.Collection dataElementConceptCollection = new java.util.HashSet();
			public java.util.Collection getDataElementConceptCollection(){
			try{
			   if(dataElementConceptCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ObjectClass thisIdSet = new gov.nih.nci.cadsr.domain.impl.ObjectClassImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.DataElementConcept", thisIdSet);
				 	dataElementConceptCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ObjectClass:getDataElementConceptCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return dataElementConceptCollection;
	          }








	   	public void setDataElementConceptCollection(java.util.Collection dataElementConceptCollection){
	   		this.dataElementConceptCollection = dataElementConceptCollection;
	        }











			private gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule;
			public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule(){
			  return conceptDerivationRule;
                        }






	   public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule){
		this.conceptDerivationRule = conceptDerivationRule;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ObjectClass) {
				ObjectClass c =(ObjectClass)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}