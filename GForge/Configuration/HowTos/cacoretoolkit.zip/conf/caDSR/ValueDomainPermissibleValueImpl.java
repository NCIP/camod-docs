

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ValueDomainPermissibleValueImpl
	implements java.io.Serializable, ValueDomainPermissibleValue
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.String id;
	   public  java.lang.String getId(){
	      return id;
	   }
	   public void setId( java.lang.String id){
	      this.id = id;
	   }


	   public java.util.Date dateCreated;
	   public  java.util.Date getDateCreated(){
	      return dateCreated;
	   }
	   public void setDateCreated( java.util.Date dateCreated){
	      this.dateCreated = dateCreated;
	   }


	   public java.util.Date dateModified;
	   public  java.util.Date getDateModified(){
	      return dateModified;
	   }
	   public void setDateModified( java.util.Date dateModified){
	      this.dateModified = dateModified;
	   }


	   public java.lang.String createdBy;
	   public  java.lang.String getCreatedBy(){
	      return createdBy;
	   }
	   public void setCreatedBy( java.lang.String createdBy){
	      this.createdBy = createdBy;
	   }


	   public java.lang.String modifiedBy;
	   public  java.lang.String getModifiedBy(){
	      return modifiedBy;
	   }
	   public void setModifiedBy( java.lang.String modifiedBy){
	      this.modifiedBy = modifiedBy;
	   }


	   public java.lang.String origin;
	   public  java.lang.String getOrigin(){
	      return origin;
	   }
	   public void setOrigin( java.lang.String origin){
	      this.origin = origin;
	   }


	   public java.util.Date beginDate;
	   public  java.util.Date getBeginDate(){
	      return beginDate;
	   }
	   public void setBeginDate( java.util.Date beginDate){
	      this.beginDate = beginDate;
	   }


	   public java.util.Date endDate;
	   public  java.util.Date getEndDate(){
	      return endDate;
	   }
	   public void setEndDate( java.util.Date endDate){
	      this.endDate = endDate;
	   }











			private gov.nih.nci.cadsr.domain.Concept concept;
			public gov.nih.nci.cadsr.domain.Concept getConcept(){
			  return concept;
                        }






	   public void setConcept(gov.nih.nci.cadsr.domain.Concept concept){
		this.concept = concept;
	   }







			private java.util.Collection validValueCollection = new java.util.HashSet();
			public java.util.Collection getValidValueCollection(){
			try{
			   if(validValueCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.ValueDomainPermissibleValue thisIdSet = new gov.nih.nci.cadsr.domain.impl.ValueDomainPermissibleValueImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.ValidValue", thisIdSet);
				 	validValueCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("ValueDomainPermissibleValue:getValidValueCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return validValueCollection;
	          }








	   	public void setValidValueCollection(java.util.Collection validValueCollection){
	   		this.validValueCollection = validValueCollection;
	        }











			private gov.nih.nci.cadsr.domain.EnumeratedValueDomain enumeratedValueDomain;
			public gov.nih.nci.cadsr.domain.EnumeratedValueDomain getEnumeratedValueDomain(){
			  return enumeratedValueDomain;
                        }






	   public void setEnumeratedValueDomain(gov.nih.nci.cadsr.domain.EnumeratedValueDomain enumeratedValueDomain){
		this.enumeratedValueDomain = enumeratedValueDomain;
	   }











			private gov.nih.nci.cadsr.domain.PermissibleValue permissibleValue;
			public gov.nih.nci.cadsr.domain.PermissibleValue getPermissibleValue(){
			  return permissibleValue;
                        }






	   public void setPermissibleValue(gov.nih.nci.cadsr.domain.PermissibleValue permissibleValue){
		this.permissibleValue = permissibleValue;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ValueDomainPermissibleValue) {
				ValueDomainPermissibleValue c =(ValueDomainPermissibleValue)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}