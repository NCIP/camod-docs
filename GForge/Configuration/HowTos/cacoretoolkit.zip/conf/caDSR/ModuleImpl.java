

package gov.nih.nci.cadsr.domain.impl;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ModuleImpl
    extends AdministeredComponentImpl
	implements java.io.Serializable, Module
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.Integer displayOrder;
	   public  java.lang.Integer getDisplayOrder(){
	      return displayOrder;
	   }
	   public void setDisplayOrder( java.lang.Integer displayOrder){
	      this.displayOrder = displayOrder;
	   }











			private gov.nih.nci.cadsr.domain.CaseReportForm caseReportForm;
			public gov.nih.nci.cadsr.domain.CaseReportForm getCaseReportForm(){
			  return caseReportForm;
                        }






	   public void setCaseReportForm(gov.nih.nci.cadsr.domain.CaseReportForm caseReportForm){
		this.caseReportForm = caseReportForm;
	   }







			private java.util.Collection questionCollection = new java.util.HashSet();
			public java.util.Collection getQuestionCollection(){
			try{
			   if(questionCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Module thisIdSet = new gov.nih.nci.cadsr.domain.impl.ModuleImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Question", thisIdSet);
				 	questionCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Module:getQuestionCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return questionCollection;
	          }








	   	public void setQuestionCollection(java.util.Collection questionCollection){
	   		this.questionCollection = questionCollection;
	        }







			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
			try{
			   if(instructionCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {



				 	gov.nih.nci.cadsr.domain.Module thisIdSet = new gov.nih.nci.cadsr.domain.impl.ModuleImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cadsr.domain.Instruction", thisIdSet);
				 	instructionCollection = resultList;
				 	return resultList;


			      }catch(Exception ex)
			      {
			      	System.out.println("Module:getInstructionCollection throws exception ... ...");
			   		ex.printStackTrace();
			      }
			   }
	              return instructionCollection;
	          }








	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }











			private gov.nih.nci.cadsr.domain.ProtocolFormsTemplate protocolFormsTemplate;
			public gov.nih.nci.cadsr.domain.ProtocolFormsTemplate getProtocolFormsTemplate(){
			  return protocolFormsTemplate;
                        }






	   public void setProtocolFormsTemplate(gov.nih.nci.cadsr.domain.ProtocolFormsTemplate protocolFormsTemplate){
		this.protocolFormsTemplate = protocolFormsTemplate;
	   }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Module) {
				Module c =(Module)obj;
				String thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}