

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class SNPImpl
	implements java.io.Serializable, SNP
{
	private static final long serialVersionUID = 1234567890L;



	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }


	   public java.lang.String DBSNPID;
	   public  java.lang.String getDBSNPID(){
	      return DBSNPID;
	   }
	   public void setDBSNPID( java.lang.String DBSNPID){
	      this.DBSNPID = DBSNPID;
	   }


	   public java.lang.String validationStatus;
	   public  java.lang.String getValidationStatus(){
	      return validationStatus;
	   }
	   public void setValidationStatus( java.lang.String validationStatus){
	      this.validationStatus = validationStatus;
	   }


	   public java.lang.String alleleA;
	   public  java.lang.String getAlleleA(){
	      return alleleA;
	   }
	   public void setAlleleA( java.lang.String alleleA){
	      this.alleleA = alleleA;
	   }


	   public java.lang.String alleleB;
	   public  java.lang.String getAlleleB(){
	      return alleleB;
	   }
	   public void setAlleleB( java.lang.String alleleB){
	      this.alleleB = alleleB;
	   }







			private java.util.Collection databaseCrossReferenceCollection = new java.util.HashSet();
			public java.util.Collection getDatabaseCrossReferenceCollection(){
			try{
			   if(databaseCrossReferenceCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.SNP thisIdSet = new gov.nih.nci.cabio.domain.impl.SNPImpl();
			         thisIdSet.setId(this.getId());
			         java.util.List resultList = applicationService.search("gov.nih.nci.common.domain.DatabaseCrossReference", thisIdSet);
				 databaseCrossReferenceCollection = resultList;
				 java.util.List resultList1 = new ArrayList();
					 for(int i = 0; i < resultList.size(); i++)
					 {
						 gov.nih.nci.common.domain.DatabaseCrossReference db = (gov.nih.nci.common.domain.DatabaseCrossReference)resultList.get(i);
						 String type = db.getType().trim();
						 if(type.equalsIgnoreCase("gov.nih.nci.cabio.domain.SNP"))
							 resultList1.add(resultList.get(i));
					 }

									 //System.out.println("size = " + resultList1.size());
					 return resultList1;

			      }catch(Exception ex) { }
			   }

	                return databaseCrossReferenceCollection;
	                }

	   	public void setDatabaseCrossReferenceCollection(java.util.Collection databaseCrossReferenceCollection){
	   		this.databaseCrossReferenceCollection = databaseCrossReferenceCollection;
	        }







			private java.util.Collection populationFrequencyCollection = new java.util.HashSet();
			public java.util.Collection getPopulationFrequencyCollection(){
			try{
			   if(populationFrequencyCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.SNP thisIdSet = new gov.nih.nci.cabio.domain.impl.SNPImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.PopulationFrequency", thisIdSet);
				 populationFrequencyCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return populationFrequencyCollection;
	                }

	   	public void setPopulationFrequencyCollection(java.util.Collection populationFrequencyCollection){
	   		this.populationFrequencyCollection = populationFrequencyCollection;
	        }







			private java.util.Collection locationCollection = new java.util.HashSet();
			public java.util.Collection getLocationCollection(){
			try{
			   if(locationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.SNP thisIdSet = new gov.nih.nci.cabio.domain.impl.SNPImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Location", thisIdSet);
				 locationCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return locationCollection;
	                }

	   	public void setLocationCollection(java.util.Collection locationCollection){
	   		this.locationCollection = locationCollection;
	        }







			private java.util.Collection geneRelativeLocationCollection = new java.util.HashSet();
			public java.util.Collection getGeneRelativeLocationCollection(){
			try{
			   if(geneRelativeLocationCollection.size() == 0) {}
		           } catch(Exception e) {
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {

				 gov.nih.nci.cabio.domain.SNP thisIdSet = new gov.nih.nci.cabio.domain.impl.SNPImpl();
			         thisIdSet.setId(this.getId());
			         java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneRelativeLocation", thisIdSet);
				 geneRelativeLocationCollection = resultList;
				 return resultList;

			      }catch(Exception ex) { }
			   }

	                return geneRelativeLocationCollection;
	                }

	   	public void setGeneRelativeLocationCollection(java.util.Collection geneRelativeLocationCollection){
	   		this.geneRelativeLocationCollection = geneRelativeLocationCollection;
	        }




	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof SNP) {
				SNP c =(SNP)obj;
				Long thisId = getId();
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}

			}
			return eq;
		}

		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}


}