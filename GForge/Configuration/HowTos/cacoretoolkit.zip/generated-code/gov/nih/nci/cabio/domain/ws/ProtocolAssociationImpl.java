

package gov.nih.nci.cabio.domain.ws;
import gov.nih.nci.cabio.domain.ws.*;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ProtocolAssociationImpl 
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String diseaseSubCategory;
	   public  java.lang.String getDiseaseSubCategory(){
	      return diseaseSubCategory;
	   }
	   
	   public void setDiseaseSubCategory( java.lang.String diseaseSubCategory){
	      this.diseaseSubCategory = diseaseSubCategory;
	   }
	
	   
	   public java.lang.String CTEPNAME;
	   public  java.lang.String getCTEPNAME(){
	      return CTEPNAME;
	   }
	   
	   public void setCTEPNAME( java.lang.String CTEPNAME){
	      this.CTEPNAME = CTEPNAME;
	   }
	
	   
	   public java.lang.Long IMTCODE;
	   public  java.lang.Long getIMTCODE(){
	      return IMTCODE;
	   }
	   
	   public void setIMTCODE( java.lang.Long IMTCODE){
	      this.IMTCODE = IMTCODE;
	   }
	
	   
	   public java.lang.String diseaseCategory;
	   public  java.lang.String getDiseaseCategory(){
	      return diseaseCategory;
	   }
	   
	   public void setDiseaseCategory( java.lang.String diseaseCategory){
	      this.diseaseCategory = diseaseCategory;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl diseaseOntology;
			public gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl getDiseaseOntology(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setDiseaseOntology(gov.nih.nci.cabio.domain.ws.DiseaseOntologyImpl diseaseOntology){
		this.diseaseOntology = diseaseOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.ClinicalTrialProtocolImpl clinicalTrialProtocol;
			public gov.nih.nci.cabio.domain.ws.ClinicalTrialProtocolImpl getClinicalTrialProtocol(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setClinicalTrialProtocol(gov.nih.nci.cabio.domain.ws.ClinicalTrialProtocolImpl clinicalTrialProtocol){
		this.clinicalTrialProtocol = clinicalTrialProtocol;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ProtocolAssociation) {
				ProtocolAssociation c =(ProtocolAssociation)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
