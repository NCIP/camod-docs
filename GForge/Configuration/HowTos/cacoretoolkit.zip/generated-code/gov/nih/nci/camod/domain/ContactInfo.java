

package gov.nih.nci.camod.domain;


public interface ContactInfo 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getFaxNumber();
	   public void setFaxNumber( java.lang.String faxNumber);
	
	   
	   public  java.lang.String getZipCode();
	   public void setZipCode( java.lang.String zipCode);
	
	   
	   public  java.lang.String getStreet();
	   public void setStreet( java.lang.String street);
	
	   
	   public  java.lang.String getInstitute();
	   public void setInstitute( java.lang.String institute);
	
	   
	   public  java.lang.String getState();
	   public void setState( java.lang.String state);
	
	   
	   public  java.lang.String getEmail();
	   public void setEmail( java.lang.String email);
	
	   
	   public  java.lang.String getPhoneNumber();
	   public void setPhoneNumber( java.lang.String phoneNumber);
	
	   
	   public  java.lang.String getLabName();
	   public void setLabName( java.lang.String labName);
	
	   
	   public  java.lang.String getCity();
	   public void setCity( java.lang.String city);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getPartyCollection();
	      
		
	public void setPartyCollection(java.util.Collection partyCollection);
		
	   
	
	
}
