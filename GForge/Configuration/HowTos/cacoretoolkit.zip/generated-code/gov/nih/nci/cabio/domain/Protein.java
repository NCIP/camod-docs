

package gov.nih.nci.cabio.domain;


public interface Protein 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getPrimaryAccession();
	   public void setPrimaryAccession( java.lang.String primaryAccession);
	
	   
	   public  java.lang.String getUniProtCode();
	   public void setUniProtCode( java.lang.String uniProtCode);
	
	   
	   public  java.lang.String getCopyrightStatement();
	   public void setCopyrightStatement( java.lang.String copyrightStatement);
	
	   
	   public  java.util.Collection getSecondaryAccession();
	   public void setSecondaryAccession( java.util.Collection secondaryAccession);
	
	   
	   public  java.util.Collection getKeywords();
	   public void setKeywords( java.util.Collection keywords);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getProteinAliasCollection();
	      
		
	public void setProteinAliasCollection(java.util.Collection proteinAliasCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTaxonCollection();
	      
		
	public void setTaxonCollection(java.util.Collection taxonCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.ProteinSequence getProteinSequence();
		  
		
	public void setProteinSequence(gov.nih.nci.cabio.domain.ProteinSequence proteinSequence);
		
	
	   
	
	
}
