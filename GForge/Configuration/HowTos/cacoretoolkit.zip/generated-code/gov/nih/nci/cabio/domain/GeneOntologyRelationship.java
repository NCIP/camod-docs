

package gov.nih.nci.cabio.domain;


public interface GeneOntologyRelationship 





    extends OntologyRelationship


{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getRelationshipType();
	   public void setRelationshipType( java.lang.String relationshipType);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.GeneOntology getChildGeneOntology();
		  
		
	public void setChildGeneOntology(gov.nih.nci.cabio.domain.GeneOntology childGeneOntology);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.GeneOntology getParentGeneOntology();
		  
		
	public void setParentGeneOntology(gov.nih.nci.cabio.domain.GeneOntology parentGeneOntology);
		
	
	   
	
	
}
