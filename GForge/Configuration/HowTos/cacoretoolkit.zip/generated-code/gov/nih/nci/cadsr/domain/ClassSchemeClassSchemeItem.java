

package gov.nih.nci.cadsr.domain;


public interface ClassSchemeClassSchemeItem 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.Integer getDisplayOrder();
	   public void setDisplayOrder( java.lang.Integer displayOrder);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ClassificationScheme getClassificationScheme();
		  
		
	public void setClassificationScheme(gov.nih.nci.cadsr.domain.ClassificationScheme classificationScheme);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getAdministeredComponentClassSchemeItemCollection();
	      
		
	public void setAdministeredComponentClassSchemeItemCollection(java.util.Collection administeredComponentClassSchemeItemCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem getParentClassSchemeClassSchemeItem();
		  
		
	public void setParentClassSchemeClassSchemeItem(gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem parentClassSchemeClassSchemeItem);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDefinitionClassSchemeItemCollection();
	      
		
	public void setDefinitionClassSchemeItemCollection(java.util.Collection definitionClassSchemeItemCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ClassificationSchemeItem getClassificationSchemeItem();
		  
		
	public void setClassificationSchemeItem(gov.nih.nci.cadsr.domain.ClassificationSchemeItem classificationSchemeItem);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDesignationClassSchemeItemCollection();
	      
		
	public void setDesignationClassSchemeItemCollection(java.util.Collection designationClassSchemeItemCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildClassSchemeClassSchemeItemCollection();
	      
		
	public void setChildClassSchemeClassSchemeItemCollection(java.util.Collection childClassSchemeClassSchemeItemCollection);
		
	   
	
	
}
