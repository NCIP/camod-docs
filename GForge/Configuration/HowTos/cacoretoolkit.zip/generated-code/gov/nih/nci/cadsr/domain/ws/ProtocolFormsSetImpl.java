

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ProtocolFormsSetImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.String protocolId;
	   public  java.lang.String getProtocolId(){
	      return protocolId;
	   }
	   
	   public void setProtocolId( java.lang.String protocolId){
	      this.protocolId = protocolId;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	
	   
	   public java.lang.String phase;
	   public  java.lang.String getPhase(){
	      return phase;
	   }
	   
	   public void setPhase( java.lang.String phase){
	      this.phase = phase;
	   }
	
	   
	   public java.lang.String leadOrganizationName;
	   public  java.lang.String getLeadOrganizationName(){
	      return leadOrganizationName;
	   }
	   
	   public void setLeadOrganizationName( java.lang.String leadOrganizationName){
	      this.leadOrganizationName = leadOrganizationName;
	   }
	
	   
	   public java.lang.String changeType;
	   public  java.lang.String getChangeType(){
	      return changeType;
	   }
	   
	   public void setChangeType( java.lang.String changeType){
	      this.changeType = changeType;
	   }
	
	   
	   public java.lang.String changeNumber;
	   public  java.lang.String getChangeNumber(){
	      return changeNumber;
	   }
	   
	   public void setChangeNumber( java.lang.String changeNumber){
	      this.changeNumber = changeNumber;
	   }
	
	   
	   public java.util.Date reviewedDate;
	   public  java.util.Date getReviewedDate(){
	      return reviewedDate;
	   }
	   
	   public void setReviewedDate( java.util.Date reviewedDate){
	      this.reviewedDate = reviewedDate;
	   }
	
	   
	   public java.lang.String reviewedBy;
	   public  java.lang.String getReviewedBy(){
	      return reviewedBy;
	   }
	   
	   public void setReviewedBy( java.lang.String reviewedBy){
	      this.reviewedBy = reviewedBy;
	   }
	
	   
	   public java.util.Date approvedDate;
	   public  java.util.Date getApprovedDate(){
	      return approvedDate;
	   }
	   
	   public void setApprovedDate( java.util.Date approvedDate){
	      this.approvedDate = approvedDate;
	   }
	
	   
	   public java.lang.String approvedBy;
	   public  java.lang.String getApprovedBy(){
	      return approvedBy;
	   }
	   
	   public void setApprovedBy( java.lang.String approvedBy){
	      this.approvedBy = approvedBy;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection caseReportFormCollection = new java.util.HashSet();
			public java.util.Collection getCaseReportFormCollection(){
	              return caseReportFormCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setCaseReportFormCollection(java.util.Collection caseReportFormCollection){
	   		this.caseReportFormCollection = caseReportFormCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ProtocolFormsSet) {
				ProtocolFormsSet c =(ProtocolFormsSet)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
