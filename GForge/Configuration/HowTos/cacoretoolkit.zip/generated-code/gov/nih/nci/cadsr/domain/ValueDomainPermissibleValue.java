

package gov.nih.nci.cadsr.domain;


public interface ValueDomainPermissibleValue 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	   
	   public  java.lang.String getOrigin();
	   public void setOrigin( java.lang.String origin);
	
	   
	   public  java.util.Date getBeginDate();
	   public void setBeginDate( java.util.Date beginDate);
	
	   
	   public  java.util.Date getEndDate();
	   public void setEndDate( java.util.Date endDate);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Concept getConcept();
		  
		
	public void setConcept(gov.nih.nci.cadsr.domain.Concept concept);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getValidValueCollection();
	      
		
	public void setValidValueCollection(java.util.Collection validValueCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.EnumeratedValueDomain getEnumeratedValueDomain();
		  
		
	public void setEnumeratedValueDomain(gov.nih.nci.cadsr.domain.EnumeratedValueDomain enumeratedValueDomain);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.PermissibleValue getPermissibleValue();
		  
		
	public void setPermissibleValue(gov.nih.nci.cadsr.domain.PermissibleValue permissibleValue);
		
	
	   
	
	
}
