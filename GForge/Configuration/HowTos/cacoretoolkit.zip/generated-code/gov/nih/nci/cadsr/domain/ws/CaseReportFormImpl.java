

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class CaseReportFormImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.String displayName;
	   public  java.lang.String getDisplayName(){
	      return displayName;
	   }
	   
	   public void setDisplayName( java.lang.String displayName){
	      this.displayName = displayName;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
	              return instructionCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection moduleCollection = new java.util.HashSet();
			public java.util.Collection getModuleCollection(){
	              return moduleCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setModuleCollection(java.util.Collection moduleCollection){
	   		this.moduleCollection = moduleCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ProtocolFormsSetImpl protocolFormsSet;
			public gov.nih.nci.cadsr.domain.ws.ProtocolFormsSetImpl getProtocolFormsSet(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setProtocolFormsSet(gov.nih.nci.cadsr.domain.ws.ProtocolFormsSetImpl protocolFormsSet){
		this.protocolFormsSet = protocolFormsSet;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof CaseReportForm) {
				CaseReportForm c =(CaseReportForm)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
