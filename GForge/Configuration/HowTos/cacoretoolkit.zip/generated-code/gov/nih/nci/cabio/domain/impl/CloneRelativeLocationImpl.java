

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class CloneRelativeLocationImpl 
	implements java.io.Serializable, CloneRelativeLocation 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.Clone clone;
			public gov.nih.nci.cabio.domain.Clone getClone(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.CloneRelativeLocation thisIdSet = new gov.nih.nci.cabio.domain.impl.CloneRelativeLocationImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Clone", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                clone = (gov.nih.nci.cabio.domain.Clone)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("CloneRelativeLocation:getClone throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return clone;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setClone(gov.nih.nci.cabio.domain.Clone clone){
		this.clone = clone;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			private gov.nih.nci.cabio.domain.NucleicAcidSequence nucleicAcidSequence;
			public gov.nih.nci.cabio.domain.NucleicAcidSequence getNucleicAcidSequence(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.CloneRelativeLocation thisIdSet = new gov.nih.nci.cabio.domain.impl.CloneRelativeLocationImpl();
			  thisIdSet.setId(this.getId());
			  try {
			  java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.NucleicAcidSequence", thisIdSet);				 
			 
			  if (resultList!=null && resultList.size()>0) {
			     nucleicAcidSequence = (gov.nih.nci.cabio.domain.NucleicAcidSequence)resultList.get(0);
			     }
			  } catch(Exception ex) 
			  { 
			      	System.out.println("CloneRelativeLocation:getNucleicAcidSequence throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return nucleicAcidSequence;			
                        }
                        
	      
	               
	   
	   
	   
	   public void setNucleicAcidSequence(gov.nih.nci.cabio.domain.NucleicAcidSequence nucleicAcidSequence){
		this.nucleicAcidSequence = nucleicAcidSequence;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof CloneRelativeLocation) {
				CloneRelativeLocation c =(CloneRelativeLocation)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}