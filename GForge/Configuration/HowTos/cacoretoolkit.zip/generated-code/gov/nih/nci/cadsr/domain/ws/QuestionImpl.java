

package gov.nih.nci.cadsr.domain.ws;
import gov.nih.nci.cadsr.domain.ws.*;
import gov.nih.nci.cadsr.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class QuestionImpl 
    extends AdministeredComponentImpl
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Integer displayOrder;
	   public  java.lang.Integer getDisplayOrder(){
	      return displayOrder;
	   }
	   
	   public void setDisplayOrder( java.lang.Integer displayOrder){
	      this.displayOrder = displayOrder;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.DataElementImpl dataElement;
			public gov.nih.nci.cadsr.domain.ws.DataElementImpl getDataElement(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setDataElement(gov.nih.nci.cadsr.domain.ws.DataElementImpl dataElement){
		this.dataElement = dataElement;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ValueDomainImpl valueDomain;
			public gov.nih.nci.cadsr.domain.ws.ValueDomainImpl getValueDomain(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setValueDomain(gov.nih.nci.cadsr.domain.ws.ValueDomainImpl valueDomain){
		this.valueDomain = valueDomain;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection validValueCollection = new java.util.HashSet();
			public java.util.Collection getValidValueCollection(){
	              return validValueCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setValidValueCollection(java.util.Collection validValueCollection){
	   		this.validValueCollection = validValueCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection instructionCollection = new java.util.HashSet();
			public java.util.Collection getInstructionCollection(){
	              return instructionCollection;
	          }
			   
			   
			   
			   			   
	      
	               
	   
	   	public void setInstructionCollection(java.util.Collection instructionCollection){
	   		this.instructionCollection = instructionCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cadsr.domain.ws.ModuleImpl module;
			public gov.nih.nci.cadsr.domain.ws.ModuleImpl getModule(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setModule(gov.nih.nci.cadsr.domain.ws.ModuleImpl module){
		this.module = module;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Question) {
				Question c =(Question)obj; 			 
				String thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
