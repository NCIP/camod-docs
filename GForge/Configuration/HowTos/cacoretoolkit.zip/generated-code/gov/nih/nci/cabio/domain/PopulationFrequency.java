

package gov.nih.nci.cabio.domain;


public interface PopulationFrequency 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getEthnicity();
	   public void setEthnicity( java.lang.String ethnicity);
	
	   
	   public  java.lang.Double getMajorFrequency();
	   public void setMajorFrequency( java.lang.Double majorFrequency);
	
	   
	   public  java.lang.Double getMinorFrequency();
	   public void setMinorFrequency( java.lang.Double minorFrequency);
	
	   
	   public  java.lang.String getMajorAllele();
	   public void setMajorAllele( java.lang.String majorAllele);
	
	   
	   public  java.lang.String getMinorAllele();
	   public void setMinorAllele( java.lang.String minorAllele);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.SNP getSNP();
		  
		
	public void setSNP(gov.nih.nci.cabio.domain.SNP SNP);
		
	
	   
	
	
}
