

package gov.nih.nci.camod.domain;


public interface EndpointCode 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getCode();
	   public void setCode( java.lang.String code);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	
	   
	   
	   
	      
	   
	
	
}
