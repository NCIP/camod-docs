

package gov.nih.nci.cadsr.domain;


public interface Qualifier 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	   
	   public  java.lang.String getComments();
	   public void setComments( java.lang.String comments);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getDECPropertyCollection();
	      
		
	public void setDECPropertyCollection(java.util.Collection DECPropertyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDECObjectClassCollection();
	      
		
	public void setDECObjectClassCollection(java.util.Collection DECObjectClassCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getVDRepresentationCollection();
	      
		
	public void setVDRepresentationCollection(java.util.Collection VDRepresentationCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule();
		  
		
	public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule);
		
	
	   
	
	
}
