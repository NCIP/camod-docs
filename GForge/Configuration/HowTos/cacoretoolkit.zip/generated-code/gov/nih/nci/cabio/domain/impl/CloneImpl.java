

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class CloneImpl 
	implements java.io.Serializable, Clone 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.Long insertSize;
	   public  java.lang.Long getInsertSize(){
	      return insertSize;
	   }
	   public void setInsertSize( java.lang.Long insertSize){
	      this.insertSize = insertSize;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection cloneRelativeLocationCollection = new java.util.HashSet();
			public java.util.Collection getCloneRelativeLocationCollection(){
			try{
			   if(cloneRelativeLocationCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Clone thisIdSet = new gov.nih.nci.cabio.domain.impl.CloneImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.CloneRelativeLocation", thisIdSet);				 
				 	cloneRelativeLocationCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Clone:getCloneRelativeLocationCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return cloneRelativeLocationCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setCloneRelativeLocationCollection(java.util.Collection cloneRelativeLocationCollection){
	   		this.cloneRelativeLocationCollection = cloneRelativeLocationCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.Library library;
			public gov.nih.nci.cabio.domain.Library getLibrary(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Clone thisIdSet = new gov.nih.nci.cabio.domain.impl.CloneImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.Library", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                library = (gov.nih.nci.cabio.domain.Library)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Clone:getLibrary throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return library;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setLibrary(gov.nih.nci.cabio.domain.Library library){
		this.library = library;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection nucleicAcidSequenceCollection = new java.util.HashSet();
			public java.util.Collection getNucleicAcidSequenceCollection(){
			try{
			   if(nucleicAcidSequenceCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Clone thisIdSet = new gov.nih.nci.cabio.domain.impl.CloneImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.NucleicAcidSequence", thisIdSet);				 
				 	nucleicAcidSequenceCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Clone:getNucleicAcidSequenceCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return nucleicAcidSequenceCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setNucleicAcidSequenceCollection(java.util.Collection nucleicAcidSequenceCollection){
	   		this.nucleicAcidSequenceCollection = nucleicAcidSequenceCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection taxonCollection = new java.util.HashSet();
			public java.util.Collection getTaxonCollection(){
			try{
			   if(taxonCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Clone thisIdSet = new gov.nih.nci.cabio.domain.impl.CloneImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Taxon", thisIdSet);				 
				 	taxonCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Clone:getTaxonCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return taxonCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setTaxonCollection(java.util.Collection taxonCollection){
	   		this.taxonCollection = taxonCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Clone) {
				Clone c =(Clone)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}