

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class TargetImpl 
	implements java.io.Serializable, Target 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection anomalyCollection = new java.util.HashSet();
			public java.util.Collection getAnomalyCollection(){
			try{
			   if(anomalyCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Target thisIdSet = new gov.nih.nci.cabio.domain.impl.TargetImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Anomaly", thisIdSet);				 
				 	anomalyCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Target:getAnomalyCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return anomalyCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setAnomalyCollection(java.util.Collection anomalyCollection){
	   		this.anomalyCollection = anomalyCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection geneCollection = new java.util.HashSet();
			public java.util.Collection getGeneCollection(){
			try{
			   if(geneCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Target thisIdSet = new gov.nih.nci.cabio.domain.impl.TargetImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Gene", thisIdSet);				 
				 	geneCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Target:getGeneCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return geneCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setGeneCollection(java.util.Collection geneCollection){
	   		this.geneCollection = geneCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection agentCollection = new java.util.HashSet();
			public java.util.Collection getAgentCollection(){
			try{
			   if(agentCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Target thisIdSet = new gov.nih.nci.cabio.domain.impl.TargetImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Agent", thisIdSet);				 
				 	agentCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Target:getAgentCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return agentCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setAgentCollection(java.util.Collection agentCollection){
	   		this.agentCollection = agentCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Target) {
				Target c =(Target)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}