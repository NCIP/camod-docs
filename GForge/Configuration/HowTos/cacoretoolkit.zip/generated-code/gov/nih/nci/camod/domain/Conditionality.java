

package gov.nih.nci.camod.domain;


public interface Conditionality 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getConditionedBy();
	   public void setConditionedBy( java.lang.String conditionedBy);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	
	   
	   
	   
	      
	   
	
	
}
