

package gov.nih.nci.cadsr.domain;


public interface ValueDomain 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getDatatypeName();
	   public void setDatatypeName( java.lang.String datatypeName);
	
	   
	   public  java.lang.String getUOMName();
	   public void setUOMName( java.lang.String UOMName);
	
	   
	   public  java.lang.String getCharacterSetName();
	   public void setCharacterSetName( java.lang.String characterSetName);
	
	   
	   public  java.lang.String getFormatName();
	   public void setFormatName( java.lang.String formatName);
	
	   
	   public  java.lang.Integer getMaximumLengthNumber();
	   public void setMaximumLengthNumber( java.lang.Integer maximumLengthNumber);
	
	   
	   public  java.lang.Integer getMinimumLengthNumber();
	   public void setMinimumLengthNumber( java.lang.Integer minimumLengthNumber);
	
	   
	   public  java.lang.Integer getDecimalPlace();
	   public void setDecimalPlace( java.lang.Integer decimalPlace);
	
	   
	   public  java.lang.String getHighValueNumber();
	   public void setHighValueNumber( java.lang.String highValueNumber);
	
	   
	   public  java.lang.String getLowValueNumber();
	   public void setLowValueNumber( java.lang.String lowValueNumber);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getParentValueDomainRelationshipCollection();
	      
		
	public void setParentValueDomainRelationshipCollection(java.util.Collection parentValueDomainRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getQuestionCollection();
	      
		
	public void setQuestionCollection(java.util.Collection questionCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Qualifier getQualifier();
		  
		
	public void setQualifier(gov.nih.nci.cadsr.domain.Qualifier qualifier);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptualDomain getConceptualDomain();
		  
		
	public void setConceptualDomain(gov.nih.nci.cadsr.domain.ConceptualDomain conceptualDomain);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDataElementCollection();
	      
		
	public void setDataElementCollection(java.util.Collection dataElementCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildValueDomainRelationshipCollection();
	      
		
	public void setChildValueDomainRelationshipCollection(java.util.Collection childValueDomainRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Representation getRepresention();
		  
		
	public void setRepresention(gov.nih.nci.cadsr.domain.Representation represention);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule();
		  
		
	public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule);
		
	
	   
	
	
}
