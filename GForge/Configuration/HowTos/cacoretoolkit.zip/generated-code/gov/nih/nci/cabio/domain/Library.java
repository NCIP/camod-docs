

package gov.nih.nci.cabio.domain;


public interface Library 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getRsite1();
	   public void setRsite1( java.lang.String rsite1);
	
	   
	   public  java.util.Date getCreationDate();
	   public void setCreationDate( java.util.Date creationDate);
	
	   
	   public  java.lang.String getLabHost();
	   public void setLabHost( java.lang.String labHost);
	
	   
	   public  java.lang.String getCloneVector();
	   public void setCloneVector( java.lang.String cloneVector);
	
	   
	   public  java.lang.Long getUniGeneId();
	   public void setUniGeneId( java.lang.Long uniGeneId);
	
	   
	   public  java.lang.Long getClonesToDate();
	   public void setClonesToDate( java.lang.Long clonesToDate);
	
	   
	   public  java.lang.Long getSequencesToDate();
	   public void setSequencesToDate( java.lang.Long sequencesToDate);
	
	   
	   public  java.lang.String getKeyword();
	   public void setKeyword( java.lang.String keyword);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	   
	   public  java.lang.String getCloneProducer();
	   public void setCloneProducer( java.lang.String cloneProducer);
	
	   
	   public  java.lang.String getCloneVectorType();
	   public void setCloneVectorType( java.lang.String cloneVectorType);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.String getRsite2();
	   public void setRsite2( java.lang.String rsite2);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getCloneCollection();
	      
		
	public void setCloneCollection(java.util.Collection cloneCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Protocol getProtocol();
		  
		
	public void setProtocol(gov.nih.nci.cabio.domain.Protocol protocol);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getHistopathologyCollection();
	      
		
	public void setHistopathologyCollection(java.util.Collection histopathologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Tissue getTissue();
		  
		
	public void setTissue(gov.nih.nci.cabio.domain.Tissue tissue);
		
	
	   
	
	
}
