

package gov.nih.nci.cabio.domain;


public interface HomologousAssociation 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.Float getSimilarityPercentage();
	   public void setSimilarityPercentage( java.lang.Float similarityPercentage);
	
	   
	   public  java.lang.Long getHomologousId();
	   public void setHomologousId( java.lang.Long homologousId);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Gene getHomologousGene();
		  
		
	public void setHomologousGene(gov.nih.nci.cabio.domain.Gene homologousGene);
		
	
	   
	
	
}
