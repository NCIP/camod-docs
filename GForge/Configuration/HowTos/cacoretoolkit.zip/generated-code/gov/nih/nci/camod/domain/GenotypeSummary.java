

package gov.nih.nci.camod.domain;


public interface GenotypeSummary 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getSummary();
	   public void setSummary( java.lang.String summary);
	
	   
	   public  java.lang.String getGenotype();
	   public void setGenotype( java.lang.String genotype);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.Nomenclature getNomenclature();
		  
		
	public void setNomenclature(gov.nih.nci.camod.domain.Nomenclature nomenclature);
		
	
	   
	
	   
	   
	   
	      
	   
	
	
}
