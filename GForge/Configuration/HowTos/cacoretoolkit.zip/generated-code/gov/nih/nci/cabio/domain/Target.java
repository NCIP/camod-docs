

package gov.nih.nci.cabio.domain;


public interface Target 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getAnomalyCollection();
	      
		
	public void setAnomalyCollection(java.util.Collection anomalyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getAgentCollection();
	      
		
	public void setAgentCollection(java.util.Collection agentCollection);
		
	   
	
	
}
