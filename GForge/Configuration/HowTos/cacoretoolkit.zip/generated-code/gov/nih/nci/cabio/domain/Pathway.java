

package gov.nih.nci.cabio.domain;


public interface Pathway 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getDiagram();
	   public void setDiagram( java.lang.String diagram);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.String getDisplayValue();
	   public void setDisplayValue( java.lang.String displayValue);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getHistopathologyCollection();
	      
		
	public void setHistopathologyCollection(java.util.Collection histopathologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Taxon getTaxon();
		  
		
	public void setTaxon(gov.nih.nci.cabio.domain.Taxon taxon);
		
	
	   
	
	
}
