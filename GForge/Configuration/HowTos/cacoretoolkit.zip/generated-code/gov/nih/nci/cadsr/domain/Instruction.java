

package gov.nih.nci.cadsr.domain;


public interface Instruction 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Question getQuestion();
		  
		
	public void setQuestion(gov.nih.nci.cadsr.domain.Question question);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.CaseReportForm getCaseReportForm();
		  
		
	public void setCaseReportForm(gov.nih.nci.cadsr.domain.CaseReportForm caseReportForm);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Module getModule();
		  
		
	public void setModule(gov.nih.nci.cadsr.domain.Module module);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ProtocolFormsTemplate getProtocolFormsTemplate();
		  
		
	public void setProtocolFormsTemplate(gov.nih.nci.cadsr.domain.ProtocolFormsTemplate protocolFormsTemplate);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ValidValue getValidValue();
		  
		
	public void setValidValue(gov.nih.nci.cadsr.domain.ValidValue validValue);
		
	
	   
	
	
}
