

package gov.nih.nci.camod.domain;


public interface AnimalModel 



    extends AbstractCancerModel




{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getUrl();
	   public void setUrl( java.lang.String url);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.RepositoryInfo getRepositoryInfo();
		  
		
	public void setRepositoryInfo(gov.nih.nci.camod.domain.RepositoryInfo repositoryInfo);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getXenograftCollection();
	      
		
	public void setXenograftCollection(java.util.Collection xenograftCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getInducedMutationCollection();
	      
		
	public void setInducedMutationCollection(java.util.Collection inducedMutationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTherapyCollection();
	      
		
	public void setTherapyCollection(java.util.Collection therapyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getCellLineCollection();
	      
		
	public void setCellLineCollection(java.util.Collection cellLineCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getMicroArrayDataCollection();
	      
		
	public void setMicroArrayDataCollection(java.util.Collection microArrayDataCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGenomicSegmentCollection();
	      
		
	public void setGenomicSegmentCollection(java.util.Collection genomicSegmentCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getPartyRoleCollection();
	      
		
	public void setPartyRoleCollection(java.util.Collection partyRoleCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getHistopathologyCollection();
	      
		
	public void setHistopathologyCollection(java.util.Collection histopathologyCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.JaxInfo getJaxInfo();
		  
		
	public void setJaxInfo(gov.nih.nci.camod.domain.JaxInfo jaxInfo);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTargetedModificationCollection();
	      
		
	public void setTargetedModificationCollection(java.util.Collection targetedModificationCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.Phenotype getPhenotype();
		  
		
	public void setPhenotype(gov.nih.nci.camod.domain.Phenotype phenotype);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getTransgeneCollection();
	      
		
	public void setTransgeneCollection(java.util.Collection transgeneCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getCarcinogenicInterventionCollection();
	      
		
	public void setCarcinogenicInterventionCollection(java.util.Collection carcinogenicInterventionCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getImageCollection();
	      
		
	public void setImageCollection(java.util.Collection imageCollection);
		
	   
	
	
}
