

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class OrganOntologyRelationshipImpl 
	implements java.io.Serializable, OrganOntologyRelationship 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.OrganOntology childOrganOntology;
			public gov.nih.nci.cabio.domain.OrganOntology getChildOrganOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.OrganOntologyRelationship thisIdSet = new gov.nih.nci.cabio.domain.impl.OrganOntologyRelationshipImpl();
			  thisIdSet.setId(this.getId());
			  
			   List relations = new ArrayList();
			   relations.add(thisIdSet);
			   gov.nih.nci.cabio.domain.OrganOntology obj = new gov.nih.nci.cabio.domain.impl.OrganOntologyImpl();
			   	obj.setParentOrganOntologyRelationshipCollection(relations);
			   
			  try {
			  	java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.OrganOntology", obj);				 
			  	if (resultList!=null && resultList.size()>0) {
			  	childOrganOntology = (gov.nih.nci.cabio.domain.OrganOntology)resultList.get(0);
		          }
			  
			  } catch(Exception ex) 
			  { 
			      	System.out.println("OrganOntologyRelationship:getChildOrganOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return childOrganOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setChildOrganOntology(gov.nih.nci.cabio.domain.OrganOntology childOrganOntology){
		this.childOrganOntology = childOrganOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.OrganOntology parentOrganOntology;
			public gov.nih.nci.cabio.domain.OrganOntology getParentOrganOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.OrganOntologyRelationship thisIdSet = new gov.nih.nci.cabio.domain.impl.OrganOntologyRelationshipImpl();
			  thisIdSet.setId(this.getId());
			  
			   List relations = new ArrayList();
			   relations.add(thisIdSet);
			   gov.nih.nci.cabio.domain.OrganOntology obj = new gov.nih.nci.cabio.domain.impl.OrganOntologyImpl();
			   	obj.setChildOrganOntologyRelationshipCollection(relations);
			   
			  try {
			  	java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.OrganOntology", obj);				 
			  	if (resultList!=null && resultList.size()>0) {
			  	parentOrganOntology = (gov.nih.nci.cabio.domain.OrganOntology)resultList.get(0);
		          }
			  
			  } catch(Exception ex) 
			  { 
			      	System.out.println("OrganOntologyRelationship:getParentOrganOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return parentOrganOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setParentOrganOntology(gov.nih.nci.cabio.domain.OrganOntology parentOrganOntology){
		this.parentOrganOntology = parentOrganOntology;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof OrganOntologyRelationship) {
				OrganOntologyRelationship c =(OrganOntologyRelationship)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}