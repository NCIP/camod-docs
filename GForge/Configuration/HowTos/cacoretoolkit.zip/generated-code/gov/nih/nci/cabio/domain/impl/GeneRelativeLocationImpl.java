

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class GeneRelativeLocationImpl 
	implements java.io.Serializable, GeneRelativeLocation 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String type;
	   public  java.lang.String getType(){
	      return type;
	   }
	   public void setType( java.lang.String type){
	      this.type = type;
	   }
	

	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof GeneRelativeLocation) {
				GeneRelativeLocation c =(GeneRelativeLocation)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}