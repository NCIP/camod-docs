

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class CytobandImpl 
	implements java.io.Serializable, Cytoband 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.PhysicalLocation physicalLocation;
			public gov.nih.nci.cabio.domain.PhysicalLocation getPhysicalLocation(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Cytoband thisIdSet = new gov.nih.nci.cabio.domain.impl.CytobandImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.PhysicalLocation", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                physicalLocation = (gov.nih.nci.cabio.domain.PhysicalLocation)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Cytoband:getPhysicalLocation throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return physicalLocation;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setPhysicalLocation(gov.nih.nci.cabio.domain.PhysicalLocation physicalLocation){
		this.physicalLocation = physicalLocation;
	   }	
	   
	   
	
	   
	   
	   
	      
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Cytoband) {
				Cytoband c =(Cytoband)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}