

package gov.nih.nci.cadsr.domain;


public interface ObjectClass 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getDefinitionSource();
	   public void setDefinitionSource( java.lang.String definitionSource);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getTargetObjectClassRelationshipCollection();
	      
		
	public void setTargetObjectClassRelationshipCollection(java.util.Collection targetObjectClassRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getSourcObjectClassRelationshipCollection();
	      
		
	public void setSourcObjectClassRelationshipCollection(java.util.Collection sourcObjectClassRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDataElementConceptCollection();
	      
		
	public void setDataElementConceptCollection(java.util.Collection dataElementConceptCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptDerivationRule getConceptDerivationRule();
		  
		
	public void setConceptDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule conceptDerivationRule);
		
	
	   
	
	
}
