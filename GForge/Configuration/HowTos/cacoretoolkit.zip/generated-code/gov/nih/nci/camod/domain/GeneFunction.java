

package gov.nih.nci.camod.domain;


public interface GeneFunction 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getFunction();
	   public void setFunction( java.lang.String function);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.EngineeredGene getEngineeredGene();
		  
		
	public void setEngineeredGene(gov.nih.nci.camod.domain.EngineeredGene engineeredGene);
		
	
	   
	
	
}
