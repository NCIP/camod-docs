

package gov.nih.nci.cadsr.domain;


public interface Context 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.lang.Float getVersion();
	   public void setVersion( java.lang.Float version);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	   
	   public  java.lang.String getLanguageName();
	   public void setLanguageName( java.lang.String languageName);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDesignationCollection();
	      
		
	public void setDesignationCollection(java.util.Collection designationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getReferenceDocumentCollection();
	      
		
	public void setReferenceDocumentCollection(java.util.Collection referenceDocumentCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getDefinitionCollection();
	      
		
	public void setDefinitionCollection(java.util.Collection definitionCollection);
		
	   
	
	
}
