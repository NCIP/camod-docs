

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class GeneOntologyRelationshipImpl 
	implements java.io.Serializable, GeneOntologyRelationship 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String relationshipType;
	   public  java.lang.String getRelationshipType(){
	      return relationshipType;
	   }
	   public void setRelationshipType( java.lang.String relationshipType){
	      this.relationshipType = relationshipType;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.GeneOntology childGeneOntology;
			public gov.nih.nci.cabio.domain.GeneOntology getChildGeneOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.GeneOntologyRelationship thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneOntologyRelationshipImpl();
			  thisIdSet.setId(this.getId());
			  
			   List relations = new ArrayList();
			   relations.add(thisIdSet);
			   gov.nih.nci.cabio.domain.GeneOntology obj = new gov.nih.nci.cabio.domain.impl.GeneOntologyImpl();
			   	obj.setParentGeneOntologyRelationshipCollection(relations);
			   
			  try {
			  	java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneOntology", obj);				 
			  	if (resultList!=null && resultList.size()>0) {
			  	childGeneOntology = (gov.nih.nci.cabio.domain.GeneOntology)resultList.get(0);
		          }
			  
			  } catch(Exception ex) 
			  { 
			      	System.out.println("GeneOntologyRelationship:getChildGeneOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return childGeneOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setChildGeneOntology(gov.nih.nci.cabio.domain.GeneOntology childGeneOntology){
		this.childGeneOntology = childGeneOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.GeneOntology parentGeneOntology;
			public gov.nih.nci.cabio.domain.GeneOntology getParentGeneOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.GeneOntologyRelationship thisIdSet = new gov.nih.nci.cabio.domain.impl.GeneOntologyRelationshipImpl();
			  thisIdSet.setId(this.getId());
			  
			   List relations = new ArrayList();
			   relations.add(thisIdSet);
			   gov.nih.nci.cabio.domain.GeneOntology obj = new gov.nih.nci.cabio.domain.impl.GeneOntologyImpl();
			   	obj.setChildGeneOntologyRelationshipCollection(relations);
			   
			  try {
			  	java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.GeneOntology", obj);				 
			  	if (resultList!=null && resultList.size()>0) {
			  	parentGeneOntology = (gov.nih.nci.cabio.domain.GeneOntology)resultList.get(0);
		          }
			  
			  } catch(Exception ex) 
			  { 
			      	System.out.println("GeneOntologyRelationship:getParentGeneOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return parentGeneOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setParentGeneOntology(gov.nih.nci.cabio.domain.GeneOntology parentGeneOntology){
		this.parentGeneOntology = parentGeneOntology;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof GeneOntologyRelationship) {
				GeneOntologyRelationship c =(GeneOntologyRelationship)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}