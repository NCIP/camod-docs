

package gov.nih.nci.cadsr.domain;


public interface ComponentConcept 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.Integer getDisplayOrder();
	   public void setDisplayOrder( java.lang.Integer displayOrder);
	
	   
	   public  java.lang.String getPrimaryFlag();
	   public void setPrimaryFlag( java.lang.String primaryFlag);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.Concept getConcept();
		  
		
	public void setConcept(gov.nih.nci.cadsr.domain.Concept concept);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ConceptDerivationRule getDerivationRule();
		  
		
	public void setDerivationRule(gov.nih.nci.cadsr.domain.ConceptDerivationRule derivationRule);
		
	
	   
	
	
}
