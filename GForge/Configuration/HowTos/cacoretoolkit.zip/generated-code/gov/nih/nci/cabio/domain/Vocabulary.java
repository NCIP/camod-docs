

package gov.nih.nci.cabio.domain;


public interface Vocabulary 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getCoreTerm();
	   public void setCoreTerm( java.lang.String coreTerm);
	
	   
	   public  java.lang.String getGeneralTerm();
	   public void setGeneralTerm( java.lang.String generalTerm);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getAnomalyCollection();
	      
		
	public void setAnomalyCollection(java.util.Collection anomalyCollection);
		
	   
	
	
}
