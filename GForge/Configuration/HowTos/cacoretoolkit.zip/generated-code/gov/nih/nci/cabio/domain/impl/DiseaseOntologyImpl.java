

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class DiseaseOntologyImpl 
	implements java.io.Serializable, DiseaseOntology 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection clinicalTrialProtocolCollection = new java.util.HashSet();
			public java.util.Collection getClinicalTrialProtocolCollection(){
			try{
			   if(clinicalTrialProtocolCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.DiseaseOntology thisIdSet = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.ClinicalTrialProtocol", thisIdSet);				 
				 	clinicalTrialProtocolCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("DiseaseOntology:getClinicalTrialProtocolCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return clinicalTrialProtocolCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setClinicalTrialProtocolCollection(java.util.Collection clinicalTrialProtocolCollection){
	   		this.clinicalTrialProtocolCollection = clinicalTrialProtocolCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
			private java.util.Collection childDiseaseOntologyRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getChildDiseaseOntologyRelationshipCollection(){
			try{
			   if(childDiseaseOntologyRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
			         	gov.nih.nci.cabio.domain.DiseaseOntology thisIdSet = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyImpl();
			         	thisIdSet.setId(this.getId()); 
			         	gov.nih.nci.cabio.domain.DiseaseOntologyRelationship obj = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyRelationshipImpl();
				 	
				 	        obj.setParentDiseaseOntology(thisIdSet);
				 	
				 	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.DiseaseOntologyRelationship", obj);				 
				 	
				 	childDiseaseOntologyRelationshipCollection = resultList;  
				 	return resultList;
			         
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("DiseaseOntology:getChildDiseaseOntologyRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return childDiseaseOntologyRelationshipCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setChildDiseaseOntologyRelationshipCollection(java.util.Collection childDiseaseOntologyRelationshipCollection){
	   		this.childDiseaseOntologyRelationshipCollection = childDiseaseOntologyRelationshipCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection histopathologyCollection = new java.util.HashSet();
			public java.util.Collection getHistopathologyCollection(){
			try{
			   if(histopathologyCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.DiseaseOntology thisIdSet = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Histopathology", thisIdSet);				 
				 	histopathologyCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("DiseaseOntology:getHistopathologyCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return histopathologyCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setHistopathologyCollection(java.util.Collection histopathologyCollection){
	   		this.histopathologyCollection = histopathologyCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection parentDiseaseOntologyRelationshipCollection = new java.util.HashSet();
			public java.util.Collection getParentDiseaseOntologyRelationshipCollection(){
			try{
			   if(parentDiseaseOntologyRelationshipCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
			         	gov.nih.nci.cabio.domain.DiseaseOntology thisIdSet = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyImpl();
			         	thisIdSet.setId(this.getId()); 
			         	gov.nih.nci.cabio.domain.DiseaseOntologyRelationship obj = new gov.nih.nci.cabio.domain.impl.DiseaseOntologyRelationshipImpl();
				 	
				 		obj.setChildDiseaseOntology(thisIdSet);
				 	
				 	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.DiseaseOntologyRelationship", obj);				 
				 	
				 	parentDiseaseOntologyRelationshipCollection = resultList;  
				 	return resultList;
			         
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("DiseaseOntology:getParentDiseaseOntologyRelationshipCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return parentDiseaseOntologyRelationshipCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setParentDiseaseOntologyRelationshipCollection(java.util.Collection parentDiseaseOntologyRelationshipCollection){
	   		this.parentDiseaseOntologyRelationshipCollection = parentDiseaseOntologyRelationshipCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof DiseaseOntology) {
				DiseaseOntology c =(DiseaseOntology)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}