

package gov.nih.nci.camod.domain;


public interface Image 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getTitle();
	   public void setTitle( java.lang.String title);
	
	   
	   public  java.lang.String getDescription();
	   public void setDescription( java.lang.String description);
	
	   
	   public  java.lang.String getStaining();
	   public void setStaining( java.lang.String staining);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.camod.domain.Availability getAvailability();
		  
		
	public void setAvailability(gov.nih.nci.camod.domain.Availability availability);
		
	
	   
	
	   
	   
	   
	      
	   
	
	
}
