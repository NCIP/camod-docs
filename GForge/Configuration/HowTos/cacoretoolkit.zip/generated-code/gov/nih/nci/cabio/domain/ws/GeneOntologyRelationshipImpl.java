

package gov.nih.nci.cabio.domain.ws;
import gov.nih.nci.cabio.domain.ws.*;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class GeneOntologyRelationshipImpl 
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String relationshipType;
	   public  java.lang.String getRelationshipType(){
	      return relationshipType;
	   }
	   
	   public void setRelationshipType( java.lang.String relationshipType){
	      this.relationshipType = relationshipType;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.GeneOntologyImpl childGeneOntology;
			public gov.nih.nci.cabio.domain.ws.GeneOntologyImpl getChildGeneOntology(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setChildGeneOntology(gov.nih.nci.cabio.domain.ws.GeneOntologyImpl childGeneOntology){
		this.childGeneOntology = childGeneOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.GeneOntologyImpl parentGeneOntology;
			public gov.nih.nci.cabio.domain.ws.GeneOntologyImpl getParentGeneOntology(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setParentGeneOntology(gov.nih.nci.cabio.domain.ws.GeneOntologyImpl parentGeneOntology){
		this.parentGeneOntology = parentGeneOntology;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof GeneOntologyRelationship) {
				GeneOntologyRelationship c =(GeneOntologyRelationship)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
