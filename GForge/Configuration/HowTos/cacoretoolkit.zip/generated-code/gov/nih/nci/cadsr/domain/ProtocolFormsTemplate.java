

package gov.nih.nci.cadsr.domain;


public interface ProtocolFormsTemplate 



    extends AdministeredComponent




{
	
	   
	   public  java.lang.String getDisplayName();
	   public void setDisplayName( java.lang.String displayName);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getInstructionCollection();
	      
		
	public void setInstructionCollection(java.util.Collection instructionCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getModuleCollection();
	      
		
	public void setModuleCollection(java.util.Collection moduleCollection);
		
	   
	
	
}
