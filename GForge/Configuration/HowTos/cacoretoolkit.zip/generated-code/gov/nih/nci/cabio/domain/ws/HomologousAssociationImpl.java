

package gov.nih.nci.cabio.domain.ws;
import gov.nih.nci.cabio.domain.ws.*;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class HomologousAssociationImpl 
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.Float similarityPercentage;
	   public  java.lang.Float getSimilarityPercentage(){
	      return similarityPercentage;
	   }
	   
	   public void setSimilarityPercentage( java.lang.Float similarityPercentage){
	      this.similarityPercentage = similarityPercentage;
	   }
	
	   
	   public java.lang.Long homologousId;
	   public  java.lang.Long getHomologousId(){
	      return homologousId;
	   }
	   
	   public void setHomologousId( java.lang.Long homologousId){
	      this.homologousId = homologousId;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.ws.GeneImpl homologousGene;
			public gov.nih.nci.cabio.domain.ws.GeneImpl getHomologousGene(){
			  return null;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setHomologousGene(gov.nih.nci.cabio.domain.ws.GeneImpl homologousGene){
		this.homologousGene = homologousGene;
	   }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof HomologousAssociation) {
				HomologousAssociation c =(HomologousAssociation)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}
