

package gov.nih.nci.cabio.domain;


public interface PhysicalLocation 



    extends Location




{
	
	   
	   public  java.lang.Long getChromosomalStartPosition();
	   public void setChromosomalStartPosition( java.lang.Long chromosomalStartPosition);
	
	   
	   public  java.lang.Long getChromosomalEndPosition();
	   public void setChromosomalEndPosition( java.lang.Long chromosomalEndPosition);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getCytobandCollection();
	      
		
	public void setCytobandCollection(java.util.Collection cytobandCollection);
		
	   
	
	
}
