

package gov.nih.nci.cabio.domain;


public interface DiseaseOntology 




    extends Ontology



{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getClinicalTrialProtocolCollection();
	      
		
	public void setClinicalTrialProtocolCollection(java.util.Collection clinicalTrialProtocolCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getChildDiseaseOntologyRelationshipCollection();
	      
		
	public void setChildDiseaseOntologyRelationshipCollection(java.util.Collection childDiseaseOntologyRelationshipCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getHistopathologyCollection();
	      
		
	public void setHistopathologyCollection(java.util.Collection histopathologyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getParentDiseaseOntologyRelationshipCollection();
	      
		
	public void setParentDiseaseOntologyRelationshipCollection(java.util.Collection parentDiseaseOntologyRelationshipCollection);
		
	   
	
	
}
