

package gov.nih.nci.camod.domain;


public interface Availability 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.util.Date getEnteredDate();
	   public void setEnteredDate( java.util.Date enteredDate);
	
	   
	   public  java.lang.String getVisibleTo();
	   public void setVisibleTo( java.lang.String visibleTo);
	
	   
	   public  java.util.Date getModifiedDate();
	   public void setModifiedDate( java.util.Date modifiedDate);
	
	   
	   public  java.util.Date getReleaseDate();
	   public void setReleaseDate( java.util.Date releaseDate);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	   
	
	
}
