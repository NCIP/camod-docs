

package gov.nih.nci.camod.domain;


public interface EnvironmentalFactor 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getInducedMutationCollection();
	      
		
	public void setInducedMutationCollection(java.util.Collection inducedMutationCollection);
		
	   
	
	   
	   
	   
	      
	   
	
	
}
