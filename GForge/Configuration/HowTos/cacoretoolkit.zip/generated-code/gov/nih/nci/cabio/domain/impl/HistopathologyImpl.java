

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class HistopathologyImpl 
	implements java.io.Serializable, Histopathology 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String comments;
	   public  java.lang.String getComments(){
	      return comments;
	   }
	   public void setComments( java.lang.String comments){
	      this.comments = comments;
	   }
	
	   
	   public java.lang.String grossDescription;
	   public  java.lang.String getGrossDescription(){
	      return grossDescription;
	   }
	   public void setGrossDescription( java.lang.String grossDescription){
	      this.grossDescription = grossDescription;
	   }
	
	   
	   public java.lang.String relationalOperation;
	   public  java.lang.String getRelationalOperation(){
	      return relationalOperation;
	   }
	   public void setRelationalOperation( java.lang.String relationalOperation){
	      this.relationalOperation = relationalOperation;
	   }
	
	   
	   public java.lang.Float tumorIncidenceRate;
	   public  java.lang.Float getTumorIncidenceRate(){
	      return tumorIncidenceRate;
	   }
	   public void setTumorIncidenceRate( java.lang.Float tumorIncidenceRate){
	      this.tumorIncidenceRate = tumorIncidenceRate;
	   }
	
	   
	   public java.lang.String survivalInfo;
	   public  java.lang.String getSurvivalInfo(){
	      return survivalInfo;
	   }
	   public void setSurvivalInfo( java.lang.String survivalInfo){
	      this.survivalInfo = survivalInfo;
	   }
	
	   
	   public java.lang.String ageOfOnset;
	   public  java.lang.String getAgeOfOnset(){
	      return ageOfOnset;
	   }
	   public void setAgeOfOnset( java.lang.String ageOfOnset){
	      this.ageOfOnset = ageOfOnset;
	   }
	
	   
	   public java.lang.String microscopicDescription;
	   public  java.lang.String getMicroscopicDescription(){
	      return microscopicDescription;
	   }
	   public void setMicroscopicDescription( java.lang.String microscopicDescription){
	      this.microscopicDescription = microscopicDescription;
	   }
	

	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.DiseaseOntology diseaseOntology;
			public gov.nih.nci.cabio.domain.DiseaseOntology getDiseaseOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Histopathology thisIdSet = new gov.nih.nci.cabio.domain.impl.HistopathologyImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.DiseaseOntology", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                diseaseOntology = (gov.nih.nci.cabio.domain.DiseaseOntology)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Histopathology:getDiseaseOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return diseaseOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology diseaseOntology){
		this.diseaseOntology = diseaseOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection anomalyCollection = new java.util.HashSet();
			public java.util.Collection getAnomalyCollection(){
			try{
			   if(anomalyCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Histopathology thisIdSet = new gov.nih.nci.cabio.domain.impl.HistopathologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Anomaly", thisIdSet);				 
				 	anomalyCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Histopathology:getAnomalyCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return anomalyCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setAnomalyCollection(java.util.Collection anomalyCollection){
	   		this.anomalyCollection = anomalyCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection clinicalTrialProtocolCollection = new java.util.HashSet();
			public java.util.Collection getClinicalTrialProtocolCollection(){
			try{
			   if(clinicalTrialProtocolCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Histopathology thisIdSet = new gov.nih.nci.cabio.domain.impl.HistopathologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.ClinicalTrialProtocol", thisIdSet);				 
				 	clinicalTrialProtocolCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Histopathology:getClinicalTrialProtocolCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return clinicalTrialProtocolCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setClinicalTrialProtocolCollection(java.util.Collection clinicalTrialProtocolCollection){
	   		this.clinicalTrialProtocolCollection = clinicalTrialProtocolCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection libraryCollection = new java.util.HashSet();
			public java.util.Collection getLibraryCollection(){
			try{
			   if(libraryCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Histopathology thisIdSet = new gov.nih.nci.cabio.domain.impl.HistopathologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Library", thisIdSet);				 
				 	libraryCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Histopathology:getLibraryCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return libraryCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setLibraryCollection(java.util.Collection libraryCollection){
	   		this.libraryCollection = libraryCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection geneCollection = new java.util.HashSet();
			public java.util.Collection getGeneCollection(){
			try{
			   if(geneCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Histopathology thisIdSet = new gov.nih.nci.cabio.domain.impl.HistopathologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Gene", thisIdSet);				 
				 	geneCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Histopathology:getGeneCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return geneCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setGeneCollection(java.util.Collection geneCollection){
	   		this.geneCollection = geneCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
			
			
			
			
			private gov.nih.nci.cabio.domain.OrganOntology organOntology;
			public gov.nih.nci.cabio.domain.OrganOntology getOrganOntology(){
                          ApplicationService applicationService = ApplicationService.getApplicationService();
			  gov.nih.nci.cabio.domain.Histopathology thisIdSet = new gov.nih.nci.cabio.domain.impl.HistopathologyImpl();
			  thisIdSet.setId(this.getId());
			  
			  try {
			     java.util.List resultList = applicationService.search("gov.nih.nci.cabio.domain.OrganOntology", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0) {
		                organOntology = (gov.nih.nci.cabio.domain.OrganOntology)resultList.get(0);
		             }
		          
			  } catch(Exception ex) 
			  { 
			      	System.out.println("Histopathology:getOrganOntology throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return organOntology;			
                        }
		   
	      
	               
	   
	   
	   
	   public void setOrganOntology(gov.nih.nci.cabio.domain.OrganOntology organOntology){
		this.organOntology = organOntology;
	   }	
	   
	   
	
	   
	   
	   
	      
			private java.util.Collection metastasisCollection = new java.util.HashSet();
			public java.util.Collection getMetastasisCollection(){
			try{
			   if(metastasisCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.Histopathology thisIdSet = new gov.nih.nci.cabio.domain.impl.HistopathologyImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Histopathology", thisIdSet);				 
				 	metastasisCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("Histopathology:getMetastasisCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return metastasisCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setMetastasisCollection(java.util.Collection metastasisCollection){
	   		this.metastasisCollection = metastasisCollection;
	        }	
	   
	   
	
	   
	   
	   
	      
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Histopathology) {
				Histopathology c =(Histopathology)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}