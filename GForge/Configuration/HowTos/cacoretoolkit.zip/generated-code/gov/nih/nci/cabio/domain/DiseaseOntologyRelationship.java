

package gov.nih.nci.cabio.domain;


public interface DiseaseOntologyRelationship 





    extends OntologyRelationship


{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.DiseaseOntology getChildDiseaseOntology();
		  
		
	public void setChildDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology childDiseaseOntology);
		
	
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.DiseaseOntology getParentDiseaseOntology();
		  
		
	public void setParentDiseaseOntology(gov.nih.nci.cabio.domain.DiseaseOntology parentDiseaseOntology);
		
	
	   
	
	
}
