

package gov.nih.nci.cadsr.domain;


public interface ConceptDerivationRule 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.lang.String getName();
	   public void setName( java.lang.String name);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getQualifierCollection();
	      
		
	public void setQualifierCollection(java.util.Collection qualifierCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getValueMeaningCollection();
	      
		
	public void setValueMeaningCollection(java.util.Collection valueMeaningCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getValueDomainCollection();
	      
		
	public void setValueDomainCollection(java.util.Collection valueDomainCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.DerivationType getDerivationType();
		  
		
	public void setDerivationType(gov.nih.nci.cadsr.domain.DerivationType derivationType);
		
	
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getPropertyCollection();
	      
		
	public void setPropertyCollection(java.util.Collection propertyCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getObjectClassCollection();
	      
		
	public void setObjectClassCollection(java.util.Collection objectClassCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getComponentConceptCollection();
	      
		
	public void setComponentConceptCollection(java.util.Collection componentConceptCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getRepresentationCollection();
	      
		
	public void setRepresentationCollection(java.util.Collection representationCollection);
		
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getConceptualDomainCollection();
	      
		
	public void setConceptualDomainCollection(java.util.Collection conceptualDomainCollection);
		
	   
	
	
}
