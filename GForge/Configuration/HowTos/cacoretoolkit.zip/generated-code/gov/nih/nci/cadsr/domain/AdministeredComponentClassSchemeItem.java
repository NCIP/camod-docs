

package gov.nih.nci.cadsr.domain;


public interface AdministeredComponentClassSchemeItem 







{
	
	   
	   public  java.lang.String getId();
	   public void setId( java.lang.String id);
	
	   
	   public  java.util.Date getDateCreated();
	   public void setDateCreated( java.util.Date dateCreated);
	
	   
	   public  java.util.Date getDateModified();
	   public void setDateModified( java.util.Date dateModified);
	
	   
	   public  java.lang.String getModifiedBy();
	   public void setModifiedBy( java.lang.String modifiedBy);
	
	   
	   public  java.lang.String getCreatedBy();
	   public void setCreatedBy( java.lang.String createdBy);
	
	
	   
	   
	   
	      
	
        public gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem getClassSchemeClassSchemeItem();
		  
		
	public void setClassSchemeClassSchemeItem(gov.nih.nci.cadsr.domain.ClassSchemeClassSchemeItem classSchemeClassSchemeItem);
		
	
	   
	
	   
	   
	   
	      
	   
	
	
}
