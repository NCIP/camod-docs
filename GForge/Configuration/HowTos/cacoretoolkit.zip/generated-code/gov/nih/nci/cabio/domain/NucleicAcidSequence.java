

package gov.nih.nci.cabio.domain;


public interface NucleicAcidSequence 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	   
	   public  java.lang.String getAccessionNumber();
	   public void setAccessionNumber( java.lang.String accessionNumber);
	
	   
	   public  java.lang.String getAccessionNumberVersion();
	   public void setAccessionNumberVersion( java.lang.String accessionNumberVersion);
	
	   
	   public  java.lang.String getType();
	   public void setType( java.lang.String type);
	
	   
	   public  java.lang.String getValue();
	   public void setValue( java.lang.String value);
	
	   
	   public  java.lang.Long getLength();
	   public void setLength( java.lang.Long length);
	
	
	   
	   
	   
	      
	
	public java.util.Collection getDatabaseCrossReferenceCollection();
	      
		
	public void setDatabaseCrossReferenceCollection(java.util.Collection databaseCrossReferenceCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.CloneRelativeLocation getCloneRelativeLocation();
		  
		
	public void setCloneRelativeLocation(gov.nih.nci.cabio.domain.CloneRelativeLocation cloneRelativeLocation);
		
	
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getGeneCollection();
	      
		
	public void setGeneCollection(java.util.Collection geneCollection);
		
	   
	
	   
	   
	   
	      
	
        public gov.nih.nci.cabio.domain.Location getLocation();
		  
		
	public void setLocation(gov.nih.nci.cabio.domain.Location location);
		
	
	   
	
	
}
