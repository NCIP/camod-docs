

package gov.nih.nci.camod.domain;


public interface ExpressionFeature 







{
	
	   
	   public  java.lang.Long getId();
	   public void setId( java.lang.Long id);
	
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	   
	
	   
	   
	   
	      
	
	public java.util.Collection getOrganOntologyCollection();
	      
		
	public void setOrganOntologyCollection(java.util.Collection organOntologyCollection);
		
	   
	
	
}
