

package gov.nih.nci.cabio.domain.impl;
import gov.nih.nci.cabio.domain.*;
import gov.nih.nci.system.applicationservice.*;
import java.util.*;

public  class ProteinAliasImpl 
	implements java.io.Serializable, ProteinAlias 
{
	private static final long serialVersionUID = 1234567890L;

	
	   
	   public java.lang.Long id;
	   public  java.lang.Long getId(){
	      return id;
	   }
	   public void setId( java.lang.Long id){
	      this.id = id;
	   }
	
	   
	   public java.lang.String name;
	   public  java.lang.String getName(){
	      return name;
	   }
	   public void setName( java.lang.String name){
	      this.name = name;
	   }
	

	
	   
	   
	   
	      
			private java.util.Collection proteinCollection = new java.util.HashSet();
			public java.util.Collection getProteinCollection(){
			try{
			   if(proteinCollection.size() == 0) {}
		           } catch(Exception e) {			     
			      ApplicationService applicationService = ApplicationService.getApplicationService();
			      try {
			      
			      
			         
				 	gov.nih.nci.cabio.domain.ProteinAlias thisIdSet = new gov.nih.nci.cabio.domain.impl.ProteinAliasImpl();
			         	thisIdSet.setId(this.getId());
			         	java.util.Collection resultList = applicationService.search("gov.nih.nci.cabio.domain.Protein", thisIdSet);				 
				 	proteinCollection = resultList;  
				 	return resultList;
				 
			      
			      }catch(Exception ex) 
			      {
			      	System.out.println("ProteinAlias:getProteinCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return proteinCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setProteinCollection(java.util.Collection proteinCollection){
	   		this.proteinCollection = proteinCollection;
	        }	
	   
	   
	

	public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ProteinAlias) {
				ProteinAlias c =(ProteinAlias)obj; 			 
				Long thisId = getId();			
				if(thisId != null && thisId.equals(c.getId())) {
					eq = true;
				}		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			if(getId() != null) {
				h += getId().hashCode();
			}
			return h;
	}
	
	
}