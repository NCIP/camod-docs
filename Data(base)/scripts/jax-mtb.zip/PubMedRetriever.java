/**
  * This class ....
  *
  * @author      Johnita Beasley (SAIC/NCICB Contractor)
  * @version     $Revision: 1.4 $
  */

  import java.io.*;
  import java.util.*;

public class PubMedRetriever
{

  // ****************************************************
  //                     CONSTRUCTOR
  // ****************************************************

    public PubMedRetriever(){}


  // ****************************************************
  //                       METHODS
  // ****************************************************

    public void run()
    {
		ArrayList jaxPubRefs = null;
		HashMap jaxPmidJnumMap = null;
    	PrintWriter pw = null;
		String jnumber = null;
		String pmid = null;
		StringTokenizer st = null;
		int nopmidCount = 0;

		try {

			// Get the Jax PMID-JNUMBER Mapping
			jaxPmidJnumMap = getJaxPmidJnumMap();

			// Query database JACKSON_LAB_TMP table for J_NUMBERS (References)
			Database db = new Database();
			jaxPubRefs = db.getJaxPubReferences();

 			pw = new PrintWriter(new BufferedWriter(new FileWriter("c:\\temp\\pubmeddata-pmids.txt")));

			// For each J_NUMBER, use the PMID-JNUMBER mapping to pull the PMID
			for ( int i=0; i < jaxPubRefs.size(); i++ )
			{
				jnumber = (String)jaxPubRefs.get(i);
				System.out.println("\nThe Jax Table Reference value is: " + jnumber);

				if ( jnumber != null ) {
					if ( jnumber.contains("|") ) {
						st = new StringTokenizer(jnumber, "|");
						while (st.hasMoreTokens()) {
							pmid = (String)jaxPmidJnumMap.get(st.nextToken());
							if ( pmid == null )
							{
								nopmidCount++;
								continue;
							}
							System.out.println("\nRetrieved " + pmid + " for jnumber " + jnumber);
							pw.println(getPubDataToPrint(retrievePubMedData(pmid), pmid, jnumber));
						}
					}
					else {

						pmid = (String)jaxPmidJnumMap.get(jnumber);
						if ( pmid == null )
							{
								nopmidCount++;
								continue;
							}
						System.out.println("\nRetrieved " + pmid + " for jnumber " + jnumber);
						pw.println(getPubDataToPrint(retrievePubMedData(pmid), pmid, jnumber));
					}
				}
			}
			System.out.println("===> SUMMARY ");
			System.out.println("===> The number of records without a PMID is " + nopmidCount);

			// Close the outout file
			pw.flush();
			pw.close();

		} catch (IOException ioe) {
		}
	}


    public void test()
    {
		ArrayList jaxPubRefs = null;
		HashMap jaxPmidJnumMap = null;
    	PrintWriter pw = null;
		String jnumber = null;
		String pmid = null;
		StringTokenizer st = null;

		try {

			// Get the Jax PMID-JNUMBER Mapping
			jaxPmidJnumMap = getJaxPmidJnumMap();

			// Query database JACKSON_LAB_TMP table for J_NUMBERS (References)
			Database db = new Database();
			jaxPubRefs = db.getJaxPubReferences();

 			//pw = new PrintWriter(new BufferedWriter(new FileWriter("c:\\temp\\pubmeddata-pmids.txt")));

			// For each J_NUMBER, use the PMID-JNUMBER mapping to pull the PMID
			//for ( int i=0; i < jaxPubRefs.size(); i++ )
			for ( int i=0; i < 10; i++ )
			{
				jnumber = (String)jaxPubRefs.get(i);
				System.out.println("\nThe Jax Table Reference value is: " + jnumber);

				if ( jnumber != null ) {
					if ( jnumber.contains("|") ) {
						st = new StringTokenizer(jnumber, "|");
						while (st.hasMoreTokens()) {
							pmid = (String)jaxPmidJnumMap.get(st.nextToken());
							if ( pmid == null )
								continue;
							//System.out.println("\nRetrieved " + pmid + " for jnumber " + jnumber);
							retrievePubMedData(pmid);
						}
					}
					else {

						pmid = (String)jaxPmidJnumMap.get(jnumber);
						if ( pmid == null )
							continue;
						//System.out.println("\nRetrieved " + pmid + " for jnumber " + jnumber);
						retrievePubMedData(pmid);
					}
				}
			}

			// Close the outout file
			//pw.flush();
			//pw.close();

		} catch (Exception e) {
		}
	}


    public HashMap getJaxPmidJnumMap()
    {
		HashMap map = new HashMap();

		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		PrintWriter pw = null;

		String data = null;
		String pmid = null;
		String jnumber = null;

		try {

			fis = new FileInputStream("c:\\temp\\pmids.txt");
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);

			// Read the PMIDs.
			System.out.println("\nThe PMID-JNUMBER Mapping is as follows:");
  			while ( (data=dis.readLine()) != null ) {

				System.out.println("\nThe PMID-JNUMBER Mapping data read is : " + data);
				pmid = data.substring(0, data.indexOf(",")).trim();
				System.out.println("\nThe PMID is : " + pmid);
				jnumber = data.substring(data.indexOf(",") + 1).trim();
				System.out.println("\nThe JNUMBER is : " + jnumber);

				map.put(jnumber, pmid);
				System.out.println(jnumber + "<==>" + pmid);
  	 		}

		} catch (IOException e) {
		  //
 		  // put your error-handling code here
 		  //
		}
		return map;
	}


    public Publication retrievePubMedData(String pmid)
    {
		Publication pub = new Publication();

		try {

			pub = new Publication();

			// Retrieve the PubMed details associated with the current PMID
			PopulatePubMedUtil.populatePubMedRecord(Long.valueOf(pmid), pub);

		} catch (Exception e) {
		  //
 		  // put your error-handling code here
 		  //
		}

		return pub;
	}

    public String getPubDataToPrint(Publication pub, String pmid, String jnumber)
    {
		StringBuffer outStr = null;

		outStr = new StringBuffer();

		// Write the details to a file
		if ( (pub.getVolume() == null) ||
		   	 (pub.getVolume() != null && (pub.getVolume().length() <= 0 || pub.getVolume().equals("null"))) )
			outStr.append(" \"\" ");
		else
		   	outStr.append("\"" + pub.getVolume() + "\" ");

		if ( pub.getEndPage() == null)
			outStr.append(" \"\" ");
		else
		   	outStr.append("\"" + pub.getEndPage() + "\" ");

		if ( pub.getYear() == null )
			outStr.append(" \"\" ");
		else
		   	outStr.append("\"" + pub.getYear() + "\" ");

		String theTitle = pub.getTitle().replace('\'', ' ');
		outStr.append("\"" + theTitle.replace('\n', ' ') + "\" ");
		outStr.append("\"" + pmid + "\" ");

		if ( pub.getStartPage() == null )
			outStr.append(" \"\" ");
		else
		   	outStr.append("\"" + pub.getStartPage() + "\" ");

		if ( (pub.getJournal() == null) ||
		   	 (pub.getJournal() != null && (pub.getJournal().length() <= 0 || pub.getJournal().equals("null"))) )
			outStr.append(" \"\" ");
		else
		   	outStr.append("\"" + pub.getJournal() + "\" ");

		if ( pub.getAuthors() == null || pub.getAuthors().length() <= 0 )
			outStr.append(" \"\" ");
		else
		  	outStr.append("\"" + pub.getAuthors() + "\" ");

		outStr.append("\"" + jnumber + "\" ");
		outStr.append("\"1\"");

		return outStr.toString();
	}


    public static void main(String args[])
    {
        System.out.println("Retrieving PubMed Data ...");

        PubMedRetriever pubMedRetriever = new PubMedRetriever();
        //Publication pub = pubMedRetriever.retrievePubMedData("4351393");
        pubMedRetriever.run();
        //pubMedRetriever.test();
    }
}

