public  class Publication
	implements java.io.Serializable
{
	private static final long serialVersionUID = 1234567890L;

	   private Long publicationId;
	   public Long getPublicationId(){
	      return publicationId;
	   }
	   public void setPublicationId(Long publicationId){
	      this.publicationId = publicationId;
	   }

	   private String jnumber;
	   public String getJNumber(){
	      return jnumber;
	   }
	   public void setJNumber(String jnumber){
	      this.jnumber = jnumber;
	   }

	   private String volume;
	   public String getVolume(){
	      return volume;
	   }
	   public void setVolume(String volume){
	      this.volume = volume;
	   }


	   private Long endPage;
	   public Long getEndPage(){
	      return endPage;
	   }
	   public void setEndPage(Long endPage){
	      this.endPage = endPage;
	   }


	   private Long startPage;
	   public Long getStartPage(){
	      return startPage;
	   }
	   public void setStartPage(Long startPage){
	      this.startPage = startPage;
	   }


	   private Long year;
	   public Long getYear(){
	      return year;
	   }
	   public void setYear(Long year){
	      this.year = year;
	   }


	   private String authors;
	   public String getAuthors(){
	      return authors;
	   }
	   public void setAuthors(String authors){
	      this.authors = authors;
	   }


	   private String title;
	   public String getTitle(){
	      return title;
	   }
	   public void setTitle(String title){
	      this.title = title;
	   }


	   private String journal;
	   public String getJournal(){
	      return journal;
	   }
	   public void setJournal(String journal){
	      this.journal = journal;
	   }


	   private String pubMedLink;
	   public String getPubMedLink(){
	      return pubMedLink;
	   }
	   public void setPubMedLink(String pubMedLink){
	      this.pubMedLink = pubMedLink;
	   }

}