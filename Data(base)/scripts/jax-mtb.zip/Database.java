  // Java SDK Classes
  import java.sql.*;
  import java.util.*;

public class Database {

	private Connection connection = null;

	public Database()
	{
		connection = getConnection();
		System.out.println("\nInstantiating database obj.... " + connection);
	}


	private void setConnection(Connection theConnection)
	{
		this.connection = theConnection;
	}


	private Connection getConnection()
	{
		try
		{
			if ( connection == null )
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				setConnection(DriverManager.getConnection("jdbc:oracle:thin:@cbiodb2-d.nci.nih.gov:1521:CADEV", "camoddev22", "dev!234"));
			}
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			se.printStackTrace();
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
		return this.connection;
	}

	public void close()
	{
		try{
			connection.close();
		} catch(SQLException e) {
		}
	}


	// ==================================================================================================
	//                               BEGIN...JAX PUB REFERENCE RETREIVAL...BEGIN
	// ==================================================================================================


	/**
	 * Determine the max index in the specified table
	 */
	public ArrayList getJaxPubReferences()
	{
		ArrayList jaxPubRefs = null;

		try {
			String jaxPubRefsSql = "SELECT DISTINCT jlt.REFERENCES FROM JACKSON_LAB_TMP jlt";
			PreparedStatement pstmtJaxPubRefs = connection.prepareStatement(jaxPubRefsSql);

			ResultSet rs = pstmtJaxPubRefs.executeQuery();

			jaxPubRefs = new ArrayList();
			System.out.println("\n\n>>>> The Jax Publication references are as follows: ");
			while ( rs.next() ) {
				jaxPubRefs.add(rs.getString(1));
				System.out.println(rs.getString(1));
			}

			// Close the statement.
		  	pstmtJaxPubRefs.close();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return jaxPubRefs;
	}


	// ==================================================================================================
	//                                END...JAX PUB REFERENCE RETREIVAL...END
	// ==================================================================================================
}
