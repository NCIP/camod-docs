#!/bin/sh
export BASE_DIR=/home/thulasik/caMOD
export DATA_DIR=/home/thulasik/caMOD/data
export INDEX_DIR=/home/thulasik/caMOD/indexes
export CONSTRAINTS_DIR=/home/thulasik/caMOD/constraints
export JLAB=/home/thulasik/caMOD/jacksonLab
export ORACLE_HOME=/app/oracle/product/10gClient 
export SQLLDR=/app/oracle/product/10gClient/bin/sqlldr 
export SQLPLUS=/app/oracle/product/10gClient/bin/sqlplus 
export SCHEMA='DBI:Oracle:NCID1QA' 
export DB=NCID1QA 
export UNAME='camodqa' 
export PASSWD='cmqa!234' 
export PATH=.:$ORACLE_HOME/bin:~/bin:$PATH


