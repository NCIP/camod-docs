
alter table PUBLICATION disable constraint SYS_C0074889;

alter table PUBLICATION disable primary key;

EXIT;
