
alter table PARTY enable constraint SYS_C0074881;
alter table PARTY enable constraint SYS_C0074882;

alter table PARTY enable primary key;

EXIT;
