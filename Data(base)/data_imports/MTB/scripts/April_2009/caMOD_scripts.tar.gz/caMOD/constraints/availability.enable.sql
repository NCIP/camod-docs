
alter table AVAILABILITY enable constraint SYS_C0074847;

alter table AVAILABILITY enable primary key;

EXIT;
