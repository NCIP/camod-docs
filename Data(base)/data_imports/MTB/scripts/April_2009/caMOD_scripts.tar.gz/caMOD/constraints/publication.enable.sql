
alter table PUBLICATION enable constraint SYS_C0074889;

alter table PUBLICATION enable primary key;

EXIT;
