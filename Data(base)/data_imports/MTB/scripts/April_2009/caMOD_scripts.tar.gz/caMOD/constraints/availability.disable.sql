
alter table AVAILABILITY disable constraint SYS_C0074847;

alter table AVAILABILITY disable primary key;

EXIT;
