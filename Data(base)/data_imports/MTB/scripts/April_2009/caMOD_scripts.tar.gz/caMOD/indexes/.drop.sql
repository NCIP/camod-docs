SELECT 'drop index ' || A.index_name || ';' FROM user_indexes A WHERE lower(
*
ERROR at line 1:
ORA-03114: not connected to ORACLE


SELECT 'EXIT;' FROM dual
*
ERROR at line 1:
ORA-03114: not connected to ORACLE


