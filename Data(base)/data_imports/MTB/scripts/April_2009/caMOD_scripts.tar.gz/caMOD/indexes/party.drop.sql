
drop index SYS_C0022850;

EXIT;
