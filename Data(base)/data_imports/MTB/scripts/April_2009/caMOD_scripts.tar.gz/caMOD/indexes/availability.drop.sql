
drop index SYS_C0022816;

EXIT;
