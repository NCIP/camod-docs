
drop index SYS_C0022829;

EXIT;
