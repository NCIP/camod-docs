
drop index SYS_C0022849;

EXIT;
