
drop index SYS_C0022832;

EXIT;
