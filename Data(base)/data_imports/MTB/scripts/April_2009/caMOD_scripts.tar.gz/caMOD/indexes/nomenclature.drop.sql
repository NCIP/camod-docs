
drop index SYS_C0022848;

EXIT;
